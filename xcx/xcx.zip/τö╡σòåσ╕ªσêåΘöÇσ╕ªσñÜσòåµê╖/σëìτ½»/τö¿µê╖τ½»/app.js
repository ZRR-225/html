var s = require("yb_tuangou/utils/core.js");

App({
    onShow: function(t) {
        console.log("APP onShow !!!!!!"), console.log(t), console.log("lxm", t.path);
    },
    version: "1.0.4",
    get_location: function(e) {
        console.log("获取位置");
        var a = this;
        wx.getLocation({
            type: "wgs84",
            success: function(t) {
                a.setCache("location", t), s.get("Community/city", {
                    latitude: t.latitude,
                    longitude: t.longitude
                }, function(t) {
                    0 == t.code && (a.setCache("community", t.info), "function" == typeof e && e("1"));
                });
            },
            fail: function(t) {
                t.errMsg && "getLocation:fail auth deny" == t.errMsg && s.alert("为了体验更好的服务，请选授权位置信息", function() {
                    wx.openSetting({
                        success: function(t) {
                            a.get_location();
                        }
                    });
                });
            }
        });
    },
    get_city: function() {
        var e = this, t = e.getCache("location"), a = e.getCache("select_loc");
        a && (t = a), s.get("Community/city", {
            latitude: t.latitude,
            longitude: t.longitude
        }, function(t) {
            0 == t.code && e.setCache("community", t.info);
        });
    },
    queryString: function(t) {
        var e = t.indexOf("?");
        t = t.substr(e + 1);
        for (var a = new Object(), n = t.split("&"), o = 0; o < n.length; o++) a[n[o].split("=")[0]] = unescape(n[o].split("=")[1]);
        return a;
    },
    getExtC: function(t) {
        "function" == typeof t && t();
    },
    onLaunch: function(t) {
        var e = this;
        console.log(t);
        var a = getCurrentPages();
        console.log(a);
        var n = require("siteinfo.js"), o = 0;
        (e = this).siteInfo = n, t.query.pid && (o = t.query.pid), console.log(o), e.setCache("pid", o), 
        e.getExtC(function() {
            e.get_menu(function(t) {});
        });
    },
    set_share_pid: function(t) {
        var e = this.getCache("userinfo").uid;
        e && t && 0 != t && s.get("Distribe/addman", {
            uid: e,
            pid: t
        }, function(t) {
            console.log(t);
        });
    },
    after_sale: function(t, e) {
        var a = s.data(t).id;
        s.get("order/after_sale", {
            order_id: a,
            type: e
        }, function(t) {
            0 == t.code ? s.alert("申请成功,请等待商家与您联系！") : s.alert(t.msg);
        });
    },
    requirejs: function(t) {
        return require("yb_tuangou/utils/" + t + ".js");
    },
    get_menu: function(o) {
        var i = this;
        i.getCache("menu") ? o(2) : wx.request({
            url: i.siteInfo.siteroot + "?i=" + i.siteInfo.uniacid + "&t=undefined&v=" + i.version + "&from=wxapp&c=entry&a=wxapp&do=index_tabbar&m=yb_tuangou&sign=1d917db727d0aa4e23ca117826fa3153",
            data: {},
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                if ("request:ok" == t.errMsg) {
                    if ("string" == typeof t.data && 0 <= t.data.indexOf("html") && 0 <= t.data.indexOf("head") && 0 <= t.data.indexOf("body")) return void s.error("请求错误003");
                    if ("" == t.data) return void console.log("请求异常！");
                    if ("string" == typeof t.data && (t.data = s.json_parse(t.data)), 0 == t.data.code) {
                        var e = t.data.info;
                        if (null == e.page || null == e.page) return void s.alert(e.msg);
                        i.tabBar = e.tabbar, i.page = e.page;
                        var a = 0;
                        for (a = 0; a < i.tabBar.list.length; a++) {
                            var n = i.tabBar.list[a];
                            n.url.indexOf("?") < 0 ? n.url += "?tabbar_index=" + a : n.url += "&tabbar_index=" + a;
                        }
                        i.setCache("menu", e.tabbar, 5);
                    }
                    o(1);
                } else s.alert(t.errMsg);
            }
        });
    },
    getUserInfo: function(e, a) {
        var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
        console.log("getUserInfo !!!!!!");
        var i = this, r = "", c = i.getCache("userinfo");
        c ? a && "function" == typeof a && a(c) : wx.login({
            success: function(t) {
                t.code ? (console.log(t), s.get("user/openid", {
                    wx_code: t.code,
                    iv: o,
                    encryptedData: n
                }, function(t) {
                    return console.log(t), 0 != t.code ? (s.alert(t.msg), "function" == typeof a && a(1e3), 
                    !1) : t.info.errcode ? (s.alert("errcode:" + t.info.errcode + ";errmsg:" + t.info.errmsg), 
                    !1) : (r = t.info.openid, t.info.session_key, void s.get("user/Login", {
                        wx_openid: r,
                        wx_unionid: t.info.unionid ? t.info.unionid : null,
                        nick_name: e.nickName,
                        user_headimg: e.avatarUrl,
                        pid: i.getCache("pid")
                    }, function(t) {
                        console.log(t), e.openid = r, e.uid = t.info, i.setCache("userinfo", e), a && "function" == typeof a && a(c);
                    }));
                })) : s.alert("获取用户登录态失败2");
            },
            fail: function() {
                "function" == typeof a && a(1e3), s.alert("获取用户信息失败");
            }
        });
    },
    get_user_name: function(t, e) {
        s.get("user/UserInfo", {
            uid: t
        }, function(t) {
            console.log(t), e.setData({
                p_name: t.info.nick_name
            });
        });
    },
    check_is_tabbar: function() {
        var t = getCurrentPages()[0];
        if (this.siteInfo.native_tabbar) t.setData({
            tabbar_index: -1,
            showtabbar: !1
        }); else {
            if (t.options.tabbar_index) t.setData({
                tabbar_index: t.options.tabbar_index
            }); else {
                var e = t.route;
                console.log(this.tabBar.list);
                for (var a = 0; a < this.tabBar.list.length; a++) {
                    if (0 <= this.tabBar.list[a].url.indexOf(e)) {
                        t.setData({
                            tabbar_index: a
                        });
                        break;
                    }
                }
            }
            console.log(t.data.tabbar_index), 0 <= t.data.tabbar_index && t.setData({
                showtabbar: "true" == this.page.show_tabbar
            });
        }
    },
    isInArray: function(t, e) {
        for (var a = 0; a < t.length; a++) if (e == t[a].key) {
            var n = t[a].url;
            return n.charAt(n.length - 1);
        }
        return !1;
    },
    page: {
        name: "小程序",
        nv_color: "#ffffff",
        bg_color: "#f2f2f2",
        text_color: "#000000",
        bg_img: "",
        open_img: {},
        show_tabbar: "true",
        login_img: "/yb_tuangou/static/images/login.png"
    },
    tabBar: {
        bg_color: "#ffffff",
        text_color: "#333333",
        select_color: "#fe4b71",
        list: [ {
            imgurl: "/yb_tuangou/pages/index/index",
            name: "首页",
            key: "index",
            page_icon: "/yb_tuangou/static/icon/gray_home.png",
            page_select_icon: "/yb_tuangou/static/icon/red_home.png"
        }, {
            imgurl: "/yb_tuangou/pages/shop_coupon/index",
            name: "优惠券",
            key: "shop_coupon",
            page_icon: "/yb_tuangou/static/icon/gray_find.png",
            page_select_icon: "/yb_tuangou/static/icon/red_find.png"
        }, {
            imgurl: "/yb_tuangou/pages/product/index",
            name: "商品",
            key: "product",
            page_icon: "/yb_tuangou/static/icon/gray_cate.png",
            page_select_icon: "/yb_tuangou/static/icon/red_cate.png"
        }, {
            imgurl: "/yb_tuangou/pages/member/cart/index",
            name: "购物车",
            key: "cart",
            page_icon: "/yb_tuangou/static/icon/gray_cart.png",
            page_select_icon: "/yb_tuangou/static/icon/red_cart.png"
        }, {
            imgurl: "/yb_tuangou/pages/member/index/index",
            name: "会员中心",
            key: "member_index",
            page_icon: "/yb_tuangou/static/icon/gray_people.png",
            page_select_icon: "/yb_tuangou/static/icon/red_people.png"
        } ]
    },
    getCache: function(t, e) {
        var a = +new Date() / 1e3, n = "";
        a = parseInt(a);
        try {
            (n = wx.getStorageSync(t + this.globalData.appid)).expire > a || 0 == n.expire ? n = n.value : (n = "", 
            this.removeCache(t));
        } catch (t) {
            n = void 0 === e ? "" : e;
        }
        return n || "";
    },
    setCache: function(t, e, a) {
        var n = +new Date() / 1e3, o = !0, i = {
            expire: a ? n + parseInt(a) : 0,
            value: e
        };
        try {
            wx.setStorageSync(t + this.globalData.appid, i);
        } catch (t) {
            o = !1;
        }
        return o;
    },
    removeCache: function(t) {
        var e = !0;
        try {
            wx.removeStorageSync(t + this.globalData.appid);
        } catch (t) {
            e = !1;
        }
        return e;
    },
    ab: function(t) {},
    util: require("./we7/resource/js/util.js"),
    siteInfo: require("siteinfo.js"),
    globalData: {
        appid: "liu2417301781",
        userInfo: null,
        app_name: "壹佰小程序"
    },
    config: {
        background: "#8b8b8b",
        button_color: "#fff",
        alert_color: "#fff",
        font_color: "black",
        selectedColor: "#f74951",
        kuan: "款",
        dan: "单",
        fu: "付",
        gou: "购",
        huo: "货"
    },
    redirect: function(t, e) {
        wx.navigateTo({
            url: "/yb_tuangou/pages/pintuan/pages/" + t + "?" + e
        });
    },
    showModal: function(t) {
        var e = wx.createAnimation({
            duration: 200
        });
        e.opacity(0).rotateX(-100).step(), t.setData({
            animationData: e.export()
        }), setTimeout(function() {
            e.opacity(1).rotateX(0).step(), t.setData({
                animationData: e
            });
        }.bind(t), 200);
    },
    showToast: function(t, e) {
        var a = {};
        a.toastTitle = e, t.setData({
            toast: a
        });
        var n = wx.createAnimation({
            duration: 100
        });
        n.opacity(0).rotateY(-100).step(), a.toastStatus = !0, a.toastAnimationData = n.export(), 
        t.setData({
            toast: a
        }), setTimeout(function() {
            n.opacity(1).rotateY(0).step(), a.toastAnimationData = n, t.setData({
                toast: a
            });
        }.bind(t), 100), setTimeout(function() {
            a.toastStatus = !1, t.setData({
                toast: a
            });
        }.bind(t), 2e3);
    }
});