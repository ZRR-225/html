module.exports = {
    name: "说图谱源码社区",
    uniacid: "5",
    acid: "5",
    version: "1.0.0",
    siteroot: "https://www.shuotupu.com/app/index.php",
    native_tabbar: !0
};