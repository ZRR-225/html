var o = require("./barcode"), c = require("./qrcode");

function a(e) {
    return Math.round(wx.getSystemInfoSync().windowWidth * e / 750);
}

module.exports = {
    barcode: function(e, t, r, n) {
        o.code128(wx.createCanvasContext(e), t, a(r), a(n));
    },
    qrcode: function(e, t, r, n) {
        c.api.draw(t, {
            ctx: wx.createCanvasContext(e),
            width: a(r),
            height: a(n)
        });
    }
};