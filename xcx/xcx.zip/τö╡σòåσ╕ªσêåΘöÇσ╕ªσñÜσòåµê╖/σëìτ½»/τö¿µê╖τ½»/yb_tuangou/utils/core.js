var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, o = "function" == typeof Symbol && "symbol" == r(Symbol.iterator) ? function(t) {
    return void 0 === t ? "undefined" : r(t);
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : r(t);
}, c = require("./check");

module.exports = {
    toQueryPair: function(t, e) {
        return void 0 === e ? t : t + "=" + encodeURIComponent(null === e ? "" : String(e));
    },
    getUrl: function(t, e) {
        t = t.replace(/\//gi, "/");
        var n = getApp().globalData.api + "api/" + t;
        return e && ("object" == (void 0 === e ? "undefined" : o(e)) ? n += "?app_id=" + getApp().globalData.appid + "&" + c.param(e) : "string" == typeof e && (n += "&" + e)), 
        n;
    },
    json: function(t, e, n, o, a, i) {
        var r = getApp(), s = (r.getCache("userinfo"), r.requirejs("core"));
        o && s.loading();
        var u = {
            url: a ? this.getUrl(t) : this.getUrl(t, e),
            method: a ? "POST" : "GET",
            header: {
                "Content-type": a ? "application/x-www-form-urlencoded" : "application/json"
            }
        };
        a && (u.data = c.param(e)), n && (u.success = function(t) {
            if (o && s.hideLoading(), "request:ok" == t.errMsg) {
                if ("string" == typeof t.data && 0 <= t.data.indexOf("html") && 0 <= t.data.indexOf("head") && 0 <= t.data.indexOf("body")) return void s.error("服务器错误！");
                n(t.data);
            } else this.alert(t.errMsg);
        }), u.fail = function(t) {
            that.alert(t.errMsg);
        }, wx.request(u), console.log(u);
    },
    post: function(t, e, n, o) {
        var a = this, i = t.split("/");
        i = i[0] + "_" + i[1], o && a.loading(), getApp().util.request({
            url: "entry/wxapp/" + i,
            data: e,
            method: "POST",
            success: function(t) {
                if (console.log(t), o && a.hideLoading(), "request:ok" == t.errMsg) {
                    if ("string" == typeof t.data && 0 <= t.data.indexOf("html") && 0 <= t.data.indexOf("head") && 0 <= t.data.indexOf("body")) return void a.error("请求错误002");
                    if ("" == t.data) return void console.log("请求异常！");
                    var e = t.data;
                    "string" == typeof e && (console.log(void 0 === e ? "undefined" : r(e)), e = a.json_parse(e)), 
                    n(e);
                } else a.alert(t.errMsg);
            },
            fail: function(t) {
                a.alert(t.errMsg);
            }
        });
    },
    get: function(t, e, n, o) {
        var a = this, i = t.split("/");
        i = i[0] + "_" + i[1], o && a.loading(), getApp().util.request({
            url: "entry/wxapp/" + i,
            data: e,
            success: function(t) {
                if (o && a.hideLoading(), "request:ok" == t.errMsg) {
                    if ("string" == typeof t.data && 0 <= t.data.indexOf("html") && 0 <= t.data.indexOf("head") && 0 <= t.data.indexOf("body")) return void a.error("请求错误001");
                    if ("" == t.data) return void console.log("请求异常！");
                    var e = t.data;
                    "string" == typeof e && (console.log(void 0 === e ? "undefined" : r(e)), e = a.json_parse(e)), 
                    n(e);
                } else a.alert(t.errMsg);
            },
            fail: function(t) {
                o && a.hideLoading(), a.alert(t.errMsg);
            }
        });
    },
    alert: function(t, e) {
        "object" === (void 0 === t ? "undefined" : o(t)) && (t = JSON.stringify(t)), wx.showModal({
            title: "提示",
            content: t,
            showCancel: !1,
            success: function(t) {
                t.confirm && "function" == typeof e && e();
            }
        });
    },
    confirm: function(t, e, n) {
        "object" === (void 0 === t ? "undefined" : o(t)) && (t = JSON.stringify(t)), wx.showModal({
            title: "提示",
            content: t,
            showCancel: !0,
            success: function(t) {
                t.confirm ? "function" == typeof e && e() : "function" == typeof n && n();
            }
        });
    },
    loading: function(t) {
        void 0 !== t && "" != t || (t = "加载中"), wx.showToast({
            title: t,
            icon: "loading",
            duration: 5e6
        });
    },
    hideLoading: function() {
        wx.hideToast();
    },
    toast: function(t, e) {
        e || (e = "loading"), wx.showToast({
            title: t,
            icon: e,
            duration: 1e3
        });
    },
    warning: function(t) {
        wx.showToast({
            title: t,
            image: "/yb_tuangou/static/images/icon-warning.png",
            duration: 2e3
        });
    },
    error: function(t) {
        wx.showToast({
            title: t,
            icon: "success",
            image: "/yb_tuangou/static/images/x.png",
            duration: 2e3
        });
    },
    success: function(t) {
        wx.showToast({
            title: t,
            icon: "success",
            duration: 1e3
        });
    },
    pdata: function(t) {
        return t.currentTarget.dataset;
    },
    data: function(t) {
        return t.target.dataset;
    },
    phone: function(t) {
        var e = this.pdata(t).phone;
        wx.makePhoneCall({
            phoneNumber: e
        });
    },
    time_format: function(t) {
        var e = new Date(1e3 * t);
        return e.getFullYear() + "-" + (e.getMonth() + 1) + "-" + e.getDate() + " " + e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds();
    },
    time_str: function(t) {
        return t = (t = t.substring(0, 19)).replace(/-/g, "/"), new Date(t).getTime() / 1e3;
    },
    Countdown: function(t, u) {
        var e = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 0, c = (3 < arguments.length && void 0 !== arguments[3] && arguments[3], 
        {}), l = "interval" + e, f = t - Date.parse(new Date()) / 1e3;
        f <= 0 && (c.show_time = !1, u(c)), l = setInterval(function() {
            var t = f, e = Math.floor(t / 3600 / 24), n = e.toString();
            1 == n.length && (n = "0" + n);
            var o = Math.floor((t - 3600 * e * 24) / 3600), a = o.toString();
            1 == a.length && (a = "0" + a);
            var i = Math.floor((t - 3600 * e * 24 - 3600 * o) / 60), r = i.toString();
            1 == r.length && (r = "0" + r);
            var s = (t - 3600 * e * 24 - 3600 * o - 60 * i).toString();
            1 == s.length && (s = "0" + s), c.countDownDay = 99 < parseInt(n) ? "99" : n, c.countDownHour = a, 
            c.countDownMinute = r, c.countDownSecond = s, c.show_time = !0, "function" == typeof u && u(c), 
            --f < 0 && (clearInterval(l), wx.showToast({
                title: "活动已结束"
            }), c.countDownDay = "0", c.countDownHour = "0", c.countDownMinute = "0", c.countDownSecond = "0", 
            c.show_time = !1, "function" == typeof u && u(c));
        }.bind(this), 1e3);
    },
    json_parse: function(t) {
        var e = t;
        if ("object" != (void 0 === (e = e.replace(" ", "")) ? "undefined" : r(e))) return e = e.replace(/\ufeff/g, ""), 
        JSON.parse(e);
    },
    str: function(t) {
        return JSON.stringify(t);
    },
    tx_map: function(e, n, o) {
        e = parseFloat(e), n = parseFloat(n);
        var t = this;
        getApp().getCache("map") ? wx.openLocation({
            latitude: e,
            longitude: n,
            scale: 28,
            name: o
        }) : wx.getLocation({
            type: "wgs84",
            success: function(t) {
                console.log(t), getApp().setCache("map", t, 1200);
                t.latitude, t.longitude;
                wx.openLocation({
                    latitude: e,
                    longitude: n,
                    scale: 28,
                    name: o
                });
            },
            fail: function() {
                t.alert("未授权位置信息");
            }
        });
    },
    previewImage: function(t, e, n) {
        var o = [];
        (e = JSON.parse(e)).forEach(function(t, e) {
            o[e] = t[n];
        }), wx.previewImage({
            current: t,
            urls: o
        });
    },
    Clipboard: function(t) {
        wx.setClipboardData({
            data: t,
            success: function(t) {
                wx.getClipboardData({
                    success: function(t) {}
                });
            }
        });
    },
    jump: function(e, t) {
        t = t && "" != t ? t : 1;
        var n = e;
        -1 < n.indexOf("?") && (n = (n = e.split("?"))[0]);
        for (var o = getApp().tabBar.list, a = 0; a < o.length; a++) if (n == o[a].url.split("?")[0] && 0 != a) {
            e = "/yb_tuangou/native/tabbar" + a + "/index", t = 4;
            break;
        }
        console.log("page", e + ";type=" + t), "/yb_tuangou/pages/index/index" == e && (t = 4), 
        1 == t ? wx.navigateTo({
            url: e,
            fail: function(t) {
                if (0 <= t.errMsg.indexOf("tabbar")) {
                    if (-1 < e.indexOf("?")) e = e.split("?")[0];
                    wx.switchTab({
                        url: e
                    });
                }
            }
        }) : 2 == t ? wx.redirectTo({
            url: e,
            fail: function(t) {
                0 <= t.errMsg.indexOf("tabbar") && wx.switchTab({
                    url: e
                });
            }
        }) : 3 == t ? wx.reLaunch({
            url: e
        }) : 4 == t ? wx.switchTab({
            url: e
        }) : 5 == t && wx.navigateBack();
    },
    ReName: function(t) {
        wx.setNavigationBarTitle({
            title: t || ""
        });
    },
    removeByValue: function(t, e, n) {
        for (var o = -1, a = 0; a < t.length; a++) if (console.log(t[a]), t[a] == e) {
            o = a;
            break;
        }
        t.splice(o, 1), "function" == typeof n && n(t);
    },
    setting: function() {
        wx.setNavigationBarColor({
            frontColor: getApp().page.text_color,
            backgroundColor: getApp().page.nv_color,
            animation: {
                duration: 0,
                timingFunc: "easeIn"
            }
        }), getApp().check_is_tabbar();
    },
    compatible_phonex: function(e) {
        wx.getSystemInfo({
            success: function(t) {
                "iphonrx" == t.model && e.setData({
                    isIphoneX: !0
                });
            }
        });
    },
    menu_url: function(t) {
        var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1, n = this, o = n.pdata(t), a = (t = o.key, 
        o.url ? o.url : ""), i = o.appid ? o.appid : "", r = o.path ? o.path : "", s = o.title ? o.title : "", u = o.phone ? o.phone : "", c = o.lat ? o.lat : "", l = o.lng ? o.lng : "";
        if (console.log(o), 1 == t) a && 0 < a.length && n.jump(a, e); else if (2 == t) wx.navigateToMiniProgram({
            appId: i,
            path: r,
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function(t) {
                console.log("打开成功");
            },
            fail: function(t) {}
        }); else if (3 == t) n.jump(a, 1); else if (4 == t) u ? wx.makePhoneCall({
            phoneNumber: u
        }) : n.alert("电话不能为空"); else {
            if (5 != t) return;
            c && l ? n.tx_map(c, l, s) : n.alert("请完善位置信息");
        }
    },
    setWatcher: function(e, n) {
        var o = this;
        Object.keys(n).forEach(function(t) {
            o.observe(e, t, n[t]);
        });
    },
    observe: function(t, e, n) {
        var o = t[e];
        Object.defineProperty(t, e, {
            configurable: !0,
            enumerable: !0,
            set: function(t) {
                n(o = t, o);
            },
            get: function() {
                return o;
            }
        });
    },
    isPoneAvailable: function(t) {
        return !!/^[1][3,4,5,7,8][0-9]{9}$/.test(t);
    },
    isCardNo: function(t) {
        return !1 !== /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(t);
    },
    canvasToTempImage: function(t, n) {
        wx.canvasToTempFilePath({
            canvasId: t,
            success: function(t) {
                console.log(t);
                var e = t.tempFilePath;
                console.log(e), n.setData({
                    imagePath: e
                });
            },
            fail: function(t) {
                console.log(t);
            }
        });
    }
};