<?php
if(!defined('IN_IA'))
{
    define('IN_IA', TRUE);
}
$alert_add = array(
    [
        'table'=>tablename('ybtg_after_sale'),
        'column'=>'mch_id',
        'sql'=>"ALTER TABLE  `ims_ybtg_after_sale` ADD  `mch_id` int(11) NOT NULL COMMENT '商户id';"
    ],
    [
    'table'=>tablename('ybtg_user_card_orders'),
            'column'=>'prepay_id',
            'sql'=>"ALTER TABLE  `ims_ybtg_user_card_orders` ADD  `prepay_id` varchar(255) DEFAULT NULL COMMENT '模板推送';"
    ],
    [
        'table'=>tablename('ybtg_user_commander_setting'),
        'column'=>'ad_pic',
        'sql'=>"ALTER TABLE  `ims_ybtg_user_commander_setting` ADD  `ad_pic` varchar(500) DEFAULT NULL COMMENT '首页广告';"
    ],
);
foreach ($alert_add as $item)
{
    $s = 'describe '.$item['table'].' '.$item['column'].';';
    $has = pdo_fetch($s);
    if(empty($has))
    {
        $ss .= $item['sql'];
    }
}
$a="";
$sql=<<<UP
$ss
UP;
$SQL_RES = pdo_run($sql);
