<?php

define('IN_SYS', TRUE);
header('Access-Control-Allow-Origin:*');
define('SITE_PATH',str_replace('\\','/',realpath(dirname(__FILE__).'/'))."/");
// 定义应用目录1
define('APP_PATH', __DIR__ . '/application/');
//加载自定义配置
define('CONF_PATH', APP_PATH );
define('WXAPP_TYPE', 20);//102
define('ATTACHMENT_ROOT', SITE_PATH);
$HTTP_HOST = explode(":", $_SERVER['HTTP_HOST']);
$HTTP_HOST = $HTTP_HOST[0];
define('WEB_HOST', $HTTP_HOST);
error_reporting(0);
require '../../../framework/bootstrap.inc.php';
require 'bootstrap.sys.inc.php';
error_reporting(0);
//require '../update.php';
// 加载框架引导文件
require __DIR__ . '/thinkphp/start.php';
