<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/6
 * Time: 14:16
 */
/*ini_set('display_errors',true);
error_reporting(E_ALL);*/
define('APP_PATH', __DIR__ . '/application/');
require __DIR__ . '/thinkphp/base.php';
require __DIR__ . '/thinkphp/library/think/Session.php';
require __DIR__ . '/thinkphp/library/think/Request.php';
require __DIR__ . '/application/web/service/Wechat.php';
require __DIR__ . '/application/web/controller/User.php';
use think\Request;
use think\Config;
use think\Session;
use app\web\service\Wechat;
use app\web\controller\User;
$databasePath = APP_PATH."database.php";
Config::load($databasePath,'database');
$mch_id = Request::instance()->param("mch_id");
if (!empty($mch_id)) {
    Session::set("mch_id", $mch_id);
}
$pid = Request::instance()->param("pid");
if (!empty($pid)) {
    Session::set("pid", $pid);
}
$page = Request::instance()->param("page");
if (!empty($page)) {
    Session::set("page", $page);
}
//获取code
$code = Request::instance()->param("code");
if (empty($code)) {
    if (isset($_SERVER['HTTP_X_REAL_HOST'])) {
        $host = $_SERVER['HTTP_X_REAL_HOST'];
    } else {
        $host = $_SERVER['HTTP_HOST'];
    }
    $url = "https://" . $host . "/addons/yb_tuangou/core/web.php";
    $we_chat = new Wechat(); //实例化类
    $we_chat->accredit($url); //调用方法
} else {
    $user = new User();
    $user->Login($code);
}
/*$user = new User();
$user->Login("");*/