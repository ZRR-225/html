<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:78:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/bargain/add_bargain.html";i:1550822761;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/demo.html";i:1548035074;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
<script src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/js/vue.js"></script>
<link href="./favicon.ico?v=1.2" rel="shortcut icon" type="image/x-icon"/>
<link rel="stylesheet" href="/public/css/linecons.css">
<link rel="stylesheet" href="/public/static/bast/bootstrap.css">
<link rel="stylesheet" href="/public/static/bast/xenon-core.css?v=1.0">
<link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css"/>
<link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
<link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
<link rel="stylesheet" type="text/css" href="/public/css/dashboard.css">
<link rel="stylesheet" type="text/css" href="/public/css/yb_index.css?v=1.0"/>
<link rel="stylesheet" type="text/css" href="/public/css/defau.css">
<script src="/public/static/layer/2.4/layer.js"></script>
</head>
<script>
    var UM_SITE_ROOT = '__CONF_SITE__';
</script>
<div id="newks2"></div>
<script src="/public/menu/js/jquery.artdialog.js"></script>
<script src="/public/menu/js/iframetools.js"></script>
<script src="/public/js/public_js.js"></script>
<link href="/public/static/umedito/themes/default/_css/umeditor.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="/public/static/umedito/third-party/template.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/public/static/umedito/umeditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/public/static/umedito/_examples/editor_api.js"></script>
<script type="text/javascript" src="/public/static/umedito/lang/zh-cn/zh-cn.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>
<script src="/public/js/all.js"></script>
<link rel="stylesheet" type="text/css" href="/public/css/defau.css">
<input  type="hidden" id="goods_select_id" value="">
<script src="/public/menu/js/jquery.artdialog.js"></script>
<style>
    .thumbnail {
        display: block;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        max-height: 100%;
        max-width: 100%;
        padding: 4px;
        line-height: 1.42857143;
        /* border: 1px solid #ddd; */
        -webkit-transition: all .2s ease-in-out;
        -o-transition: all .2s ease-in-out;
        transition: all .2s ease-in-out;
        height: 165px;
        width: 165px;
        display: inline-flex;
        margin-left: 10px;
    }
    .formControls a {
        height: 30px !important;
        width: 110px !important;
        background: #00c1de !important;
        color: #fff !important;
        text-align: center !important;
        line-height: 30px !important;
        display: inline-block;
    }
    .formControls a {height: 30px !important;width: 110px !important; background: #00c1de !important;color: #fff !important;text-align: center !important;line-height: 30px !important;}
</style>
<article class="cl pd-20">
    <form action="" method="post" class="form form-horizontal" id="my_bargain">
        <input type="hidden" value="" id="goods_id">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>活动名称：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" v-model="goods_name" value="" placeholder="活动名称" class="input-text" id="bargain_name">
                <input type="hidden" id="old_goods" value="-1">
                <a href="javascript:;" onclick="layer_open('选择商品','__CONF_SITE__admin/Bargain/returnGoodsList',800,600)">选择商品</a>
                <!--<p id="show_alert"><span style="color: red;">注：请选择商品</span></p>-->
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>活动主图：</label>
            <div class="formControls col-xs-8 col-sm-9" style="margin-left: -10px">
                <img width="120"  v-if="img_path!=''"  :src="img_path" class="thumbnail" id='master_goods_pic'>
                <input onclick="select_img('1','zhu');" class="btn btn-default" type="button" value="选择图片" style="margin-left: 10px;display: block;">
                <div style="color: #ccc;margin-left: 10px">建议图标尺寸：600*300px</div>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>轮播图：</label>
            <div class="formControls col-xs-8 col-sm-9" style="margin-left: -10px">
                <img v-for="item in array_img" width="120"  :src="item.url" class="thumbnail">
                <div class="clear"></div>
                <div>
                <input onclick="select_img('5','lun');" class="btn btn-default" type="button" value="选择图片" style="margin-left: 10px">
                <div style="color: #ccc;margin-left: 10px">建议图标尺寸：600*300px</div>
                </div>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>活动分类：</label>
            <div class="formControls col-xs-8 col-sm-3">
                <span class="select-box">
                  <select class="select" size="1" id="class_id">
                    <option value="">请选择</option>
                      <?php if(is_array($class_list) || $class_list instanceof \think\Collection || $class_list instanceof \think\Paginator): $i = 0; $__LIST__ = $class_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$c): $mod = ($i % 2 );++$i;?>
                             <option value="<?php echo $c['id']; ?>"><?php echo $c['class_name']; ?></option>
                      <?php endforeach; endif; else: echo "" ;endif; ?>
                  </select>
                </span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>原价：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="original_price" type="number" autocomplete="off" v-model="price" value="" placeholder="原价" class="input-text">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>底价：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="lowest_price" type="number" autocomplete="off" value="" class="input-text" placeholder="底价">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>完成人数：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="completed_number" type="number" autocomplete="off" value="" class="input-text" placeholder="完成人数">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>活动数量：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="bargain_inventory" type="number" autocomplete="off" value="" class="input-text" placeholder="活动数量" >
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>开始时间：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="star_time" class="input-text Wdate" type="text" onclick="WdatePicker({dateFmt:'yyyy-M-d H:mm:ss',minDate:'%y-%M-{%d}'})" style="width:160px;"/>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>结束时间：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="end_time" type="text" onclick="WdatePicker({dateFmt:'yyyy-M-d H:mm:ss',minDate:'%y-%M-{%d+1}'})" value=""  class="input-text Wdate" style="width:160px;">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>消费截至时间：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="consumption_time" type="text"  onclick="WdatePicker({dateFmt:'yyyy-M-d H:mm:ss',minDate:'%y-%M-{%d+1}'})" value="" class="input-text Wdate" style="width:160px;">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>活动规则：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <div id="editor" type="text/plain" style="width: 50%; height: 500px;"></div>
                </div>
                </div>
                <div class="row cl">
                    <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                    <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button"
                           style="bottom:0rem;z-index: 999999999;"value="提交">
                    </div>
                    </div>
                    </form>
                    </article>
                <script type="text/javascript" src="/public/js/vue.js"></script>
                <script src="/public/menu/js/jquery.artdialog.js"></script>
                <script src="/public/menu/js/iframetools.js"></script>
                <script type="text/javascript">
                    var bannerVM = new Vue({
                        el: '#my_bargain',
                        data: {
                            goods_id:'',//商品ID
                            goods_name:'',//商品名称
                            img_path:'',//图片链接
                            img_id:'',//图片ID
                            price:'',//价格
                            array_img:[],
                        }
                    });
                    $(function () {
                        var ue =UM.getEditor('editor',{
                            imageUrl:"__CONF_SITE__app/Umupload/uploadFile", //处理图片上传的接口
                            imageFieldName:"upfile", //上传图片的表单的name
                            imagePath: ""
                        });
                    });
                    //模块输入信息验证
                    function verify(bargain_picture,bargain_name,bargain_inventory,lowest_price,star_time,end_time,consumption_time,activity_rules,completed_number,array_img,class_id) {
                        var a=$("#old_goods").val();
                        if(a==-1){
                            layer.msg('请选择商品',{icon:5,time:1000});
                            return false;
                        }
                        if (bargain_name==''){
                            layer.msg('活动名称不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (bargain_picture==''){
                            layer.msg('主图不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (lowest_price==''){
                            layer.msg('底价不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (completed_number==''){
                            layer.msg('完成人数不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (bargain_inventory==''){
                            layer.msg('活动数量不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (star_time==''){
                            layer.msg('开始时间不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (end_time==''){
                            layer.msg('结束时间不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (consumption_time==''){
                            layer.msg('消费截至时间不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (activity_rules==''){
                            layer.msg('活动规则不能为空',{icon:5,time:1000});
                            return false;
                        }
                        if (array_img==''){
                            layer.msg('请选择轮播图',{icon:5,time:1000});
                            return false;
                        }
                        if (class_id == '') {
                            layer.msg('请选择活动分类',{icon:5,time:1000});
                            return false;
                        }
                        return true;
                    }
                    var flag = false;//防止重复提交
                    //添加用户
                    function addSuppAjax() {
                        var bargain_name = $("#bargain_name").val();
                        var bargain_picture =bannerVM.img_id;
                        var bargain_inventory  = $("#bargain_inventory").val();
                        var original_price = $("#original_price").val();
                        var lowest_price = $("#lowest_price").val();
                        var star_time=$("#star_time").val();
                        var end_time=$("#end_time").val();
                        var consumption_time=$("#consumption_time").val();
                        var activity_rules= UM.getEditor('editor').getContent();
                        var completed_number=$("#completed_number").val();
                        var array_img= JSON.stringify(bannerVM.array_img);
                        var class_id=$("#class_id").val();
                        if(parseFloat(original_price)<=parseFloat(lowest_price)){
                            layer.msg('原价不能小于低价',{icon:5,time:1000});
                            return false;
                        }
                        if(verify(bargain_picture,bargain_name,bargain_inventory,lowest_price,star_time,end_time,consumption_time,activity_rules,completed_number,array_img,class_id) && !flag){
                            flag = true;
                            $.ajax({
                                type : "post",
                                url : "<?php echo url('bargain/add_bargain'); ?>",
                                data : {
                                    'bargain_name' : bargain_name,
                                    'bargain_picture' : bargain_picture,
                                    'bargain_inventory' : bargain_inventory,
                                    'original_price' : original_price,
                                    'lowest_price':lowest_price,
                                    'star_time':star_time,
                                    'end_time':end_time,
                                    'consumption_time':consumption_time,
                                    'activity_rules':activity_rules,
                                    'completed_number':completed_number,
                                    'array_img':array_img,
                                    'class_id': class_id,
                                    'goods_id':$("#old_goods").val(),
                                },
                                success : function(data) {
                                    console.log(data);
                                    if(data['code']>0){
                                        layer.msg('添加成功!',{icon:1,time:1000},function () {
                                            window.parent.location.href="<?php echo url('bargain/index'); ?>";
                                        });
                                    }
                                    else{
                                        flag = false;
                                        layer.msg(data['message'],{icon:5,time:1000});
                                    }
                                }
                            });
                        }
                    }
                    function select_img(number,type) {
                        art.dialog.open(('__CONF_SITE__admin/images/dialogalbumlist&number=' + number + '&type=' + type), {
                            lock : true,
                            title : "我的图片",
                            width : 900,
                            height : 620,
                            drag : false,
                            background : "#000000",
                            scrollbar:false,
                        }, true);
                    }
                    //选择多张图片
                    function lun_images(id_array,path_array) {
                        var arr=[];
                        id_array=id_array.split(",");
                        path_array=path_array.split(",");
                        for (var i=0;i<id_array.length;i++){
                            var item={};
                            item['id']=id_array[i];
                            item['url']=path_array[i];
                            arr.push(item);
                        }
                        bannerVM.array_img=arr;
                    }
                    //选择单张图片
                    function zhu_images(id,path) {
                        bannerVM.img_path=path;
                        bannerVM.img_id = id;
                    }
                function select_normal_goods(goods_id) {
                    $.post("<?php echo url('bargain/returnGoodsList'); ?>",{goods_id:goods_id},
                        function (data) {
                            if(data.message == '操作成功')
                            {
                                $('#lowest_price').val(data.code.cost_price);
                                $('#editor').html(data.code.description);
                                $('#bargain_inventory').val(data.code.stock);
                                bannerVM.img_path = data.code.img_cover;
                                bannerVM.price = data.code.price;
                                bannerVM.img_id = data.code.images;
                                bannerVM.goods_name = data.code.goods_name;
                                var img_arr = data.code.img_arr;
                                var arr=[];
                                for (var i=0;i<img_arr.length;i++){
                                    var item={};
                                    item['id']=img_arr[i]['img_id'];
                                    item['url']=img_arr[i]['img_cover'];
                                    arr.push(item);
                                }
                                bannerVM.array_img=arr;
                                $("#show_alert").hide();
                                $("#old_goods").val(goods_id);
                            }
                        },"json");
                }
                </script>