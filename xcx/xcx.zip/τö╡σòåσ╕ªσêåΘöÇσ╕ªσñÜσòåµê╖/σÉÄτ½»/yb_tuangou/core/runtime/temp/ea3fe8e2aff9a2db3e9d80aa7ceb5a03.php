<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/user/edit_integral.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css"/>
    <script src="/public/js/jquery-2.1.1.js"></script>
</head>
<body>
<article class="cl pd-20">
    <div class="row cl">
        <label class="form-label col-xs-12 col-sm-12">
            重要提示：<br/>
            <span class="c-red">更改累计积分会关联更改会员等级，请谨慎操作！</span>
        </label>
    </div>
    <div class="row cl" style="margin-top: 20px;">
        <label class="form-label col-xs-3 col-sm-2">
            <span class="c-red">*</span>
            可用积分：</label>
        <div class="formControls col-xs-9 col-sm-8">
            <input type="text" autocomplete="off" value="<?php echo $list['integral']; ?>" placeholder="请输入要更改的可用积分" class="input-text" id="integral">
        </div>
    </div>
    <div class="row cl" style="margin-top: 20px;">
        <label class="form-label col-xs-3 col-sm-2">
            <span class="c-red">*</span>
            累计积分：</label>
        <div class="formControls col-xs-9 col-sm-8">
            <input type="text" autocomplete="off" value="<?php echo $list['consume']; ?>" placeholder="请输入要更改的累计积分" class="input-text" id="consume">
        </div>
    </div>
    <div class="row cl" style="margin-top: 20px;">
        <label class="form-label col-xs-3 col-sm-2">
            <span class="c-red">*</span>
            说明：</label>
        <div class="formControls col-xs-9 col-sm-8">
            <input type="text" autocomplete="off" value="无" placeholder="积分更改说明" class="input-text" id="explain">
        </div>
    </div>
    <div class="row cl" style="margin-top: 30px;">
        <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
            <input class="btn btn-primary radius" onclick="rsave('<?php echo $list['uid']; ?>')" type="button" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
        </div>
    </div>
</article>
 <script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
var lock = false;
function rsave(uid) {
    var intral = $('#integral').val();
    intral = parseInt(intral);
    var consus = $('#consume').val();
    consus = parseInt(consus);
    if (intral >= 0) {
        if (!lock) {
            lock = true;
            $.ajax({
                type: "post",
                url: "<?php echo url('user/edit_integral'); ?>",
                data: {
                    uid: uid,
                    integral: intral,
                    consume: consus,
                    explain: $('#explain').val(),
                },
                success: function (data) {
                    if (data['code'] > 0) {
                        layer.msg('保存成功!', {icon: 1, time: 1000}, function () {
                            parent.location.reload();
                        });
                    } else {
                        lock = false;
                        layer.msg('保存失败!', {icon: 2, time: 1000});
                    }
                }
            });
        }
    }else{
        layer.msg('保存失败，会员积分不能小于0', {icon: 2, time: 1000});
    }
}
</script>
</body>
</html>