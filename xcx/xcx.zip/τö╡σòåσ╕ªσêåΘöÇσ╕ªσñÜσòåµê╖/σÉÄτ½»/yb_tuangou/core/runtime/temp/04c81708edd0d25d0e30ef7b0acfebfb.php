<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/integral/index.html";i:1550626186;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/base.html";i:1550644207;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
    <script src="/public/js/jquery-2.1.1.js"></script>
    <script type="text/javascript" src="/public/js/vue.js"></script>
    <link href="./favicon.ico?v=<?php echo time(); ?>" rel="shortcut icon" type="image/x-icon"/>
    <link rel="stylesheet" href="/public/css/linecons.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/bast/bootstrap.css">
    <link rel="stylesheet" href="/public/static/bast/xenon-core.css">
    <link rel="stylesheet" href="/public/static/bast/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css?v=1.1"/>
    <link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
    <link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
    <script src="/public/js/all.js"></script>
    <script>
        var UM_SITE_ROOT = '__CONF_SITE__';
    </script>
    
<style>
    .nav-tabs > li > a:hover { border-color: #eee #eee #20a0ff #eee; } .nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus { background-color: #20a0ff; border-color: #20a0ff; } .nav-tabs > li > a { border-radius: 0 0 0 0; } .nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus { color: #FFF; background-color: #20a0ff; border-color: #20a0ff; } .navbar-nav > li > a { padding-top: 10px; padding-bottom: 10px; line-height: 40px } .navbar-inverse .navbar-nav > li > a:hover, .navbar-inverse .navbar-nav > li > a:focus { color: #777; background-color: #eee; } .therji > li:nth-child(1) { margin-top: 20px; } .big-menu .panel .list-group-item { border: none; overflow: hidden; white-space: normal; text-overflow: clip; font-size: 13px; height: 50px; padding: 0px 15px; } .panel > .list-group .list-group-item { padding-left: 34px; } .big-menu .panel .list-group-item:hover { background-color: #edf6ff; color: #00aeff; } .big-menu .panel .panel-heading .panel-title { width: 100px; float: left; font-size: 14px; } .big-menu .panel .panel-heading .panel-title .fa { font-size: 16px; } .navbar-inverse .navbar-nav > .active > a, .navbar-inverse .navbar-nav > .active > a:hover, .navbar-inverse .navbar-nav > .active > a:focus { color: #f60; background-color: #e7e7e7; border-bottom: 2px solid transparent; border-color: #f60; } button { outline: none; } a { text-decoration: none; } a:hover { text-decoration: none; } ul, li { list-style: none; } ul { margin-bottom: 0px; } body { font-size: 14px; font-family: "微软雅黑"; } .header_right > li > a:hover { color: #666; } .header_right > li { float: left; padding: 0px 20px; border-right: 1px solid #eee; line-height: 33px; } .yyhome:hover .fanhuihome { display: block; } .panel-default > .navtitle { background-color: #24303C; color: white; border: none; } .big-menu .panel .panel-heading .wytitle { height: 50px; padding: 15px 15px; width: 130px; } .yg_login > img { margin: 0px auto; width: 60px; height: 60px; background-color: #5CB85C; border-radius: 50%; border: none; margin-bottom: 10px; } .nav-tabs > li > a:hover { color: #fff; border-color: #44ABF7; background-color: #44ABF7; } .nav-tabs > li { margin-right: 10px; } .nav-tabs > li.active > a, .nav-tabs > li.active > a:hover { background-color: #44ABF7; color: #fff; border-color: #44ABF7; } .nav > li > a { padding: 6px 20px; border-radius: 4px; border: 1px solid #44ABF7; color: #44ABF7; } input[type="radio"] + label::before { content: "\a0"; /*不换行空格*/ display: inline-block; vertical-align: middle; font-size: 16px; width: 1em; height: 1em; margin-right: .4em; border-radius: 50%; border: 2px solid #ddd; text-indent: .15em; line-height: 1; } input[type="radio"]:checked + label::before { background-color: #44ABF7; background-clip: content-box; padding: .1em; border: 2px solid #44ABF7; } input[type="radio"] { position: absolute; clip: rect(0, 0, 0, 0); } /*#frame-11{display: block;visibility: visible;}*/ .panel-default > .wyheader { font-weight: bold; background-color: #F3F3F3; } .chongzhi { margin-bottom: 10px; height: 35px;margin-left: 20px;width: 500px; } .ygminp, .man4, .man2, .man, .man3, .money, .money2, .titleinp { float: left; border: 1px solid #eee; height: 35px; line-height: 35px; margin-left: 0px; margin-right: 0px; } .man { padding: 0px 12px; text-align: center; } .man3 { padding: 0px 12px; text-align: center; } .man2 { width: 130px; padding: 0px 12px; text-align: center; } .man4 { width: 160px; padding: 0px 12px; text-align: center; } .money2 { width: 42%; text-indent: 1em; } .ygminp { width: 42%; text-indent: 1em; } .titleinp2 > .row { width: 260px; margin: 0px; } .titleinp2 > .row > .col-sm-8 { width: 100%; padding-left: 0px; } .shanchu { color: white; background-color: #ED5565; cursor: pointer; } .fa-plus { margin-right: 5px; } .tianj1 { height: 35px; text-align: center; line-height: 35px; border: 1px solid #EFEFEF; background-color: #ddd; cursor: pointer; } .ygtime { padding: 0px; }
    @media (min-width: 1800px){
        .col-md-10{margin-left: 60px;}
    }
    @media (min-width: 1700px){
        .col-md-10{margin-left: 60px;}
    }
    /*@media (min-width: 1650px){*/
        /*.col-md-10{margin-left: 30px;}*/
    /*}*/
    @media (min-width: 1592px) { .titleinp { width: 15%; text-indent: 1em; float: left; border: 1px solid #eee; height: 35px; line-height: 35px; margin-left: 0px; margin-right: 20px; } .titleinp3 { width: 15%; text-indent: 1em; float: left; border: 1px solid #eee;
            height: 35px; line-height: 35px; margin-left: 0px; } }
    @media (max-width: 1591px) { .titleinp { width: 10%; padding-left: 5px; float: left; border: 1px solid #eee; height: 35px; line-height: 35px; margin-left: 0px; margin-right: 10px; } .titleinp3 { width: 10%; padding-left: 5px; float: left; border: 1px solid #eee; height: 35px; line-height: 35px; margin-left: 0px; }
        .col-md-10 {margin-left: 70px;}
    }
    .panel-body { font-size: 12px; }
    @media screen and (min-width:700px) and (max-width:1400px){
        /*.panel-body {background-color:#fcc;}*/
        .col-sm-11{width: 850px;}
        .col-sm-1{font-size: 10px;width: 120px;height: 15px;line-height: 15px;text-align: center;}
        .man4{width: 100px;height: 30px;font-size:10px;line-height: 30px;text-align: center;}
        .tianj1{width:390px;height:35px;margin-left: -100px;line-height: 35px;text-align: center}
        .datetimepicker{width: 100px;height: 30px;font-size: 10px;line-height: 30px;text-align: center}
        .col-md-10{margin-left: 120px; width: 400px}
    }
    /*@media screen and (min-width:700px) and (max-width:1300px){*/
        /*!*.panel-body {background-color:#f60;}*!*/
        /*.col-md-10{margin-left: 140px; width: 370px}*/
    /*}*/
    @media screen and (min-width:700px) and (max-width:1100px){
        /*.panel-body {background-color:#f60;}*/
        .col-sm-11{margin-top: 20px}
    }
    @media screen and (min-width:1200px) and (max-width:1300px){
        /*.panel-body {background-color:cadetblue;}*/
        .col-sm-11{margin-top: 20px}
        .col-md-10{margin-left: 100px;display: inline-block;}
    }
    @media screen and (min-width:1000px) and (max-width:1200px){
        /*.panel-body {background-color:yellow;}*/
        .col-sm-11{margin-top: 20px}
        .tianj1{margin-left: 100px}
    }
    @media screen and (min-width:700px) and (max-width:1000px){
        /*.panel-body {background-color:#fcc;}*/
        .tianj1{margin-left:50px;}
        .col-md-10{width: 400px}
        .ygminp inp1{width: 300px;}
        #datetimepicker{width: 100px;height: 30px;}
        .col-md-10{margin-left: 100px;}
    }@media screen and (min-width:700px) and (max-width:990px){
        .col-md-10{margin-left: 0px;margin-top: 20px}
    }
    @media screen and (min-width:700px) and (max-width:900px){
        /*.panel-body {background-color:#fcc;}*/
        .tianj1{margin-left: 100px;}
        .datetimepicker{width: 100px;height: 30px;font-size: 10px;line-height: 30px;text-align: center;display: inline-block;position: absolute;}
        .col-md-10{width: 400px}
        .ygminp inp1{width: 300px;}
    }
    label {font-size:12px !important;}
    .col-md-10 .chongzhi{width: 400px;margin-left: 80px;margin-top: 2px}
</style>

    <style>.new_logo .logo-expanded {color:#fff;font-size:14px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:100px; display: block;margin-left: 10px;background: #000;border-radius: 4px; height: 30px; line-height: 30px; text-align: center;padding:0 5px;margin-top:15px;margin-bottom: 5px;} .input-text {margin-bottom:0 !important;} .top_menu { height:50px; line-height: 50px; background: #fff;width:calc(100% - 200px);position: fixed;z-index: 1;top:0;left:200px;border-bottom:1px solid #eeeeee;} .top_menu a {display:block;float:right;height:50px; line-height: 50px;width:100px; text-align: center;border-left:1px solid #eeeeee;} .clear {clear:both;} .btn {margin-bottom:0;} body {line-height: 1.6 !important; overflow-x: hidden;} .left_cur a i:before ,.left_cur ul li .cur_s .title ,.left_cur .cur_tit ,li.left_cur > a:before {color:#444 !important;} .left_cur {    } .logo-env .new_logo {padding-left:36px;} .logo-env .new_logo .wq_logo {margin-left:-36px;width:28px;height: 28px;float: left;border-radius: 50%;} .logo-env .new_logo:after {clear:both;} .tool_box a span ,.tool_box a:hover span {color:#666 !important;} .left_btn_box {padding:3px 10px 0 10px;justify-content:center;display: flex;} .left_btn_box a {display:block;height: 28px; line-height: 26px;width:80px;color: #fff; text-align: center;    border-radius: 2px;} .left_btn_box a.btn_li01 {background:rgb(25, 200, 91);border-bottom-right-radius: 0; border-top-right-radius: 0;} .left_btn_box a.btn_li02 {background:rgb(0, 193, 222);border-bottom-left-radius: 0; border-top-left-radius: 0;} .left_btn_box a.btn_li01:hover {background:rgb(21, 186, 93);} .left_btn_box a.btn_li02:hover {background:rgb(2, 182, 209);} .wq_bottom_btn {position:fixed;bottom:0;left:230px;width:100%;background: #fff;justify-content:center;display: flex; height: 80px; line-height: 80px;} .sidebar-menu {min-width: 122px !important;width: 122px !important; overflow: hidden;background: #fff !important;} .main-menu-scroll{height: calc(100% - 130px);overflow-x: hidden;width: 200px;overflow-y: scroll;} .main-menu-scroll::-webkit-scrollbar {display: none;} .new_left_menu {width:180px; height: 100%;display: table-cell;position: relative;background: #fafafa;z-index: 1;border-right: 1px solid #e7e7f0;overflow: auto;} .sidebar-menu.fixed .sidebar-menu-inner {left:86px !important;border-right: 1px solid #eeeeee;} .f_name_box {display: block; height: 50px; line-height: 50px;color: #504f5c;} .f_name_box.cur_name {width: 180px} .new_left_menu a {text-decoration:none;height: 30px;line-height: 26px;margin-top: 10px;} .new_left_menu a span {font-size:12px;margin-left: 16px;} .new_left_menu a i {margin-left:18px;display:inline-block;color:#b3b3b3;} .new_left_menu a.cur_name i ,.new_left_menu a.cur_name .big_class_name {color: #503eff;} .main-menu-scroll {width:122px !important;} /*		.sidebar-menu .main-menu a {color: #444 !important;background: rgba(55, 87, 109, 0.05);}*/ .sidebar-menu .main-menu a {color: #444 !important;padding-left:20px !important;} .sidebar-menu .main-menu .cur_s a ,.sidebar-menu .main-menu .cur_s a:visited ,.sidebar-menu .main-menu .left_cur ul li.cur_s a>span{ background: rgba(255, 255, 255, 1) !important;color: #00a0e9 !important;border-right: 1px solid #eeeeee;} .title.cur_tit {color:#444 !important;font-weight: bold;} /*		.left_cur {background:#fff !important;}*/ .cur_s .sidebar-menu .main-menu a {background:#fff !important;} .sidebar-menu .main-menu ul li a {padding-left:20px !important;} /*		.left_cur ul li a {background:#fff !important;}*/ .left_cur ul li {background:#fff !important;} .sidebar-menu .main-menu {margin-top:0 !important;} .top_big_class_name { height: 50px;line-height: 50px; text-align: center;overflow: hidden;border-bottom: 1px solid;white-space: nowrap;text-overflow: ellipsis;border-bottom: 1px solid #eeeeee;font-size:13px;} .new_logo {    display: block !important;} .sidebar-menu .main-menu .left_cur ul li a>span {color:#777777 !important;} .sidebar-menu .main-menu li.has-sub>a:before {content: '\f0d7' !important;} .main-menu-scroll {height:100% !important;} .page-container {position:absolute;padding-top: 40px;box-sizing: border-box;} .new_page_top {height:44px;width:100%;position: fixed;background:#1d1a3b;border-bottom: 1px solid #2f3d5a;z-index: 999999;} .sidebar-menu.fixed .sidebar-menu-inner {top:44px !important;} .new_logo {width:30px;height:30px;float: left;margin-top:7px;margin-left:18px;border-radius: 50%;border:2px solid rgba(255,255,255,0.5);overflow:hidden;} .new_logo img {width:26px;height:26px;} .app_name {color: #fff;font-size: 18px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;width: 155px;display: block; height:40px; line-height: 40px;margin-top:2px;margin-left:8px;float:left;} .new_page_top a  ,.new_page_top a:visited {color:#fff;text-decoration: none;} .new_page_top a:hover {color: #b3b3b3;text-decoration: none;} .sidebar-menu.fixed .sidebar-menu-inner {position:fixed !important;} .new_top_right {float:right;width:180px;height:44px; line-height: 44px;} .logout_box {width:153px; height: 44px;background:url(../../yb_tuangou/core/public/images/logout_icon.png) right center no-repeat;float:left;font-size:13px;margin-left:12px;} .left_menu_box {position:fixed;width:180px;top:44px;left:0;} .back_sys {width:100px; text-align: center;color:#fff;float:left;}.f_name_box:hover{color: #504f5c;background: #f3f3f3;text-decoration: none;}.ul_style .left_cur a{color: #503eff;}.ul_style li:hover{background: #f3f3f3;}.ul_style a{color: #7f7d8e;}.ul_style li:hover a span{color: #504f5c; }.ul_style .left_cur:hover a span{color: #503eff;}.ul_style li a{margin-left: 34px;}.jt{position: absolute;right: 10px;margin-top: -14px}.ul_style li a:hover{text-decoration: none;}.f_name_box.cur_name{text-decoration: none;}

    </style>
</head>
<body class="page-body">
<div class="new_page_top">
    <div class="new_logo">
        <?php if($about['logo'] != ''): ?>
        <img src="<?php echo $about['logo']; ?>" class="wq_logo">
        <?php else: ?>
        <img src="/public/static/bast/img/wq_shop_logo.png" class="wq_logo">
        <?php endif; ?>
    </div>
    <a href="javascript:void(0);" class="app_name"><?php echo $xcx_name; ?></a>
    <div class="new_top_right">
        <div class="logout_box">
            <?php if($copyright['back_type'] == 1): ?>
                <a href="<?php echo url('login/wxapp'); ?>" class="back_sys">
                    <?php else: if(!empty($last_visit_url)): ?>
                        <a href="<?php echo $last_visit_url; ?>" class="back_sys">
                    <?php else: ?>
                        <a href="<?php echo $siteroot; ?>web/index.php?c=wxapp&a=version&do=home&version_id=<?php echo $version_id; ?>" class="back_sys">
                    <?php endif; endif; ?>
                返回系统
            </a>
            <a href="<?php echo url('login/logout'); ?>" class="right_logout">退出</a>
        </div>
        <div class="clear"></div>
    </div>
    <?php if($endtime['is_show'] ==1): ?>
    <div style="height:44px; line-height:44px;float:right;color:#b3b3b3;font-size:13px;margin-right:15px;">该账号使用有效期至 <?php echo $endtime['time']; ?>，将在<?php echo $endtime['days']; ?>天后过期，请及时付费 ！  </div>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<div class="page-container" style="border-collapse:inherit;">
    <div class="new_left_menu" >
        <div class="left_menu_box" id="top_menu">
            <ul v-for="(item, index) in list" >
                <a v-on:click="top_click(item)" href="javascript:void(0);" :class="item.class"><i>
                    <img v-if="top_mid==item.module_id" :src="'public/images/aside_icon/'+item.logo+'_p.png'" alt="" >
                    <img v-else :src="'public/images/aside_icon/'+item.logo+'_n.png'" >
                </i><span class="big_class_name" v-text="item.module_name"></span>
                    <div v-if="item.sub.length>0">
                    <img src="public/images/aside_icon/ic_menu_top.png" v-if="top_mid==item.module_id && show" alt="" class="jt">
                    <img src="public/images/aside_icon/ic_menu_bot.png" v-else alt="" class="jt">
                    </div>
                </a>
                <ul :id="'second_'+item.module_id" name="second_menu" class="ul_style">
                    <li  v-if="item.sub.length>0" v-for="(v, k) in item.sub" v-on:click="sub_click(v)" v-bind:class="{'left_cur' : v.module_id == sub_mid, 'expanded' : expanded && v.module_id == sub_mid && item.sub.length > 0 }">
                        <a href="javascript:void(0);">
                            <span class="title" v-text="v.module_name"></span>
                        </a>
                    </li>
                </ul>
            </ul>
        </div>
    </div>
    <div class="main-content">
        
<article class="cl pd-20" >
    <div id="tab_demo2" class="HuiTab" style="margin-bottom: 15px; position:relative;">
        <div class="tabBar clearfix">
            <span onclick="window.location.href='__CONF_SITE__admin/Integral/attendance'" class="current">积分签到</span>
        </div>
    </div>
    <div class="panel-body" id="main" style="display: none" v-show="show">
        <form class="form-horizontal" action="" method="POST">
            <div class="form-group col-md-12">
                <label class="col-sm-1 control-label">开启签到功能</label>
                <div class="col-sm-11">
                    <div class="col-md-12">
                        <label class="radio-inline">
                            <input type="radio" id="emailwy1"  class="kaiqi1"  :checked="is_open==1" name="is_open" v-model="is_open" value="1">
                            <label for="emailwy1">开启</label>
                        </label>
                        <label class="radio-inline">
                            <input type="radio" id="emailwy2" class="kaiqi2" name="is_open"  :checked="is_open==0" v-model="is_open" value="0">
                            <label for="emailwy2">关闭</label>
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <label class="col-sm-1 control-label">关联会员等级</label>
                <div class="col-sm-11" style="width: 200px">
                    <div class="col-md-12" style="width: 200px">
                        <label class="radio-inline">
                            <input type="radio"  class="kaiqi1" id="emailwy3" :checked="level==1" name="level" v-model="level" value="1">
                            <label for="emailwy3">开启</label>
                        </label>
                        <label class="radio-inline">
                            <input type="radio" class="kaiqi2" id="emailwy4" name="level"  :checked="level==0" v-model="level" value="0">
                            <label for="emailwy4">关闭</label>
                        </label>
                    </div>
                </div>
                <div><span style="width: 400px;height: 35px;border: 0px solid #ddd;display: inline-block;line-height: 35px;text-align: center;background: #ffffff;border-radius: 5px;color:#999;">开启关联会员等级,签到所获取的积分可用于会员等级升级！</span></div>
            </div>
            <div class="form-group col-md-12">
                <label for="inputEmail3" class="col-sm-1 control-label">首次奖励</label>
                <div class="col-sm-11">
                    <div class="col-md-5 chongzhi">
                        <div class="man4">首次奖励</div>
                        <input type="number" name="oneintegral" min="1" v-model="frist_reward"  class="ygminp inp1">
                        <div class="man">积分</div>
                    </div>
                    <div class="col-md-7 chongzhi">
                        <div class="man2">日常奖励</div>
                        <input type="number" name="sintegral" min="1" v-model="day_reward" class="money2 inp2">
                        <div class="man">积分</div>
                    </div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <label for="inputEmail3" class="col-sm-1 control-label">连签奖励</label>
                <div class="col-sm-11">
                    <div v-if="cont_reward.length>0">
                        <div class="col-md-12 yginter yginter2" v-for="(v,k) in cont_reward" style="padding: 0px;">
                            <div class="col-md-5 chongzhi">
                                <div class="man4">签到</div>
                                <input type="number" name="day" min="2" v-model="v.date" class="ygminp inp1">
                                <div class="man">天</div>
                            </div>
                            <div class="col-md-7 chongzhi">
                                <div class="man2">奖励</div>
                                <input type="number" name="integral" min="1" v-model="v.reward" class="money2 inp2">
                                <!--<div class="man" style="position: fixed;">积分</div>-->
                                <div class="man">积分</div>
                                <div id="del6" data-id="6" @click="del_cont(k)" class="man shanchu shanchu6"><span class="fa fa-times"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-5" style="margin-left:-90px;">
                        <div class="tianj1 special2 col-md-6 col-md-push-3" @click="add_cont"><span class="fa fa-plus"></span>添加一个连签奖励规则
                        </div>
                    </div>

                </div>
            </div>

            <div class="form-group col-md-12">
                <label for="inputEmail3" class="col-sm-1 control-label">特殊奖励</label>
                <div class="col-sm-11">
                    <div class="col-md-12 yginter" id="addhang">

                        <div class="col-md-2 ygtime" style="margin-left:20px;">
                            <div class="input-group datetime">
                                            <span class="input-group-btn">
                                                <span class="btn btn-default">日期</span>
                                            </span>
                                <input type="text" id="datetimepicker" onfocus="WdatePicker()" :value="other.date" placeholder="请选择日期时间" name="star_time" readonly="readonly" class="datetimepicker form-control" style="margin-left: 10px;height: 32px;line-height: 32px;text-align: center;margin-bottom:3px;">
                            </div>
                        </div>

                        <!--<div class="col-md-10 chongzhi" style="width: 400px;margin-left: 23px;margin-top: 2px">-->
                        <div class="col-md-10 chongzhi">
                            <div class="man3">标题</div>
                            <input type="text" name="" v-model="other.title" placeholder="非必填" class="titleinp" style="width:190px;">
                            <div class="man3">奖励</div>
                            <input type="number" name="integral2" v-model="other.reward" class="titleinp3 inp2">
                            <div class="man">积分</div>
                        </div>
                    </div>


                </div>
            </div>
            <div class="col-md-12"></div>
            <div class="form-group col-md-12">
                <input type="button" name="button" onclick="integral_add()" value="提交"  class="btn col-lg-3 col-lg-offset-3" style="color: white;background-color: #44ABF7;">
            </div>

        </form></div>
</article>

    </div>

    <footer class="footer" style="background: #FFFFFF;height: 25px;margin-top: -5px;padding-top: 10px;line-height: 25px;">
        <!--<p><?php echo $copyright['content']; ?></p>-->
        <?php if($show_we7): ?>
        <div class="container-fluid footer text-center" role="footer">
            <div class="friend-link" >
                <?php if(empty($_W['footerright'])): ?>
                <a href="http://www.we7.cc">微信开发</a>
                <a href="http://s.we7.cc">微信应用</a>
                <a href="http://bbs.we7.cc">微擎论坛</a>
                <a href="http://s.we7.cc">联系客服</a>
                <?php else: ?>
                <?php echo $_W['footerright']; endif; ?>
            </div>
            <div class="copyright"><?php if(empty($_W['footerleft'])): ?>Powered by <a href="http://www.we7.cc"><b>微擎</b></a> v<?php echo $version; ?> &copy; 2014-2015 <a href="http://www.we7.cc">www.we7.cc</a><?php else: ?><?php echo $_W['footerleft']; endif; ?></div>
            <?php if(!empty($_W['icp'])): ?><div>备案号：<a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $_W['icp']; ?></a></div><?php endif; ?>
        </div>
        <?php if(!empty($_W['statcode'])): ?><?php echo $_W['statcode']; endif; if(!empty($_GPC) && !in_array($_GPC, array('keyword', 'special', 'welcome', 'default', 'userapi')) || defined('IN_MODULE')): ?>
        <script>
            if(typeof $.fn.tooltip != 'function' || typeof $.fn.tab != 'function' || typeof $.fn.modal != 'function' || typeof $.fn.dropdown != 'function') {  require(['bootstrap']);}
        </script>
        <?php endif; endif; ?>
    </footer>
</div>
<script src="/public/static/bast/xenon-custom.js"></script>
<script src="/public/static/bast/clipboard.js"></script>
<script src="/public/static/bast/TweenMax.min.js"></script>
<script src="/public/static/bast/resizeable.js"></script>
<script src="/public/static/layer/2.4/layer.js"></script>
<script src="/public/js/public_js.js"></script>
<script src="/public/js/all.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>

<script type="text/javascript">
    var flag = false;//防止重复提交1
    function verify( frist_reward,day_reward) {
        if(parseInt(frist_reward)<1){
            layer.msg('首签奖励不小于1',{icon:5,time:1000});
            return false;
        }
        if(parseInt(day_reward)<1){
            layer.msg('日常奖励不小于1',{icon:5,time:1000});
            return false;
        }
        return true;
    }
    function integral_add(){
        if (verify(vm.frist_reward,vm.day_reward) && !flag) {
            flag = true;
            var date_val=$('#datetimepicker').val();
            console.log(date_val)
            if(date_val){
                Vue.set(vm.other, "date", date_val);
            }
            console.log(vm.other);
            $.ajax({
                type : "post",
                url : "<?php echo url('integral/attendance'); ?>",
                data : {
                    'cont_reward' : JSON.stringify(vm.cont_reward),
                    'is_open' : vm.is_open,
                    'level':vm.level,
                    'frist_reward' : vm.frist_reward,
                    'day_reward' : vm.day_reward,
                    'other':JSON.stringify(vm.other),
                },
                success : function(data) {
                    flag = false;
                    if (data> 0) {
                        layer.msg('操作成功',{icon:1,time:1000},function () {
                            //window.location.reload();
                        });
                    }else{
                        layer.msg('操作失败', {icon: 2, time: 1000});
                    }
                }
            });
        }
    }
    var vm = new Vue({
        el: '#main',
        data: {
            is_open: 0,
            level:0,
            frist_reward:1,
            day_reward: 1,
            cont_reward:[],
            other:{'date':'','title':'','reward':0},
            show: false
        },
        created: function () {
            var that = this;
            that.show = true;
            if('<?php echo $info['cont_reward']; ?>'.length>0) {
                that.cont_reward = JSON.parse('<?php echo $info['cont_reward']; ?>');
            }
            that.day_reward='<?php echo (isset($info['day_reward']) && ($info['day_reward'] !== '')?$info['day_reward']:1); ?>';
            that.frist_reward='<?php echo (isset($info['frist_reward']) && ($info['frist_reward'] !== '')?$info['frist_reward']:1); ?>';
            that.is_open='<?php echo (isset($info['is_open']) && ($info['is_open'] !== '')?$info['is_open']:0); ?>';
            that.level='<?php echo (isset($info['level']) && ($info['level'] !== '')?$info['level']:0); ?>';
            if('<?php echo $info['other']; ?>'){
                that.other=JSON.parse('<?php echo $info['other']; ?>');
                console.log(that.other)
            }
        },
        methods: {
            add_cont:function(){
             var that=this;
                console.log(that.cont_reward);
                console.log(that.other);
                that.cont_reward = that.cont_reward.concat([{'date':2,'reward':1}]);
            },
            del_cont:function(index){
                var that=this,arr=that.cont_reward,new_arr=[];
                for(var s=0;s<arr.length;s++){
                    if(s!=index){
                        new_arr.push(arr[s]);
                    }
                }
                that.cont_reward=new_arr;
            }

        }
    });

</script>

<script>
    var str;
    str = '<?php echo json_encode($all_menu); ?>';
    var all_menu = eval(decodeURIComponent(str));
    var root_url = "<?php global $_W; echo $_W['siteroot'].'addons/yb_tuangou/core/index.php?s=/admin/'; ?>";
    var top_mid = '<?php echo $top_mid; ?>';
    var sub_mid = '<?php echo $sub_mid; ?>';
    var three_mid = '<?php echo $three_mid; ?>';
    var sub_menu_arr = [];
    $(document).ready(function () {
        $("ul[name=second_menu]").hide();
        if(top_mid>0){
            $("#second_"+top_mid).show();
        }
    });
    all_menu.forEach(function (item, index) {
        if(item.module_id == top_mid)
        {
            item.class = 'f_name_box cur_name';
            sub_menu_arr = item.sub? item.sub : [];
        }
        else
        {
            item.class = 'f_name_box';
        }
    });
    var top_menu = new Vue({
        el: '#top_menu',
        data: {
            list:all_menu,
            top_mid: top_mid,
            root_url : root_url,
            sub_mid: sub_mid,
            three_mid: three_mid,
            expanded:sub_mid > 0,
            show:true,
        },
        methods:{
            top_click:function (top_item) {
                if(this.top_mid != top_item.module_id)
                {
                    this.show=true;
                    var sub_menu=this;
                    $("ul[name=second_menu]").hide();
                    $("#second_"+top_item.module_id).show();
                    var val = top_item.module_id;
                    this.top_mid = val;
                    sub_menu.expanded = false;
                    document.cookie = "top_mid=" + val;
                    if(top_item.sub.length > 0)
                    {
                        this.list.forEach(function (item, index) {
                            if(item.module_id == val)
                            {
                                item.class = 'f_name_box cur_name';
//                                sub_menu.list = item.sub;
                                sub_menu.sub_mid = 0;
                                sub_menu.three_mid = 0;
                                if(sub_menu.list != null && sub_menu.list != undefined)
                                {
                                    if(sub_menu.list.length > 0)
                                    {
                                        sub_menu.expanded = true;
                                        sub_menu.sub_mid = sub_menu.list[0]['module_id'];
                                    }
                                }
                            }
                            else
                            {
                                item.class = 'f_name_box';
                            }
                        });
                    }
                    else
                    {
                        window.location.href = this.root_url+top_item.url;
                    }
                }else {
                    this.show=!this.show;
                    $("ul[name=second_menu]").hide();
                    if(this.show){
                        $("#second_"+top_item.module_id).show();
                    }
                }
            },
            sub_click: function (item) {
                this.expanded = this.sub_mid == item.module_id ? !this.expanded : true;
                this.sub_mid = item.module_id;
                document.cookie = "sub_mid=" + item.module_id;
                if(item.sub.length == 0)
                {
                    window.location.href = this.root_url+item.url;
                }
            },
            three_click: function (item) {
                this.three_mid = item.module_id;
                document.cookie = "three_mid=" + item.module_id;
                window.location.href = this.root_url+item.url;
            }
        },
    });
</script>
</body>
</html>