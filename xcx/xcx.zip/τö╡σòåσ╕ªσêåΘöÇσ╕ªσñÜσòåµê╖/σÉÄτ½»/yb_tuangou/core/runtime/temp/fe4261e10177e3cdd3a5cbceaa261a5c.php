<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:81:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/arliki/comment_message.html";i:1548042145;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/noue.html";i:1545994004;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
<script src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/js/vue.js"></script>
<link href="./favicon.ico?v=1.2" rel="shortcut icon" type="image/x-icon"/>
<link rel="stylesheet" href="/public/css/linecons.css">
<link rel="stylesheet" href="/public/static/bast/bootstrap.css">
<link rel="stylesheet" href="/public/static/bast/xenon-core.css?v=1.0">
<link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css"/>
<link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
<link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
<link rel="stylesheet" type="text/css" href="/public/css/dashboard.css">
<link rel="stylesheet" type="text/css" href="/public/css/yb_index.css?v=1.0"/>
<link rel="stylesheet" href="/public/css/new_index.css">
<link rel="stylesheet" type="text/css" href="/public/css/defau.css">
<script src="/public/static/layer/2.4/layer.js"></script>
</head>
<div id="newks2"></div>
<script src="/public/menu/js/jquery.artdialog.js"></script>
<script src="/public/menu/js/iframetools.js"></script>
<script src="/public/js/public_js.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>
<script>
    var UM_SITE_ROOT = '__CONF_SITE__';
</script>
<script src="/public/js/all.js"></script>

<style>
    .row {height: 32px !important; line-height: 32px !important;}
    .upload-thumb img{max-width: 150px;}
    .formControls {display: block !important;}
    .formControls select { height: 30px; line-height: 30px; border: 1px solid #ddd;}
</style>
<article class="cl pd-20">
    <form action="" method="post" class="form form-horizontal" id="my_bargain">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>评论人：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input id="name" type="text" autocomplete="off" v-model="name" value="" class="input-text">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>评论内容：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <textarea name="info" id="info" cols="80" rows="5"><?php echo (isset($info['info']) && ($info['info'] !== '')?$info['info']:""); ?></textarea>
            </div>
        </div>
        <!--<div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <input type="hidden" value="<?php echo $info['supplier_id']; ?>" id="id">
                <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button" value="提交">
            </div>
        </div>-->
    </form>
</article>
<script src="/public/menu/js/jquery.artdialog.js"></script>
<script src="/public/menu/js/iframetools.js"></script>
<script type="text/javascript">
    var bannerVM = new Vue({
        el: '#my_bargain',
        data: {
            supplier_name: "<?php echo (isset($info['supplier_name']) && ($info['supplier_name'] !== '')?$info['supplier_name']:''); ?>",
            name:"<?php echo (isset($info['name']) && ($info['name'] !== '')?$info['name']:''); ?>",
            tel:"<?php echo (isset($info['tel']) && ($info['tel'] !== '')?$info['tel']:''); ?>",
            address:"<?php echo (isset($info['address']) && ($info['address'] !== '')?$info['address']:''); ?>",
            pic:"<?php echo (isset($info['logo']) && ($info['logo'] !== '')?$info['logo']:''); ?>"
        }
    });


</script>
</html>