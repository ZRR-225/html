<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/order/order_msg.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
</head>
<body>
<div class="modal-body">
   <textarea class="textarea radius" id="memo" placeholder="请填写备注信息"><?php echo $res; ?></textarea>
    <div style="clear:both;"></div>
</div>
<div class="modal-footer">
    <input type="hidden" id="order_id" value="<?php echo $order_id; ?>">
    <button class="btn btn-primary" onclick="addMemoAjax()">提交更改</button>
    <button class="btn" onclick="shut_down()">关闭</button>
</div>
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script>
    //关闭
    function shut_down() {
        parent.layer.closeAll();
    }
    //修改备注
    function addMemoAjax(){
        var order_id = $("#order_id").val();
        var memo = $("#memo").val();
        $.ajax({
            url: "<?php echo url('order/addmemo'); ?>",
            data: { "order_id": order_id,"memo":memo },
            type : "post",
            success: function(data) {
                if (data.code > 0) {
                    layer.msg("添加成功", {icon: 1, time: 1000},function () {
                        window.parent.location.reload();
                    });
                }else{
                    layer.msg("添加失败", {icon: 2, time: 1000});
                }
            }
        });
    }
</script>
</body>
</html>