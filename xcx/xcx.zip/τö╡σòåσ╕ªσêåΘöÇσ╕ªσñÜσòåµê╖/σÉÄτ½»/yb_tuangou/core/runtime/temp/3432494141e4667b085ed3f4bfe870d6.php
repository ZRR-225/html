<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/role/role_edit.html";i:1547903355;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.admin.css"/>
    <style>
        .permission-list>dd>dl>dd {
            margin-left: 80px;
            display: flex;
            flex-direction: column;
            width: 200px;
            line-height: 27px;
        }

        .formControls {display: block !important;}
    </style>
</head>
<body>
<div class="Hui-article">
    <article class="cl pd-20">
        <form action="" method="post" class="form form-horizontal" id="form-admin-role-add">
            <div class="row cl">
                <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>用户组名称：</label>
                <div class="formControls col-xs-8 col-sm-9">
                    <input type="text" class="input-text" value="<?php echo $info['role_name']; ?>" placeholder="" id="role_name" >
                </div>
            </div>
            <div class="row cl">
                <label class="form-label col-xs-4 col-sm-3">描述：</label>
                <div class="formControls col-xs-8 col-sm-9">
                    <input type="text" class="input-text" value="<?php echo $info['info']; ?>" placeholder="" id="info">
                </div>
            </div>
            <div class="row cl">
                <label class="form-label col-xs-4 col-sm-3">权限：</label>
                <div class="formControls col-xs-8 col-sm-9">
                    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $key=>$vo): ?>
                    <dl class="permission-list">
                        <dt>
                            <label>
                                <input <?php if(in_array(($vo['module_id']), is_array($info['module_id_array'])?$info['module_id_array']:explode(',',$info['module_id_array']))): ?> checked <?php endif; ?> type="checkbox" onclick="step_cut('<?php echo $vo['module_id']; ?>');" value="<?php echo $vo['module_id']; ?>" name="user-Character" data-id="<?php echo $vo['module_id']; ?>">
                                <?php echo $vo['module_name']; ?>
                            </label>
                        </dt>
                        <dd>
                            <?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): if( count($vo['child'])==0 ) : echo "" ;else: foreach($vo['child'] as $key=>$per): ?>
                            <dl class="cl permission-list2">
                                <dt>
                                    <label class="">
                                        <input data-topid="<?php echo $vo['module_id']; ?>" data-id="<?php echo $per['module_id']; ?>" <?php if(in_array(($per['module_id']), is_array($info['module_id_array'])?$info['module_id_array']:explode(',',$info['module_id_array']))): ?> checked <?php endif; ?> onclick="stub_cut('<?php echo $vo['module_id']; ?>','<?php echo $per['module_id']; ?>');" type="checkbox" value="<?php echo $per['module_id']; ?>" name="user-Character">
                                        <?php echo $per['module_name']; ?></label>
                                </dt>
                                <dd>
                                    <?php if(is_array($per['child']) || $per['child'] instanceof \think\Collection || $per['child'] instanceof \think\Paginator): if( count($per['child'])==0 ) : echo "" ;else: foreach($per['child'] as $key=>$three): ?>
                                    <label class="">
                                        <input type="checkbox" <?php if(in_array(($three['module_id']), is_array($info['module_id_array'])?$info['module_id_array']:explode(',',$info['module_id_array']))): ?> checked <?php endif; ?> value="<?php echo $three['module_id']; ?>" name="user-Character" onclick="three_cut('<?php echo $vo['module_id']; ?>','<?php echo $per['module_id']; ?>','<?php echo $three['module_id']; ?>');" data-topid="<?php echo $vo['module_id']; ?>" data-subid="<?php echo $per['module_id']; ?>" data-id="<?php echo $three['module_id']; ?>">
                                        <?php echo $three['module_name']; ?></label>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </dd>
                            </dl>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </dd>
                    </dl>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <div class="row cl">
                <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                    <button type="button" onclick="add_RoleManage()" class="btn btn-success radius" id="admin-role-save" name="admin-role-save"><i class="icon-ok"></i> 确定</button>
                </div>
            </div>
        </form>
    </article>
</div>
<input type="hidden" id="id" value="<?php echo $info['role_id']; ?>">
<script src="/public/js/jquery-2.1.1.js"></script>
<script src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    function step_cut(id) {
        var topid = "input[data-id=" + id + "]";
        var subid = "input[data-topid=" + id + "]";
        if($(topid).prop('checked')){
            $(subid).prop('checked',true);
        }else{
            $(subid).prop('checked',false);
        }
    }
    function stub_cut(id,selfid) {
        var topid = "input[data-id=" + id + "]";
        var subid = "input[data-subid=" + selfid + "]";
        var self = "input[data-id=" + selfid + "]";
        if($(self).prop('checked')){
            $(topid).prop('checked',true);
            $(subid).prop('checked',true);
        }else{
            $(subid).prop('checked',false);
            var tid = "input[data-topid=" + id + "]";
            var i = 0;
            $(tid).each(function () {
                if($(this).prop('checked')){
                    i++;
                }
            });
            if(i>0){
                $(topid).prop('checked',true);
            }else{
                $(topid).prop('checked',false);
            }
        }
    }
    function three_cut(top,sub,three) {
        var topid = "input[data-topid=" + top + "]";
        var subid = "input[data-subid=" + sub + "]";
        var self = "input[data-id=" + three + "]";
        var i = 0;
        $(subid).each(function () {
            if($(this).prop('checked')){
                i++;
            }
        });
        var subck = "input[data-id=" + sub + "]";
        if(i > 0)
        {
            $(subck).prop('checked',true);
        }
        else
        {
            $(subck).prop('checked',false);
        }
        i = 0;
        $(topid).each(function () {
            if($(this).prop('checked')){
                i++;
            }
        });
        var topck = "input[data-id=" + top + "]";
        if(i>0){
            $(topck).prop('checked',true);
        }else{
            $(topck).prop('checked',false);
        }
    }
    var lock = false;
    //添加
    function add_RoleManage() {
        var di=[];
        $("[name='user-Character']:checked").each(function(index,el){   //获取选中的值
            di.push($(el).val());
        });
        var role_name=$("#role_name").val();
        var info=$("#info").val();
        var id=$("#id").val();
        if (role_name==''){
            layer.msg('请输入用户组名称！',{icon:5,time:1000});
            return false;
        }
          if (di.length==0){
              layer.msg('请选择权限！',{icon:5,time:1000});
              return false;
          }
          var str='';
          for(var i=0;i<di.length;i++){
              str+=di[i]+",";
          }
          str= str.substr(0, str.length - 1);
        if(!lock){
            lock = true;
            $.ajax({
                url : "<?php echo url('role/role_edit_do'); ?>",
                type : "post",
                data : {
                    "role_name" : role_name,
                    "info" : info,
                    "str":str,
                    'id':id
                },
                success : function(res) {
                    if(res['code']>0){
                        layer.msg('修改成功!',{icon:1,time:1000},function () {
                            window.parent.location.reload();
                        });
                    }
                    else{
                        layer.msg('修改失败！',{icon:5,time:1000});
                        lock = false;
                    }
                }
            })
        }
    }
</script>
</body>
</html>