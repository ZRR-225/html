<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/bargain/return_goods_list.html";i:1548038875;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/style.css?v=1.3" />
    <link media="all" href="/public/menu/css/article.css" type="text/css" rel="stylesheet">
<style>
	td a:hover {background-color: rgb(13, 163, 249);color:#fff;border:1px solid rgb(13, 163, 249);}
	</style>
</head>
<body style="background-color: rgb(255, 255, 255);">
<div class="jbox-container" style="float: left; padding: 0px;">
    <ul class="gagp-goodslist" style="padding: 10px; width: 750px;">
        <!-- 栏目分类 -->
        <table class="wxtables">
            <colgroup>
                <col width="10%"><col width="15%"><col width="20%"><col width="25%"><col width="15%">
            </colgroup>
            <thead>
            <tr style="background-color: rgb(13, 163, 249);">
                <td>ID</td>
                <td>图片</td>
                <td>名称</td>
                <td style="text-align: center;">发布时间</td>
                <td style="text-align: center;">操作</td>
            </tr>
            </thead>
            <tbody>
            <?php if(is_array($goods) || $goods instanceof \think\Collection || $goods instanceof \think\Paginator): $i = 0; $__LIST__ = $goods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <tr>
                    <td><p><?php echo $vo['goods_id']; ?></p></td>
                    <td><p><img src="<?php echo $vo['img_cover']; ?>" alt="" height="50px" width="50px"></p></td>
                    <td><p><?php echo $vo['goods_name']; ?></p></td>
                    <td style="text-align: center;"><p><?php echo date('Y-m-d H:i:s',$vo['create_time']); ?></p></td>
                    <td style="text-align: center;">
                        <a style="border-radius: 2px;" a href="javascript:void(0);"  onclick="run(<?php echo $vo['goods_id']; ?>)" class="btn selecta sure">选择</a>
                    </td>
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>
        <div class="n_page_no">
            <?php echo $goods->render(); ?>
        </div>
        <input type="hidden" id="goods_id" value="" />
    </ul>
</div>
<div style="height:80px; line-height: 80px;color:#fff; clear: both;">壹佰小程序占位</div>
<!--<div class="sel_fun_opt" style="position: fixed; bottom: 0px;background: #fff;height: 60px;width:100%;border-top:1px solid #eeeeee;padding-top:20px;">-->
    <!--<div class="sure" onclick="">确定</div>-->
    <!--<div class="cancel" onclick="">返回</div>-->
<!--</div>-->
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    function run ($goods_id)
    {    
        $('#goods_id').val($goods_id);
    }
    $(".selecta").click(function(){
        if ($(this).hasClass('selectedb')) {
        }else{
            $(this).addClass('selectedb');
            $(this).html('已选择');
            $(this).parent().parent().siblings().find('.selecta').removeClass('selectedb');
            $(this).parent().parent().siblings().find('.selecta').html('选择');
        }
    });
    $(".sure").click(function(){
        var good_id = $('#goods_id').val();
        if (good_id == ''){
                layer.msg('请选择内容',{icon:5,time:1000});
                return false;
        }
        parent.select_normal_goods(good_id); //向父窗口赋值
        var index = parent.layer.getFrameIndex(window.name);
        parent.layer.close(index);
    })
    $(".cancel").click(function(){
        var index = parent.layer.getFrameIndex(window.name);
        parent.layer.close(index);
    });
</script>
</body>
</html>
