<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/arliki/exp_load.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css"/>
</head>
<style type="text/css">
	input {
		vertical-align: initial;
	}
	.table input[type="text"], input[type="password"], input.text, input.password {
		font: 12px/20px Arial;
		color: #777;
		background-color: #FFF;
		vertical-align: baseline;
		margin-bottom: 0px;
	}
	.set-style dl dt {
		text-align: left;
		width: 7%;
	}
	.attr-choose-wrap label, .relate-norm label {
		cursor: pointer;
		float: left;
		margin: 0 15px 10px 0;
		padding: 0 10px;
		color: #636363;
		line-height: 28px;
	}
	.attr-choose-wrap label.current, .relate-norm label.current {
		color: #636363;
		background: url(../images/icon_choose.gif) no-repeat right bottom;
	}
	td {font-size:13px;}
</style>
<body>
<div class="Hui-article">
	<article class="cl" style="padding:0 10px !important;">
		<table class="table table-border table-bordered table-hover table-bg">
			<thead>
			<tr class="text-c">
				<th>时间</th>
				<th>状态</th>
			</tr>
			</thead>
			<tbody id="tbody">
			<?php if($code==1): ?>
			<tr>
				<td  colspan="2" style="text-align: left;">当前:<span style="color:#ff0000;"><?php echo $list["state"]; ?></span></td>
			</tr>
				<?php if(is_array($list['data']) || $list['data'] instanceof \think\Collection || $list['data'] instanceof \think\Paginator): if( count($list['data'])==0 ) : echo "" ;else: foreach($list['data'] as $k=>$vo): ?>
				<tr class="text-c">
					<td><?php echo $vo['ftime']; ?></td>
					<td style="text-align: left;"><?php echo $vo['context']; ?></td>
				</tr>
				<?php endforeach; endif; else: echo "" ;endif; else: ?>
			<p><?php echo $list['data']; ?></p>
			<?php endif; ?>
			</tbody>
		</table>
	</article>
</div>
</body>
</html>