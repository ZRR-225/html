<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/arliki/comment_edit.html";i:1546838434;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="/public/css/defau.css">
</head>
<style>
    input[type="checkbox"] + label::before {
        content: "\a0";  /*不换行空格*/
        display: inline-block;
        vertical-align: .2em;
        height: 18px;
        width: 18px;
        font-size: 22px;
        margin-right: .2em;
        border-radius: .2em;
        background-color: white;
        border: 1px solid #93a1a1;
        text-indent: .15em;
        line-height: .65;  /*行高不加单位，子元素将继承数字乘以自身字体尺寸而非父元素行高*/
    }
</style>
<body>
<article class="cl pd-20">
    <form action="" method="post" class="form form-horizontal" id="">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3">备注：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <textarea name="com" cols="" rows="" id="com" class="textarea" placeholder="说点什么...100个字符以内" maxlength="100"><?php echo $data['seller_comments']; ?></textarea>
            </div>
        </div>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button"
                       value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
        <input id="id" type="hidden" value="<?php echo $data['id']; ?>">
    </form>
</article>
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    function addSuppAjax() {
        var comss = $("#com").val();
        var id = $("#id").val();
            $.ajax({
                type : "post",
                url : "<?php echo url('arliki/update_comment'); ?>",
                data : {
                    'com':comss,
                    'id' :id
                },
                success : function(data) {
                    if (data== '2') {
                        layer.msg('操作成功',{icon:1,time:1000},function () {
                            window.parent.location.href="<?php echo url('arliki/tuan_list'); ?>";
                        });
                    }else{
                        layer.msg('操作失败', {icon: 2, time: 1000});
                    }
                }
            });
    }
</script>
</body>
</html>