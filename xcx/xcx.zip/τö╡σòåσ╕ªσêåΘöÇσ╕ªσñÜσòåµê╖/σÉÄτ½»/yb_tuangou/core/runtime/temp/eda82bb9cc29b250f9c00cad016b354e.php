<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/activity/coupon_user_list.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
</head>
<body>
<article class="cl pd-20" id="html">
    <div class="cl pd-5 bg-1 bk-gray">
        <form class="Huiform" method="post" action="__CONF_SITE__admin/activity/together_user_list" target="_self" style="padding:15px;">
            <div class="text-c"> 核销码：
                <input type="text" class="input-text" value="<?php echo $search_text; ?>" style="width:250px" placeholder="输入核销码"  name="search_text">
                <input type="hidden" value="<?php echo $id; ?>" name="id">
                <button type="submit" class="btn btn-search radius"  name="">
<!--                <i class="Hui-iconfont">&#xe665;</i>-->
                搜索</button>
            </div>
        </form>
    </div>
    <form action="" method="post" class="form form-horizontal">
        <table class="table table-border table-bordered table-hover">
            <tr class="text-c">
                <th>用户名</th>
                <th>领取时间</th>
                <th>活动结束时间</th>
                <th>核销码</th>
                <th>状态</th>
                <th>使用时间</th>
                <th>操作</th>
            </tr>
            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?>
            <tr class="text-c va-m">
                <td><?php echo $r['nick_name']; ?></td>
                <td><?php echo date("Y-m-d H:i:s",$r['get_time']); ?></td>
                <td><?php echo date("Y-m-d H:i:s",$end_time); ?></td>
                <td><?php echo $r['key']; ?></td>
                <td>
                    <?php if($r['status']==0): ?>
                    <span class="label label-default radius">未使用</span>
                    <?php else: ?>
                    <span class="label label-warning radius">已使用</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($r['status']==1): ?>
                        <?php echo date("Y-m-d H:i:s",$r['use_time']); else: ?>
                    -
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($r['status']==0): ?>
                        <input onclick="activity_stop(this,'<?php echo $r['id']; ?>')" class="btn btn-success radius size-S" type="button" value="核销">
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
    </form>
</article>
<div class="n_page_no">
    <?php echo $page; ?>
</div>
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    /*活动-核销*/
    function activity_stop(obj,id){
        layer.confirm('确认要核销吗？',function(index){
            //后台处理
            $.ajax({
                type : "post",
                url : "<?php echo url('Activity/coupon_user_hx'); ?>",
                data : {
                    "id" : id,
                },
                success : function(data) {
                    if (data['code'] > 0) {
                        layer.msg('已核销!',{icon: 1,time:1000},function () {
                            window.location.reload();
                        });
                    }else{
                        layer.msg(data['message'], {icon: 2, time: 1000});
                    }
                }
            })
        });
    }
</script>
</body>
</html>