<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/role/permission_edit.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.admin.css"/>
</head>
<body>
<div class="Hui-article">
    <article class="cl pd-20">
        <form action="" method="post" class="form form-horizontal" id="form-admin-role-add">
            <div class="row cl">
                <label class="form-label col-xs-4 col-sm-3">设置权限：</label>
                <select style="height: 32px;  width: 63%;" class="select" size="1" id="role_id">
                    <?php if(is_array($role_list) || $role_list instanceof \think\Collection || $role_list instanceof \think\Paginator): $i = 0; $__LIST__ = $role_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?>
                    <option value="<?php echo $r['role_id']; ?>" <?php if($permission['role_id'] == $r['role_id']): ?>selected<?php endif; ?>><?php echo $r['role_name']; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
            <?php if($permission!=-1): ?>
            <div class="row cl" >
                <label class="form-label col-xs-4 col-sm-3">是否显示版权信息：</label>
                <select style="height: 32px;  width: 63%;" class="select" size="1" id="is_show_copyright">
                    <option value="0" <?php if($permission['is_show_copyright'] == 0): ?>selected<?php endif; ?>>显示</option>
                    <option value="1" <?php if($permission['is_show_copyright'] == 1): ?>selected<?php endif; ?>>不显示</option>
                </select>
            </div>
            <?php endif; ?>
            <div class="row cl">
                <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3" style="padding-left: 0;">
                    <button type="button" onclick="add_RoleManage()" class="btn btn-success radius" id="admin-role-save" name="admin-role-save"><i class="icon-ok"></i> 确定</button>
                </div>
            </div>
        </form>
    </article>
</div>
<input type="hidden" value="<?php echo $uid; ?>" id="uid">
<script src="/public/js/jquery-2.1.1.js"></script>
<script src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    var lock = false;
    //添加
    function add_RoleManage() {
        var role_id=$("#role_id").val();
        var is_show_copyright=$("#is_show_copyright").val();
        var uid=$("#uid").val();
        if(!lock){
            lock = true;
            $.ajax({
                url : "<?php echo url('role/permission_edit_do'); ?>",
                type : "post",
                data : {
                    "role_id" : role_id,
                    "uid" : uid,
                    'is_show_copyright':is_show_copyright
                },
                success : function(res) {
                    if(res['code']>0){
                        layer.msg('添加成功!',{icon:1,time:1000},function () {
                            window.parent.location.reload();
                        });
                    }
                    else{
                        layer.msg('添加失败！',{icon:5,time:1000});
                        lock = false;
                    }
                }
            })
        }
    }
</script>
</body>
</html>