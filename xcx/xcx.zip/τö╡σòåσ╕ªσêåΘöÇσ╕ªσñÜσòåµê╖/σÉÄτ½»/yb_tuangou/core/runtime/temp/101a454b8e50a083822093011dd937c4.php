<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:77:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/order/order_detail.html";i:1552112108;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/base.html";i:1550644207;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
    <script src="/public/js/jquery-2.1.1.js"></script>
    <script type="text/javascript" src="/public/js/vue.js"></script>
    <link href="./favicon.ico?v=<?php echo time(); ?>" rel="shortcut icon" type="image/x-icon"/>
    <link rel="stylesheet" href="/public/css/linecons.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/bast/bootstrap.css">
    <link rel="stylesheet" href="/public/static/bast/xenon-core.css">
    <link rel="stylesheet" href="/public/static/bast/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css?v=1.1"/>
    <link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
    <link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
    <script src="/public/js/all.js"></script>
    <script>
        var UM_SITE_ROOT = '__CONF_SITE__';
    </script>
    
<link rel="stylesheet" type="text/css" href="/public/css/order.css">
<style>
    .silider-express{padding-left: 10px;background: #fff;font-size: 12px;}
    .logistics-tracking{padding-left:5px;}
    .popover-content{width:700px;}
    .popover{max-width:900px;}

	.n_tab_line a {padding: 0 20px;}
</style>

    <style>.new_logo .logo-expanded {color:#fff;font-size:14px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:100px; display: block;margin-left: 10px;background: #000;border-radius: 4px; height: 30px; line-height: 30px; text-align: center;padding:0 5px;margin-top:15px;margin-bottom: 5px;} .input-text {margin-bottom:0 !important;} .top_menu { height:50px; line-height: 50px; background: #fff;width:calc(100% - 200px);position: fixed;z-index: 1;top:0;left:200px;border-bottom:1px solid #eeeeee;} .top_menu a {display:block;float:right;height:50px; line-height: 50px;width:100px; text-align: center;border-left:1px solid #eeeeee;} .clear {clear:both;} .btn {margin-bottom:0;} body {line-height: 1.6 !important; overflow-x: hidden;} .left_cur a i:before ,.left_cur ul li .cur_s .title ,.left_cur .cur_tit ,li.left_cur > a:before {color:#444 !important;} .left_cur {    } .logo-env .new_logo {padding-left:36px;} .logo-env .new_logo .wq_logo {margin-left:-36px;width:28px;height: 28px;float: left;border-radius: 50%;} .logo-env .new_logo:after {clear:both;} .tool_box a span ,.tool_box a:hover span {color:#666 !important;} .left_btn_box {padding:3px 10px 0 10px;justify-content:center;display: flex;} .left_btn_box a {display:block;height: 28px; line-height: 26px;width:80px;color: #fff; text-align: center;    border-radius: 2px;} .left_btn_box a.btn_li01 {background:rgb(25, 200, 91);border-bottom-right-radius: 0; border-top-right-radius: 0;} .left_btn_box a.btn_li02 {background:rgb(0, 193, 222);border-bottom-left-radius: 0; border-top-left-radius: 0;} .left_btn_box a.btn_li01:hover {background:rgb(21, 186, 93);} .left_btn_box a.btn_li02:hover {background:rgb(2, 182, 209);} .wq_bottom_btn {position:fixed;bottom:0;left:230px;width:100%;background: #fff;justify-content:center;display: flex; height: 80px; line-height: 80px;} .sidebar-menu {min-width: 122px !important;width: 122px !important; overflow: hidden;background: #fff !important;} .main-menu-scroll{height: calc(100% - 130px);overflow-x: hidden;width: 200px;overflow-y: scroll;} .main-menu-scroll::-webkit-scrollbar {display: none;} .new_left_menu {width:180px; height: 100%;display: table-cell;position: relative;background: #fafafa;z-index: 1;border-right: 1px solid #e7e7f0;overflow: auto;} .sidebar-menu.fixed .sidebar-menu-inner {left:86px !important;border-right: 1px solid #eeeeee;} .f_name_box {display: block; height: 50px; line-height: 50px;color: #504f5c;} .f_name_box.cur_name {width: 180px} .new_left_menu a {text-decoration:none;height: 30px;line-height: 26px;margin-top: 10px;} .new_left_menu a span {font-size:12px;margin-left: 16px;} .new_left_menu a i {margin-left:18px;display:inline-block;color:#b3b3b3;} .new_left_menu a.cur_name i ,.new_left_menu a.cur_name .big_class_name {color: #503eff;} .main-menu-scroll {width:122px !important;} /*		.sidebar-menu .main-menu a {color: #444 !important;background: rgba(55, 87, 109, 0.05);}*/ .sidebar-menu .main-menu a {color: #444 !important;padding-left:20px !important;} .sidebar-menu .main-menu .cur_s a ,.sidebar-menu .main-menu .cur_s a:visited ,.sidebar-menu .main-menu .left_cur ul li.cur_s a>span{ background: rgba(255, 255, 255, 1) !important;color: #00a0e9 !important;border-right: 1px solid #eeeeee;} .title.cur_tit {color:#444 !important;font-weight: bold;} /*		.left_cur {background:#fff !important;}*/ .cur_s .sidebar-menu .main-menu a {background:#fff !important;} .sidebar-menu .main-menu ul li a {padding-left:20px !important;} /*		.left_cur ul li a {background:#fff !important;}*/ .left_cur ul li {background:#fff !important;} .sidebar-menu .main-menu {margin-top:0 !important;} .top_big_class_name { height: 50px;line-height: 50px; text-align: center;overflow: hidden;border-bottom: 1px solid;white-space: nowrap;text-overflow: ellipsis;border-bottom: 1px solid #eeeeee;font-size:13px;} .new_logo {    display: block !important;} .sidebar-menu .main-menu .left_cur ul li a>span {color:#777777 !important;} .sidebar-menu .main-menu li.has-sub>a:before {content: '\f0d7' !important;} .main-menu-scroll {height:100% !important;} .page-container {position:absolute;padding-top: 40px;box-sizing: border-box;} .new_page_top {height:44px;width:100%;position: fixed;background:#1d1a3b;border-bottom: 1px solid #2f3d5a;z-index: 999999;} .sidebar-menu.fixed .sidebar-menu-inner {top:44px !important;} .new_logo {width:30px;height:30px;float: left;margin-top:7px;margin-left:18px;border-radius: 50%;border:2px solid rgba(255,255,255,0.5);overflow:hidden;} .new_logo img {width:26px;height:26px;} .app_name {color: #fff;font-size: 18px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;width: 155px;display: block; height:40px; line-height: 40px;margin-top:2px;margin-left:8px;float:left;} .new_page_top a  ,.new_page_top a:visited {color:#fff;text-decoration: none;} .new_page_top a:hover {color: #b3b3b3;text-decoration: none;} .sidebar-menu.fixed .sidebar-menu-inner {position:fixed !important;} .new_top_right {float:right;width:180px;height:44px; line-height: 44px;} .logout_box {width:153px; height: 44px;background:url(../../yb_tuangou/core/public/images/logout_icon.png) right center no-repeat;float:left;font-size:13px;margin-left:12px;} .left_menu_box {position:fixed;width:180px;top:44px;left:0;} .back_sys {width:100px; text-align: center;color:#fff;float:left;}.f_name_box:hover{color: #504f5c;background: #f3f3f3;text-decoration: none;}.ul_style .left_cur a{color: #503eff;}.ul_style li:hover{background: #f3f3f3;}.ul_style a{color: #7f7d8e;}.ul_style li:hover a span{color: #504f5c; }.ul_style .left_cur:hover a span{color: #503eff;}.ul_style li a{margin-left: 34px;}.jt{position: absolute;right: 10px;margin-top: -14px}.ul_style li a:hover{text-decoration: none;}.f_name_box.cur_name{text-decoration: none;}

    </style>
</head>
<body class="page-body">
<div class="new_page_top">
    <div class="new_logo">
        <?php if($about['logo'] != ''): ?>
        <img src="<?php echo $about['logo']; ?>" class="wq_logo">
        <?php else: ?>
        <img src="/public/static/bast/img/wq_shop_logo.png" class="wq_logo">
        <?php endif; ?>
    </div>
    <a href="javascript:void(0);" class="app_name"><?php echo $xcx_name; ?></a>
    <div class="new_top_right">
        <div class="logout_box">
            <?php if($copyright['back_type'] == 1): ?>
                <a href="<?php echo url('login/wxapp'); ?>" class="back_sys">
                    <?php else: if(!empty($last_visit_url)): ?>
                        <a href="<?php echo $last_visit_url; ?>" class="back_sys">
                    <?php else: ?>
                        <a href="<?php echo $siteroot; ?>web/index.php?c=wxapp&a=version&do=home&version_id=<?php echo $version_id; ?>" class="back_sys">
                    <?php endif; endif; ?>
                返回系统
            </a>
            <a href="<?php echo url('login/logout'); ?>" class="right_logout">退出</a>
        </div>
        <div class="clear"></div>
    </div>
    <?php if($endtime['is_show'] ==1): ?>
    <div style="height:44px; line-height:44px;float:right;color:#b3b3b3;font-size:13px;margin-right:15px;">该账号使用有效期至 <?php echo $endtime['time']; ?>，将在<?php echo $endtime['days']; ?>天后过期，请及时付费 ！  </div>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<div class="page-container" style="border-collapse:inherit;">
    <div class="new_left_menu" >
        <div class="left_menu_box" id="top_menu">
            <ul v-for="(item, index) in list" >
                <a v-on:click="top_click(item)" href="javascript:void(0);" :class="item.class"><i>
                    <img v-if="top_mid==item.module_id" :src="'public/images/aside_icon/'+item.logo+'_p.png'" alt="" >
                    <img v-else :src="'public/images/aside_icon/'+item.logo+'_n.png'" >
                </i><span class="big_class_name" v-text="item.module_name"></span>
                    <div v-if="item.sub.length>0">
                    <img src="public/images/aside_icon/ic_menu_top.png" v-if="top_mid==item.module_id && show" alt="" class="jt">
                    <img src="public/images/aside_icon/ic_menu_bot.png" v-else alt="" class="jt">
                    </div>
                </a>
                <ul :id="'second_'+item.module_id" name="second_menu" class="ul_style">
                    <li  v-if="item.sub.length>0" v-for="(v, k) in item.sub" v-on:click="sub_click(v)" v-bind:class="{'left_cur' : v.module_id == sub_mid, 'expanded' : expanded && v.module_id == sub_mid && item.sub.length > 0 }">
                        <a href="javascript:void(0);">
                            <span class="title" v-text="v.module_name"></span>
                        </a>
                    </li>
                </ul>
            </ul>
        </div>
    </div>
    <div class="main-content">
        
<div class="mod-table">
    <div class="n_tab_line">
        <a href="<?php echo url('order/OrderList'); ?>" class="n_tab_list02" onclick="ding('12','27');">订单列表</a>
        <a href="javascript:;" class="n_tab_add02">订单详情</a>
        <a class="btn btn-success radius r" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a>
        <div class="cl"></div>
    </div>
    <?php if($order['order_status'] < 5 && $order['order_status'] > 0): ?>
    <div class="step-region">
        <ul class="ui-step ui-step-4">
            <li class="ui-step-done"><div class="ui-step-title">买家下单</div><div class="ui-step-number">1</div><div class="ui-step-meta"><?php echo date('Y-m-d H:i:s',$order['create_time']); ?></div></li>
            <li class="<?php if($order["order_status"] > 0): ?>ui-step-done<?php endif; ?>"><div class="ui-step-title">买家付款</div><div class="ui-step-number">2</div><div class="ui-step-meta"><?php if($order["order_status"] > 0): ?><?php echo date('Y-m-d H:i:s',$order['pay_time']); endif; ?></div></li>
            <li class="<?php if($order["order_status"] > 1): ?>ui-step-done<?php endif; ?>"><div class="ui-step-title">商家发货</div><div class="ui-step-number">3</div><div class="ui-step-meta"><?php if($order["order_status"] > 1): ?><?php echo date('Y-m-d H:i:s',$order['consign_time']); endif; ?></div></li>
            <li class="<?php if($order["order_status"] == 3): ?>ui-step-done<?php endif; ?>"><div class="ui-step-title">交易完成</div><div class="ui-step-number">4</div><div class="ui-step-meta"><?php if($order["order_status"] == 3): ?><?php echo date('Y-m-d H:i:s',$order['sign_time']); endif; ?></div></li>
        </ul>
    </div>
    <?php endif; ?>
    <div class="step-region clearfix">
        <div class="info-region">
            <div class="info-div">订单信息<span class="secured-title">担保交易</span></div>
            <table class="info-table">
                <tbody>
                <tr><th>订单编号：</th><td><?php echo $order['order_no']; ?></td></tr>
                <tr style="display: table-row;"><th>订单类型：</th><td>普通订单</td></tr>
                <tr><th>付款方式：</th><td>在线支付</td></tr>
                <tr><th>买家：</th><td><span><?php echo $order['user_name']; ?></span></td></tr>
                </tbody>
            </table>
            <div class="dashed-line"></div>
            <table class="info-table">
                <tbody>
                <tr><th>配送方式：</th><td><?php echo $order['shipping_type_name']; ?>&nbsp;&nbsp;<?php echo $order['shipping_company_name']; ?></td></tr>
                <?php switch($order['shipping_type']): case "1": ?>
                <!-- 物流 -->
                <tr>
                    <th>收货信息：</th>
                    <td>
                        <p><?php echo $order['receiver_name']; ?>，<?php echo $order['receiver_mobile']; ?>，<?php echo $order['address']; ?>&nbsp;<?php echo $order['receiver_address']; if($order['receiver_zip']!=''): ?>&nbsp;，<?php echo $order['receiver_zip']; endif; ?></p>
                    </td>
                </tr>
                <?php break; case "2": ?>
                <!-- 自提 -->
                <tr>
                    <th>自提地址：</th>
                    <td>
                        <p><?php echo $order['order_pickup']['province_name']; ?>&nbsp;<?php echo $order['order_pickup']['city_name']; ?>&nbsp;<?php echo $order['order_pickup']['dictrict_name']; ?>&nbsp;<?php echo $order['order_pickup']['address']; ?></p>
                    </td>
                </tr>
                <?php break; endswitch; if(!empty($order['buyer_invoice_info'])): ?>
                <tr>
                    <th>发票抬头：</th>
                    <td>
                        <?php if(!empty($order['buyer_invoice_info'][0])): ?>
                        <?php echo $order['buyer_invoice_info'][0]; endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>纳税人识别号：</th>
                    <td>
                        <?php if(!empty($order['buyer_invoice_info'][2])): ?>
                        <?php echo $order['buyer_invoice_info'][2]; else: ?>
                        -
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>发票内容：</th>
                    <td>
                        <?php if(!empty($order['buyer_invoice_info'][1])): ?>
                        <?php echo $order['buyer_invoice_info'][1]; endif; ?>
                    </td>
                </tr>
                <?php endif; ?>
                <tr>
                    <th>买家留言：</th>
                    <?php if($order['buyer_message'] !=''): ?>
                    <td><?php echo $order['buyer_message']; ?></td>
                    <?php else: ?>
                    <td>此订单没有留言</td>
                    <?php endif; ?>
                </tr>
                <?php if($order['seller_memo'] != ''): ?>
                <tr>
                    <th>卖家备注：</th>
                    <td><?php echo $order['seller_memo']; ?></td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="state-region">
            <div style="padding: 0px 0px 30px 40px;">
                <div class="state-title"><span class="icon info">!</span>订单状态：<?php echo $order['status_name']; ?></div>
            </div>
            <div class="state-remind-region">
                <div class="dashed-line"></div>
                <div class="state-remind"><div class="tixing">提醒：</div>
                    <ul><li>如果无法发货，请及时与买家联系并说明情况后进行退款；</li>
                        <li>买家申请退款后，须征得买家同意后再发货，否则买家有权拒收货物；</li>
                        <li>买家付款后超过7天仍未发货，将有权申请客服介入发起退款维权；</li>
                        <li><div class="tixing">可改价商品改价后按回车键即可</div></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <table class="ui-table ui-table-simple goods-table order-detail-goods-table">
        <thead>
        <tr>
            <th style="width:8%;">商品图</th>
            <th class="cell-10" style="width:30%;">商品</th>
            <th style="width:10%;">数量</th>
            <th style="width:10%;">订单价格(元)</th>
            <th style="width:8%;">优惠券(元)</th>
            <th style="width:8%;">会员折扣(元)</th>
            <th style="width:8%;">运费(元)</th>
            <th class="cell-13" style="width:10%;">实付款价格(元)</th>
            <th style="width:15%;">配送状态</th>
        </tr>
        </thead>
        <tbody>
        <!-- 待发货商品 -->
        <?php if($order['order_goods_no_delive']): if(is_array($order['order_goods_no_delive']) || $order['order_goods_no_delive'] instanceof \think\Collection || $order['order_goods_no_delive'] instanceof \think\Paginator): $i = 0; $__LIST__ = $order['order_goods_no_delive'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <tr class="test-item">
            <td class="td-goods-image" rowspan="1">
                <div class="ui-centered-image" style="width: 48px; height: 48px;">
                    <img src="<?php echo $vo['picture_info']['img_cover']; ?>" style="max-width: 48px; max-height: 48px;">
                </div>
            </td>
            <td class="cell-10" style="width:200px;">
                <a href="/admin/goods/goodsinfo?goodsid=<?php echo $vo['goods_id']; ?>" target="_blank"><?php echo $vo['goods_name']; ?></a>
                <p class="c-gray"><?php echo $vo['sku_name']; ?></p>
            </td>
            <td><?php echo $vo['num']; ?></td>
            <td><?php echo $vo['price']; ?></td>
            <td><p><?php echo $list['coupon_money']; ?></p></td>
            <td><p><?php echo $list['rebate_money']; ?></p></td>
            <td><p><?php echo $list['shipping_money']; ?></p></td>
            <td><p><?php echo $list['pay_money']; ?></p></td>
            <td>
                <p><?php echo getOrderStatus($order['order_status']); ?></p>
            </td>
        </tr>
        <tr><td colspan="9"></td></tr>
        <?php endforeach; endif; else: echo "" ;endif; endif; ?>
        <!-- 已发货 -->
        <?php if($order['goods_packet_list']): if(is_array($order['goods_packet_list']) || $order['goods_packet_list'] instanceof \think\Collection || $order['goods_packet_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $order['goods_packet_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
        <tr style="background-color:#f2f2f2;color:#999;font-weight:bold;">
            <td colspan="7"><a href="javascript:;" style="color:rgba(34, 34, 34, 0.71);font-size:14px;"><?php echo $v['packet_name']; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
                <?php if($v['is_express'] == 1): ?>
                <?php echo $v['express_name']; ?>&nbsp;&nbsp;运单号:<?php echo $v['express_code']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:;" data-html="true" class="logistics-tracking" data-container="body" data_express="<?php echo $v['express_name']; ?>" data-placement="top" data-trigger="manual" goods_id="<?php echo $v['express_id']; ?>" data-show="1">物流跟踪</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php if(is_array($v['order_goods_list']) || $v['order_goods_list'] instanceof \think\Collection || $v['order_goods_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['order_goods_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <tr class="test-item">
            <td class="td-goods-image" rowspan="1">
                <div class="ui-centered-image" style="width: 48px; height: 48px;">
                    <img src="<?php echo $vo['picture_info']['img_cover']; ?>" style="max-width: 48px; max-height: 48px;">
                </div>
            </td>
            <td class="cell-10" style="width:200px;">
                <a href="javascript:;" target="_blank"><?php echo $vo['goods_name']; ?></a>
                <p class="c-gray"><?php echo $vo['sku_name']; ?></p>
            </td>
            <td><?php echo $vo['price']; ?></td>
            <td><?php echo $vo['num']; ?></td>
            <td><p><?php echo $vo['goods_money']; ?></p></td>
            <td>
                <p>
                    <?php echo $order['shipping_status_name']; ?>
                </p>
            </td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; endforeach; endif; else: echo "" ;endif; endif; ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="9" class="text-right">
                <a href="javascript:;" target="_blank" onclick="window.open('__CONF_SITE__admin/order/OrderDetail&printer=1&order_id=<?php echo $order['order_id']; ?>')" class="btn btn-default">打印订单</a>
                <span>商品总金额：￥<?php echo $order['order_money']; ?>，</span>
                <?php if($order['user_platform_money']>0): ?>
                <span>余额支付：￥<?php echo $order['user_platform_money']; ?>，</span>
                <?php endif; if($order['coupon_money']>0): ?>
                <span>优惠券：￥<?php echo $order['coupon_money']; ?>，</span>
                <?php endif; if($order['tax_money']>0): ?>
                <span>发票税额：￥<?php echo $order['tax_money']; ?>，</span>
                <?php endif; if($order['discount_money']>0): ?>
                <span>满减优惠：￥<?php echo $order['discount_money']; ?>，</span>
                <?php endif; if($order['point']>0): ?>
                <span>使用积分：<?php echo $order['point']; ?>，</span>
                <?php endif; if($order['status_name']=='待支付'): ?>
                <span>实际需支付：<input type="text" value="<?php echo $order['pay_money']; ?>" style="border:1px solid #eeeeee;height:28px;line-height: 28px;padding-left:5px;" onchange="update_money(this.value)"></span>
                <?php else: ?>
                <span> 实际需支付：<b class="real-pay c-red">￥<?php echo $order['pay_money']; ?></b></span>
                <?php endif; ?>
                <span>（含运费 ￥<?php echo $order['shipping_money']; ?>）</span>
            </td>
        </tr>
        </tfoot>
    </table>
</div>
<input type="hidden" id="order_id" value="<?php echo $order['order_id']; ?>" />
<input type="hidden" id="old_pay" value="<?php echo $order['pay_money']; ?>" />
<input type="hidden" id="out_trade_no" value="<?php echo $order['out_trade_no']; ?>" />
<script type="text/javascript">
    $(function(){
        //查询物流
        $(".logistics-tracking").mouseover(function(){
            $(".logistics-tracking").removeAttr("data-show");
            $(this).attr("data-show",1);
        });
        var html = '';
        $(".logistics-tracking").hover(function(){
            var curr = $(this);
            var order_goods_id = curr.attr('goods_id');
            var express_name = curr.attr('data_express');
            $.ajax({
                type : "post",
                url : "<?php echo url('order/getexpressinfo'); ?>",
                data : {"order_goods_id":order_goods_id},
                beforeSend : function(){
                    html = '<div class="silider-express">';
                    html += '<div class="mask-layer-loading" style="text-align:center;">';
                    html += '<img src="ADMIN_IMG/mask_load.gif"/>';
                    html += '<div style="text-align:center;margin-top:10px;">努力加载中...</div>';
                    html += '</div>';
                    html += '</div>';
                    $(".logistics-tracking").popover({content : html});
                    curr.popover("show");
                },
                success : function(data) {
                    html = '<div class="silider-express">';
                    html += '<div class="express_names">快递公司:'+express_name+'</div>';
                    html += '<div>';
                    html += '<div>物流跟踪：</div>';
                    if (data.length > 0) {
                        for (var i = 0; i < data.length; i++){
                            html += '<p style="width:76%;float:left;">'+ data[i]["AcceptStation"]+'</p>';
                            html += '<p style="width:24%;float:right;">'+ data[i]["AcceptTime"]+'</p>';
                        }
                    } else {
                        html += '<p style="width:76%;float:left;">'+ data["Reason"]+'</p>';
                    }
                    html += '</div>';
                    html += '</div>';
                    curr.popover("destroy");
                    curr.popover({content : html});
                    curr.popover("show");
                }
            });
        },function(){
            $(this).popover("hide");
        });
    })
    function update_money(money) {
        var id=$("#order_id").val();
        var out_trade_no=$("#out_trade_no").val();
        var old_pay=$("#old_pay").val();
        $.ajax({
            type : "post",
            url : "__CONF_SITE__admin/order/change_money",
            data : {
                "id" : id,
                "out_trade_no" : out_trade_no,
                "old_pay" : old_pay,
                'val':money
            },
            success : function(data) {
                if (data=='2') {
                    layer.msg('成功!',{icon:1,time:1000},function () {
                        window.location.reload();
                    });
                }
                else
                {
                    layer.msg('失败', {icon: 2, time: 1000});
                }
            }
        })
    }
</script>

    </div>

    <footer class="footer" style="background: #FFFFFF;height: 25px;margin-top: -5px;padding-top: 10px;line-height: 25px;">
        <!--<p><?php echo $copyright['content']; ?></p>-->
        <?php if($show_we7): ?>
        <div class="container-fluid footer text-center" role="footer">
            <div class="friend-link" >
                <?php if(empty($_W['footerright'])): ?>
                <a href="http://www.we7.cc">微信开发</a>
                <a href="http://s.we7.cc">微信应用</a>
                <a href="http://bbs.we7.cc">微擎论坛</a>
                <a href="http://s.we7.cc">联系客服</a>
                <?php else: ?>
                <?php echo $_W['footerright']; endif; ?>
            </div>
            <div class="copyright"><?php if(empty($_W['footerleft'])): ?>Powered by <a href="http://www.we7.cc"><b>微擎</b></a> v<?php echo $version; ?> &copy; 2014-2015 <a href="http://www.we7.cc">www.we7.cc</a><?php else: ?><?php echo $_W['footerleft']; endif; ?></div>
            <?php if(!empty($_W['icp'])): ?><div>备案号：<a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $_W['icp']; ?></a></div><?php endif; ?>
        </div>
        <?php if(!empty($_W['statcode'])): ?><?php echo $_W['statcode']; endif; if(!empty($_GPC) && !in_array($_GPC, array('keyword', 'special', 'welcome', 'default', 'userapi')) || defined('IN_MODULE')): ?>
        <script>
            if(typeof $.fn.tooltip != 'function' || typeof $.fn.tab != 'function' || typeof $.fn.modal != 'function' || typeof $.fn.dropdown != 'function') {  require(['bootstrap']);}
        </script>
        <?php endif; endif; ?>
    </footer>
</div>
<script src="/public/static/bast/xenon-custom.js"></script>
<script src="/public/static/bast/clipboard.js"></script>
<script src="/public/static/bast/TweenMax.min.js"></script>
<script src="/public/static/bast/resizeable.js"></script>
<script src="/public/static/layer/2.4/layer.js"></script>
<script src="/public/js/public_js.js"></script>
<script src="/public/js/all.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>

<script>
    var str;
    str = '<?php echo json_encode($all_menu); ?>';
    var all_menu = eval(decodeURIComponent(str));
    var root_url = "<?php global $_W; echo $_W['siteroot'].'addons/yb_tuangou/core/index.php?s=/admin/'; ?>";
    var top_mid = '<?php echo $top_mid; ?>';
    var sub_mid = '<?php echo $sub_mid; ?>';
    var three_mid = '<?php echo $three_mid; ?>';
    var sub_menu_arr = [];
    $(document).ready(function () {
        $("ul[name=second_menu]").hide();
        if(top_mid>0){
            $("#second_"+top_mid).show();
        }
    });
    all_menu.forEach(function (item, index) {
        if(item.module_id == top_mid)
        {
            item.class = 'f_name_box cur_name';
            sub_menu_arr = item.sub? item.sub : [];
        }
        else
        {
            item.class = 'f_name_box';
        }
    });
    var top_menu = new Vue({
        el: '#top_menu',
        data: {
            list:all_menu,
            top_mid: top_mid,
            root_url : root_url,
            sub_mid: sub_mid,
            three_mid: three_mid,
            expanded:sub_mid > 0,
            show:true,
        },
        methods:{
            top_click:function (top_item) {
                if(this.top_mid != top_item.module_id)
                {
                    this.show=true;
                    var sub_menu=this;
                    $("ul[name=second_menu]").hide();
                    $("#second_"+top_item.module_id).show();
                    var val = top_item.module_id;
                    this.top_mid = val;
                    sub_menu.expanded = false;
                    document.cookie = "top_mid=" + val;
                    if(top_item.sub.length > 0)
                    {
                        this.list.forEach(function (item, index) {
                            if(item.module_id == val)
                            {
                                item.class = 'f_name_box cur_name';
//                                sub_menu.list = item.sub;
                                sub_menu.sub_mid = 0;
                                sub_menu.three_mid = 0;
                                if(sub_menu.list != null && sub_menu.list != undefined)
                                {
                                    if(sub_menu.list.length > 0)
                                    {
                                        sub_menu.expanded = true;
                                        sub_menu.sub_mid = sub_menu.list[0]['module_id'];
                                    }
                                }
                            }
                            else
                            {
                                item.class = 'f_name_box';
                            }
                        });
                    }
                    else
                    {
                        window.location.href = this.root_url+top_item.url;
                    }
                }else {
                    this.show=!this.show;
                    $("ul[name=second_menu]").hide();
                    if(this.show){
                        $("#second_"+top_item.module_id).show();
                    }
                }
            },
            sub_click: function (item) {
                this.expanded = this.sub_mid == item.module_id ? !this.expanded : true;
                this.sub_mid = item.module_id;
                document.cookie = "sub_mid=" + item.module_id;
                if(item.sub.length == 0)
                {
                    window.location.href = this.root_url+item.url;
                }
            },
            three_click: function (item) {
                this.three_mid = item.module_id;
                document.cookie = "three_mid=" + item.module_id;
                window.location.href = this.root_url+item.url;
            }
        },
    });
</script>
</body>
</html>