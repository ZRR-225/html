<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/images/images_add.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
</head>
<body>
<article class="cl pd-20">
	<form action="" method="post" class="form form-horizontal" id="">
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>相册名称：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" autocomplete="off" value="" placeholder="相册名称" class="input-text" id="images_name" name="images_name">
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>排序：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" autocomplete="off" value="" placeholder="排序" class="input-text" id="images_sort" name="images_sort">
			</div>
		</div>
		<div class="row cl">
			<div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
				<input class="btn btn-primary radius" onclick="addSuppAjax()" type="button" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
			</div>
		</div>
	</form>
</article>
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    //模块输入信息验证
    function verify() {
        var images_name = $("#images_name").val();
        if (images_name == '') {
            layer.msg('名称不能为空',{icon:5,time:1000});
            return false;
        }
        return true;
    }
    var flag = false;//防止重复提交
    //添加相册
    function addSuppAjax() {
        var images_name = $("#images_name").val();
        var images_sort = $("#images_sort").val();
        if(verify() && !flag){
            flag = true;
            $.ajax({
                type : "post",
                url : "<?php echo url('images/images_add'); ?>",
                data : {
                    'images_name':images_name,
                    'images_sort' : images_sort,
                },
                success : function(data) {
                    if(data['code']>0){
                        layer.msg('添加成功!',{icon:1,time:1000},function () {
                            window.parent.location.href="<?php echo url('images/image_list'); ?>";
                        });
                    }
                    else{
                        flag = false;
                        layer.msg(data['message'],{icon:5,time:1000});
                    }
                }
            });
        }
    }
</script>
</body>
</html>