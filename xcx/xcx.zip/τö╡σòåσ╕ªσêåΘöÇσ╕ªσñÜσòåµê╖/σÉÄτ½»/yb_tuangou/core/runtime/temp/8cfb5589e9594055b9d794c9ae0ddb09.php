<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/user/add_level.html";i:1547905372;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css"/>
    <script src="/public/js/jquery-2.1.1.js"></script>
</head>
<body>
<article class="cl pd-20">
    <div class="row cl" style="margin-top: 20px;">
        <label class="form-label col-xs-3 col-sm-2" style="text-align: right;margin-top: 5px;"><span class="c-red">*</span>会员等级：</label>
        <div class="formControls col-xs-8 col-sm-8">
            <input type="text" autocomplete="off" value="" placeholder="会员等级编号" class="input-text" id="level">
        </div>
    </div>
    <div class="row cl" style="margin-top: 20px;">
        <label class="form-label col-xs-3 col-sm-2" style="text-align: right;margin-top: 5px;"><span class="c-red">*</span>等级名称：</label>
        <div class="formControls col-xs-8 col-sm-8">
            <input type="text" autocomplete="off" value="" placeholder="会员等级名称" class="input-text" id="level_name">
        </div>
    </div>
    <div class="row cl" style="margin-top: 20px;">
        <label class="form-label col-xs-3 col-sm-2" style="text-align: right;margin-top: 5px;"><span class="c-red">*</span>累计积分：</label>
        <div class="formControls col-xs-8 col-sm-8">
            <input type="text" autocomplete="off" value="" onkeyup="this.value=this.value.replace(/\D/g,'')" placeholder="累计积分" class="input-text" id="hierarchy">
        </div>
    </div>
    <div class="row cl" style="margin-top: 20px;">
        <label class="form-label col-xs-3 col-sm-2" style="text-align: right;margin-top: 5px;"><span class="c-red">*</span>享受折扣：</label>
        <div class="formControls col-xs-8 col-sm-8">
            <input type="text" autocomplete="off" value=""  placeholder="优惠折扣 例如 9.85" class="input-text" id="rebate">
        </div>
        <div class="formControls col-xs-1 col-sm-2" style="margin-left: -20px; text-align: left;margin-top: 3px;">
            折
        </div>
    </div>
    <div class="row cl" style="margin-top: 30px;">
        <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
            <input class="btn btn-primary radius" onclick="rsave()" type="button" value="&nbsp;&nbsp;保存&nbsp;&nbsp;">
        </div>
    </div>
</article>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    function rsave() {
        $.ajax({
            type: "post",
            url: "<?php echo url('user/add_level'); ?>",
            data: {
                level: $('#level').val(),
                level_name: $('#level_name').val(),
                hierarchy: $('#hierarchy').val(),
                rebate: $('#rebate').val()
            },
            success: function (data) {
                if (data['code'] > 0) {
                    layer.msg('保存成功!', {icon: 1, time: 1000}, function () {
                        parent.location.reload();
                    });
                }
                else {
                    flag = false;
                    layer.msg(data['data'], {icon: 5, time: 3000});
                }
            }
        });
    }
</script>
</body>
</html>