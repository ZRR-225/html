<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/sappl/sappl_edit.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css"/>
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.admin.css"/>
</head>
<body>
<article class="cl pd-20">
    <form action="" method="post" class="form form-horizontal" id="">
        <div class="row cl">
            <label class="form-label col-xs-3 col-sm-3"><span class="c-red">*</span>小程序名称：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" name="sapp_name" value="<?php echo $info['sapp_name']; ?>" placeholder="请输入要跳转的小程序名称" class="input-text">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-3 col-sm-3"><span class="c-red">*</span>APPID：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" name="appid" value="<?php echo $info['appid']; ?>" placeholder="请输入小程序ID" class="input-text">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-3 col-sm-3"><span class="c-red">*</span>跳转地址：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" name="url" value="<?php echo $info['url']; ?>" placeholder="请输入要跳转的小程序地址" class="input-text">
                <span>（不填写则默认跳转首页）</span>
            </div>
        </div>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <input class="btn btn-primary radius" onclick="attr_mod_add()" type="button"
                       value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
    </form>
</article>
<input type="hidden" id="id" value="<?php echo $info['id']; ?>">
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    var lock = false;
    function attr_mod_add() {
        if(!lock){
            lock = true;
            $.ajax({
                type: "post",
                url: "<?php echo url('sappl/sappl_edit'); ?>",
                data: {
                    id: $("#id").val(),
                    sapp_name: $("[name='sapp_name']").val(),
                    appid: $("[name='appid']").val(),
                    url: $("[name='url']").val()
                },
                success: function (data) {
                    if (data['code'] > 0) {
                        layer.msg('修改成功!', {icon: 1, time: 2000});
                        parent.location.reload();
                    } else {
                        layer.msg(data['message'], {icon: 2, time: 1000});
                        lock = false;
                    }
                }
            });
        }
    }
</script>
</body>
</html>