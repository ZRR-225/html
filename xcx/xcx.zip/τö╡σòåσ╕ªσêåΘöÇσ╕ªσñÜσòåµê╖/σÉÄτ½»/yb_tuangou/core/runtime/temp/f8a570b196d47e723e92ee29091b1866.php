<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/bargain/select_goods.html";i:1548038996;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <meta charset="UTF-8">
    <title></title>
    <!--<link rel="stylesheet" type="text/css" href="/public/static/h-ui.admin/css/style.css?v=1.3" />-->
    <link media="all" href="/public/menu/css/article.css" type="text/css" rel="stylesheet">
    <style>
        @charset "utf-8";.n_tab_line{height:39px;line-height:39px;border-bottom:1px solid #ddd;margin-bottom:15px;position:relative}.n_tab_line a{display:block;height:28px;line-height:28px;float:left;margin-bottom:0;text-align:center}.n_tab_line a:hover{text-decoration:none;color:#333}.n_tab_line .n_tab_list{font-size:15px;color:#999;font-weight:500}.n_tab_add,.n_tab_line .n_tab_add{position:absolute;right:0;top:-10px;height:40px;width:110px;background:#48bd47;color:#fff;line-height:40px;color:#fff;text-align:center;cursor:pointer;border-radius: 4px;}.n_tab_line .n_tab_add:hover,.n_tab_add a{color:#fff!important;text-decoration:none}.btn-search{background:rgb(13, 163, 249);color:#fff;line-height:30px !important;height:39px !important;border:1px solid rgb(13, 163, 249);border-radius:3px;}.n_tab_add02{border-top:1px solid #5a98de;border-left:1px solid #ddd;border-bottom:1px solid #ddd;border-right:1px solid #ddd;color:#148cf1}.n_tab_list02{border-left:1px solid #ddd;border-top:1px solid #ddd;background:#fbfaf8!important;color:#666!important}.n_page_button{border:1px solid #ccc;border-radius:3px;cursor:pointer;display:inline-block;margin-left:2px;text-align:center;text-decoration:none;color:#666;height:28px;line-height:26px;text-decoration:none;margin:0 0 6px 6px;padding:6px 14px;font-size:14px}.n_page_button.current{background:rgb(13, 163, 249);color:#fff;border:1px solid rgb(13, 163, 249)}.n_page_no{height:60px;line-height:60px;text-align:right;padding-right:15px;margin-bottom:20px}.page_disable{color:#b8b8b8}.n_page_no a:hover.page_disable{color:#b8b8b8;text-decoration:none}.n_page_no a:hover.current{color:#fff;text-decoration:none}.n_page_no a:hover{color:#666;text-decoration:none}.n_page_no span .select{width:50px}.input-common{border:1px solid #ddd;padding:5px 8px}

    </style>
</head>
<body style="background-color: rgb(255, 255, 255);">
<div class="jbox-container" style="float: left; padding: 0px;position: relative">
    <ul class="gagp-goodslist" style="padding: 10px; width: 750px;">
        <table class="wxtables">
            <colgroup>
                <col width="10%"><col width="15%"><col width="20%"><col width="25%"><col width="15%">
            </colgroup>
            <thead>
            <tr style="background-color: rgb(13, 163, 249);">
                <td>ID</td>
                <td>商品图片</td>
                <td>商品名称</td>
                <td>发布时间</td>
                <td>价格</td>
                <td>操作</td>
            </tr>
            </thead>
            <tbody>
            <?php if(is_array($goods) || $goods instanceof \think\Collection || $goods instanceof \think\Paginator): $i = 0; $__LIST__ = $goods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <tr>
                    <td><p><?php echo $vo['goods_id']; ?></p></td>
                    <td><p><img src="<?php echo $vo['img_cover']; ?>" alt="" height="50px" width="50px"></p></td>
                    <td><p><?php echo $vo['goods_name']; ?></p></td>
                    <td><p><?php echo date('Y-m-d H:i:s',$vo['create_time']); ?></p></td>
                    <td><p>￥<?php echo $vo['price']; ?></p></td>
                    <td style="padding:0 !important;">
                        <a class="btn selecta sure" data-img-id="<?php echo $vo['img_id']; ?>" data-money="<?php echo $vo['price']; ?>" data-img_path="<?php echo $vo['img_cover']; ?>" data-short_title="<?php echo $vo['introduction']; ?>" data-goods-id="<?php echo $vo['goods_id']; ?>" data-value="<?php echo $vo['goods_id']; ?>"  data-name="<?php echo $vo['goods_name']; ?>">选择</a>
                    </td>
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>
        <div class="n_page_no">
            <?php echo $page; ?>
        </div>
    </ul>
    <div style="height:60px; line-height: 60px;"></div>
    <!--<div class="sel_fun_opt" style="position: absolute; bottom: 20px;">-->
        <!--<div class="sure" onclick="">确定</div>-->
        <!--<div class="cancel" onclick="">返回</div>-->
    <!--</div>-->
</div>
<script src="/public/js/jquery-2.1.1.js" type="text/javascript"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    $(".selecta").click(function(){
        if ($(this).hasClass('selectedb')) {
        }else{
            $(this).addClass('selectedb');
            $(this).html('已选择');
            $(this).parent().parent().siblings().find('.selecta').removeClass('selectedb');
            $(this).parent().parent().siblings().find('.selecta').html('选择');
        }
    });
    $(".sure").click(function(){
        if (typeof($('.selectedb').attr('data-name'))=="undefined"){
                layer.msg('请选择内容',{icon:5,time:1000});
                return false;
        }
        var item = {};
        item['img_id'] = $('.selectedb').attr('data-img-id');
        item['goods_id'] = $('.selectedb').attr('data-goods-id');
        item['name'] = $('.selectedb').attr('data-name');
        item['img_path'] = $('.selectedb').attr('data-img_path');
        item['price'] = $('.selectedb').attr('data-money');
        parent.get_images(item);
       var index = parent.layer.getFrameIndex(window.name);
        parent.layer.close(index);
    })
    $(".cancel").click(function(){
        var index = parent.layer.getFrameIndex(window.name);
        parent.layer.close(index);
    });
</script>
</body>
</html>
