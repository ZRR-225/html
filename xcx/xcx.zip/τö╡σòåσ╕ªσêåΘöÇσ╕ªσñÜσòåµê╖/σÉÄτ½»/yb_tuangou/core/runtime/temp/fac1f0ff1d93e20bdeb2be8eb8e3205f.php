<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/goods/goods_spec_edit.html";i:1545994004;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
</head>
<body>
<article class="cl pd-20">
	<form action="" method="post" class="form form-horizontal" id="">
		<input type="hidden" id="spec_id" value="<?php echo $info['spec_id']; ?>">
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>规格名称：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" autocomplete="off" value="<?php echo $info['spec_name']; ?>" placeholder="规格名称" class="input-text" id="spec_name">
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>商品分类：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<span class="select-box">
				  <select class="select" size="1" id="cate_id">
					  <?php if(is_array($res) || $res instanceof \think\Collection || $res instanceof \think\Paginator): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v1): $mod = ($i % 2 );++$i;?>
						<option value="<?php echo $v1['cate_id']; ?>" <?php if($info['cate_id']==$v1['cate_id']): ?> selected <?php endif; ?>><?php echo $v1['cate_name']; ?></option>
					  <?php endforeach; endif; else: echo "" ;endif; ?>
				  </select>
				</span>
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>规格排序：</label>
			<div class="formControls col-xs-8 col-sm-9">
				<input type="text" autocomplete="off" value="<?php echo $info['sort']; ?>" placeholder="规格排序" class="input-text" id="sort">
			</div>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3">是否启用：</label>
			<div class="formControls col-xs-8 col-sm-3 skin-minimal">
				<div class="check-box">
					<input type="checkbox" id="is_visible" <?php if($info['is_visible'] == '1'): ?>checked="checked"<?php endif; ?>>
					<label for="is_visible">&nbsp;</label>
				</div>
			</div>
		</div>
		<div class="row cl" id="att">
			<?php if(is_array($info['spec_value_list']) || $info['spec_value_list'] instanceof \think\Collection || $info['spec_value_list'] instanceof \think\Paginator): if( count($info['spec_value_list'])==0 ) : echo "" ;else: foreach($info['spec_value_list'] as $key=>$v): ?>
			<div class="w100">
				<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>规格值：</label>
				<div class="formControls col-xs-8 col-sm-9 spec_data">
					<input type="text" autocomplete="off" value="<?php echo $v['spec_value_name']; ?>" onchange="setGoodsField('spec_value_name',<?php echo $v['spec_value_id']; ?>,this);" placeholder="" class="input-text addspec_color_<?php echo $key+1; ?>" name="spec_value" id="spec_value">
					<span class="error"></span>
					<div class="inline-block w19"><a style="color: #00a2d4" href="javascript:;" onclick="delOldSpecValue(this, <?php echo $info['spec_id']; ?>, <?php echo $v['spec_value_id']; ?>)">删除</a></div>
				</div>
				<input type="hidden" name="spec_value_id_<?php echo $key; ?>" value="<?php echo $v['spec_value_id']; ?>">
			</div>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
		<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"></label>
			<div class="formControls col-xs-8 col-sm-3">
				<a href="javascript:;" onclick="addSpecValue(this)"><i class="Hui-iconfont">&#xe600;</i>添加一个规格值</a>
			</div>
		</div>
		<div class="row cl">
			<div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
				<input class="btn btn-primary radius" onclick="addSuppAjax()" type="button" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
			</div>
		</div>
	</form>
</article>
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
//修改单个字段
function setGoodsField(type,spec_value_id,e){
    var field_name = '';
    var field_value = '';
    if(type == 'spec_value_name'){
        field_name = 'spec_value_name';
        field_value = $(e).val();
        if(field_value == ''){
            layer.msg('属性名称不能为空',{icon:5,time:1000});
            return false;
        }
    }
    $.ajax({
        type : "post",
        url : "<?php echo url('goods/modifygoodsspecvaluefield'); ?>",
        data : {
            'spec_value_id' : spec_value_id,
            'field_name' : field_name,
            'field_value' : field_value
        },
        dataType : "json",
        success : function(data) {
        }
    });
}
//添加一个属性
function addSpecValue(e){
var html= '<div class="w100 new_data">';
	html+='<label class="form-label col-xs-4 col-sm-3"></label>';
    html+='<div class="formControls col-xs-8 col-sm-9 spec_data">';
    html+='<input type="text" autocomplete="off" value="" placeholder="" class="input-text" name="spec_value" id="spec_value">';
    html+='<div class="inline-block w19"><a style="color: #00a2d4" href="javascript:;" onclick="delSpecValue(this)">删除</a></div>';
    html+='</div>';
    html+='</div>';
   $("#att").append(html);
}
//删除 旧数据
function delOldSpecValue(e, spec_id, spec_value_id){
    layer.confirm('确认要删除吗？',function(index){
        //此处请求后台程序
        $.ajax({
            type : "post",
            url : "<?php echo url('goods/deletegoodsspecvalue'); ?>",
            data : { 'spec_id' : spec_id, 'spec_value_id' : spec_value_id },
            dataType : "json",
            success : function(data) {
                if (data['code'] > 0) {
                    $(e).parents('.w100').remove();
                    layer.msg(data["message"],{icon:1,time:1000});
                }else if(data['code'] == 0){
                    layer.msg(data["message"],{icon:2,time:1000});
                }else if(data['code'] == -1){
                    layer.msg('当前属性正在使用中，不能删除！',{icon:5,time:1000});
                }else if(data['code'] == -2){
                    layer.msg('当前属性已经是最后一个,不能删除！',{icon:5,time:1000});
                }
            }
        });
    });
}
var flag = false;//防止重复提交
//添加用户
function addSuppAjax() {
    var spec_name = $("#spec_name").val();
    var sort = $("#sort").val();
    var spec_id = $("#spec_id").val();
    var cate_id = $("#cate_id").val();
    var spec_value_obj = $(".new_data input[name='spec_value']");
    var spec_value_str = '';
    spec_value_obj.each(function(i){
        if(spec_value_obj.eq(i).val() != ''){
            spec_value_str += ',' + spec_value_obj.eq(i).val();
        }
    });
    spec_value_str = spec_value_str.substr(1);
    if ($("#is_visible").prop("checked")) {
        var is_visible = 1;
    } else {
        var is_visible = 0;
    }
    if(spec_name == ''){
        layer.msg('规格名称不能为空',{icon:5,time:1000});
        return false;
    }
    if(sort == ''){
        layer.msg('排序不能为空',{icon:5,time:1000});
        return false;
    }
    if(flag){
        return;
    }
     flag = true;
        $.ajax({
            type : "post",
            url : "<?php echo url('goods/goods_spec_edit'); ?>",
            data : {
                'spec_id' : spec_id,
                'spec_name' : spec_name,
                'sort' : sort,
                'is_visible' : is_visible,
                'spec_value_str' : spec_value_str,
				'cate_id':cate_id
            },
            success : function(data) {
                if(data['code']>0){
                    layer.msg('修改成功!',{icon:1,time:1000},function () {
                        window.parent.location.href="<?php echo url('goods/goods_spec'); ?>";
                    });
                }
                else{
                    flag = false;
                    layer.msg(data['message'],{icon:5,time:1000});
                }
            }
        });
}
</script>
</body>
</html>