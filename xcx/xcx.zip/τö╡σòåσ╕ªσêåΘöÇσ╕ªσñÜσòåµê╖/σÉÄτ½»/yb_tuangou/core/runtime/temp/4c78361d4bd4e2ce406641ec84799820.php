<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/order/order_delivery.html";i:1548041985;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
</head>
<body>
<div>
<div class="modal-body">
    <!-- 主要内容 -->
    <div>待发货(<span id="no_shipping_num">1</span>)</div>
    <table class="table table-hover" style="margin-bottom:10px;">
        <thead>
        <tr>
            <td>商品</td>
            <td>数量</td>
            <td>物流 | 单号</td>
            <td>状态</td>
        </tr>
        </thead>
        <colgroup>
            <col style="width: 40%;">
            <col style="width: 10%;">
            <col style="width: 30%;">
            <col style="width: 15%;">
        </colgroup><colgroup>
    </colgroup><tbody>
    <?php if(is_array($data['order_goods_list']) || $data['order_goods_list'] instanceof \think\Collection || $data['order_goods_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['order_goods_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$go): $mod = ($i % 2 );++$i;?>
    <tr>
                <td>
                    <a href="javascript:;"><?php echo $go['goods_name']; ?></a>
                </td>
                <td>
                    <?php echo $go['num']; ?>
                </td>
                <td>
                </td>
                <td><?php echo $go['shipping_status_name']; ?></td>
            </tr>
    <?php endforeach; endif; else: echo "" ;endif; ?>
    </tbody>
    </table>
    <div>
        <div style="margin-bottom:5px;">发货方式：</div>
        <label class="checkbox-inline" style="float:left;margin-right:30px;"><input type="radio" name="shipping_type" id="shipping_type0" value="0"> 无需物流</label>
        <label class="checkbox-inline" style="float:left;margin-right:30px;"><input type="radio" name="shipping_type" id="shipping_type1" value="1" checked="checked"> 需要物流</label>
        <!-- <label class="checkbox-inline" style="float:left;"><input type="radio" name="shipping_type" id="shipping_type2" value="2"> 同城配送</label> -->
    </div>
    <div style="clear:both;"></div>
    <div class="form-group" id="express_input" style="">
        <span class="select-box" style="width: auto;float: left">
        <select class="select" id="divlogistics_express_company" style="width:200px;float:left;">
            <option value="0">请选择物流公司</option>
            <?php if(is_array($data['express_company_list']) || $data['express_company_list'] instanceof \think\Collection || $data['express_company_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['express_company_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ex): $mod = ($i % 2 );++$i;?>
            <option value="<?php echo $ex['co_id']; ?>"><?php echo $ex['company_name']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        </span>
        <div class="col-xs-5" style="float: left;">
            <input type="text" id="divlogistics_express_no" class="input-text radius" placeholder="请填写快递单号" style="height:32px;">
        </div>
    </div>
    <div class="form-group" id="same_city_express" style="display:none;">
        <span class="select-box" style="width: auto;float: left">
        <select class="select" id="express_platform" style="width:200px;float:left;">
        	<option value="0">请选择配送平台</option>
            <?php if(is_array($platform) || $platform instanceof \think\Collection || $platform instanceof \think\Paginator): $i = 0; $__LIST__ = $platform;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <option value="<?php echo $vo['id']; ?>"><?php echo $vo['name']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        </span>
        <div id="express_hint" style="float: left;margin: 5px 0 0 10px;">
            	
        </div>
    </div>
    <div id="receiver_info"><?php echo $data['order_info']['address']; ?><?php echo $data['order_info']['receiver_address']; ?>&nbsp;<?php echo $data['order_info']['receiver_mobile']; ?></div>
</div>
    <div class="modal-footer">
        <input type="hidden" id="delivery_order_id" value="<?php echo $data['order_info']['order_id']; ?>">
        <button class="btn btn-primary" onclick="orderDeliverySubmit()">提交更改</button>
        <button class="btn" onclick="shut_down()">关闭</button>
    </div>
</div>
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script>
    $("#shipping_type0").focus(function(){
        $("#express_input").hide();
        $("#same_city_express").hide();
    });
    $("#shipping_type1").focus(function(){
    	$("#same_city_express").hide();
        $("#express_input").show();
    });
    $("#shipping_type2").focus(function(){
    	$("#express_input").hide();
        $("#same_city_express").show();
    });
    //关闭
    function shut_down() {
        parent.layer.closeAll();
    }
    //全选
    function deliveryCheckAll(event){
        var checked = event.checked;
        $("input[type = 'checkbox'][value = 0]").prop("checked",checked);
        var obj = $("input[type = 'checkbox'][value = 0][checked]");
        $("#checkedbox").html(obj.length);
    }
    //单选
    function deliveryCheck(event){
        var obj = $("input[type = 'checkbox'][value = 0][checked]");
        $("#checkedbox").html(obj.length);
    }
    // 验证配送城市
    var city_code = '';
    $("#express_platform").on("change",function(){
    	var delivery_id = $(this).val();
    	var order_id = $("#delivery_order_id").val();
    	
    	if (delivery_id == "0") {
    		$("#express_hint").text('');
    		return;
    	}
    	
    	var index = layer.load();
   		$.ajax({
   			url: "<?php echo url('order/checkCity'); ?>",
   			type: "post",
   			data: {delivery_id:delivery_id,'order_id':order_id},
   			dataType: "text",
   			success: function(res){
   				if (res) {
   					city_code = res;
   					$("#express_hint").text('该城市支持配送~').css("color","green");
   				} else {
   					$("#express_hint").text('该城市暂不支持配送哦~').css("color","red");
   				}
   				layer.close(index);
   			}
   		});
    	
    })
    //提交
    function orderDeliverySubmit(){
        var order_id = $("#delivery_order_id").val();
//        var order_goods_id_array = '';
//        $("input[type = 'checkbox'][value = 0][checked]").each(function(i){
//            if(0==i){
//                order_goods_id_array = $(this).attr('id');
//            }else{
//                order_goods_id_array += (","+$(this).attr('id'));
//            }
//        });
//        if(order_goods_id_array == ''){
//            layer.msg("至少选择一个商品", {icon: 5, time: 1000});
//            return false;
//        }
        var express_name = $("#divlogistics_express_company").find("option:selected").text();
        var shipping_type = $('input[name="shipping_type"]:checked').val();
        var express_company_id = $("#divlogistics_express_company").val();
        var express_no = $("#divlogistics_express_no").val();
        var delivery_id = $("#express_platform").val();
        var req_data = {'order_id':order_id,"shipping_type":shipping_type};
        if(shipping_type == 1){
            if(express_company_id == "0"){
                layer.msg("请选择物流公司", {icon: 5, time: 1000});
                return false;
            }
            if(express_no == ""){
                layer.msg("请填写快递单号", {icon: 5, time: 1000});
                $("#divlogistics_express_no").focus();
                return false;
            }
            req_data = {'order_id':order_id,"express_name":express_name,"shipping_type":shipping_type,"express_company_id":express_company_id,"express_no":express_no};
        }
        if (shipping_type == 2) {
            if (delivery_id == "0") {
                layer.msg("请选择配送平台", {icon: 5, time: 1000});
                return false;
            }
            if (city_code == '') {
                layer.msg("该城市暂不支持配送哦~", {icon: 5, time: 1000});
                return false;
            }
            req_data = {'order_id':order_id,"shipping_type":shipping_type,"delivery_id":delivery_id,"city_code":city_code};
        }
        $.ajax({
            type : "post",
            url : "<?php echo url('order/doOrderDelivery'); ?>",
            data : req_data,
            success : function(data) {
                if (data['code'] > 0) {
                    layer.msg(data["message"], {icon: 1, time: 1000},function () {
                        window.parent.location.reload();
                    });
                } else {
                    layer.msg(data["message"], {icon: 5, time: 1000});
                }
            }
        });
    }
</script>
</body>
</html>