<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/arliki/red_one.html";i:1546855749;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/base.html";i:1547172750;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
    <script src="/public/js/jquery-2.1.1.js"></script>
    <script type="text/javascript" src="/public/js/vue.js"></script>
    <link href="./favicon.ico?v=<?php echo time(); ?>" rel="shortcut icon" type="image/x-icon"/>
    <link rel="stylesheet" href="/public/css/linecons.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/bast/bootstrap.css">
    <link rel="stylesheet" href="/public/static/bast/xenon-core.css">
    <link rel="stylesheet" href="/public/static/bast/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css?v=1.0"/>
    <link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
    <link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
    <script src="/public/js/all.js"></script>
    <script>
        var UM_SITE_ROOT = '__CONF_SITE__';
    </script>
    
    <style>.new_logo .logo-expanded {color:#fff;font-size:14px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:100px; display: block;margin-left: 10px;background: #000;border-radius: 4px; height: 30px; line-height: 30px; text-align: center;padding:0 5px;margin-top:15px;margin-bottom: 5px;} .input-text {margin-bottom:0 !important;} .top_menu { height:50px; line-height: 50px; background: #fff;width:calc(100% - 200px);position: fixed;z-index: 1;top:0;left:200px;border-bottom:1px solid #eeeeee;} .top_menu a {display:block;float:right;height:50px; line-height: 50px;width:100px; text-align: center;border-left:1px solid #eeeeee;} .clear {clear:both;} .btn {margin-bottom:0;} body {line-height: 1.6 !important; overflow-x: hidden;} .left_cur a i:before ,.left_cur ul li .cur_s .title ,.left_cur .cur_tit ,li.left_cur > a:before {color:#444 !important;} .left_cur {    background: rgba(55, 87, 109, 0.05);} .logo-env .new_logo {padding-left:36px;} .logo-env .new_logo .wq_logo {margin-left:-36px;width:28px;height: 28px;float: left;border-radius: 50%;} .logo-env .new_logo:after {clear:both;} .tool_box a span ,.tool_box a:hover span {color:#666 !important;} .left_btn_box {padding:3px 10px 0 10px;justify-content:center;display: flex;} .left_btn_box a {display:block;height: 28px; line-height: 26px;width:80px;color: #fff; text-align: center;    border-radius: 2px;} .left_btn_box a.btn_li01 {background:rgb(25, 200, 91);border-bottom-right-radius: 0; border-top-right-radius: 0;} .left_btn_box a.btn_li02 {background:rgb(0, 193, 222);border-bottom-left-radius: 0; border-top-left-radius: 0;} .left_btn_box a.btn_li01:hover {background:rgb(21, 186, 93);} .left_btn_box a.btn_li02:hover {background:rgb(2, 182, 209);} .wq_bottom_btn {position:fixed;bottom:0;left:230px;width:100%;background: #fff;justify-content:center;display: flex; height: 80px; line-height: 80px;} .sidebar-menu {min-width: 122px !important;width: 122px !important; overflow: hidden;background: #fff !important;} .main-menu-scroll{height: calc(100% - 130px);overflow-x: hidden;width: 200px;overflow-y: scroll;} .main-menu-scroll::-webkit-scrollbar {display: none;} .new_left_menu {width:120px; height: 100%;display: table-cell;position: relative;background: #253350;    z-index: 1;} .sidebar-menu.fixed .sidebar-menu-inner {left:86px !important;border-right: 1px solid #eeeeee;} .f_name_box {display: block; height: 50px; line-height: 50px;} .f_name_box.cur_name {background: rgba(255,255,255,1) !important;width: 120px} .new_left_menu a {text-decoration:none;} .new_left_menu a span {color:#b3b3b3;font-size:13px;} .new_left_menu a i {margin-left:17px;display:inline-block;color:#b3b3b3;margin-right: 5px;} .new_left_menu a.cur_name i ,.new_left_menu a.cur_name .big_class_name {color: #00a0e9;} .main-menu-scroll {width:122px !important;} /*		.sidebar-menu .main-menu a {color: #444 !important;background: rgba(55, 87, 109, 0.05);}*/ .sidebar-menu .main-menu a {color: #444 !important;padding-left:20px !important;} .sidebar-menu .main-menu .cur_s a ,.sidebar-menu .main-menu .cur_s a:visited ,.sidebar-menu .main-menu .left_cur ul li.cur_s a>span{ background: rgba(255, 255, 255, 1) !important;color: #00a0e9 !important;border-right: 1px solid #eeeeee;} .title.cur_tit {color:#444 !important;font-weight: bold;} /*		.left_cur {background:#fff !important;}*/ .cur_s .sidebar-menu .main-menu a {background:#fff !important;} .sidebar-menu .main-menu ul li a {padding-left:20px !important;} /*		.left_cur ul li a {background:#fff !important;}*/ .left_cur ul li {background:#fff !important;} .sidebar-menu .main-menu {margin-top:0 !important;} .top_big_class_name { height: 50px;line-height: 50px; text-align: center;overflow: hidden;border-bottom: 1px solid;white-space: nowrap;text-overflow: ellipsis;border-bottom: 1px solid #eeeeee;font-size:13px;} .new_logo {    display: block !important;} .sidebar-menu .main-menu .left_cur ul li a>span {color:#777777 !important;} .sidebar-menu .main-menu li.has-sub>a:before {content: '\f0d7' !important;} .main-menu-scroll {height:100% !important;} .page-container {position:absolute;padding-top: 40px;box-sizing: border-box;} .new_page_top {height:44px;width:100%;position: fixed;background:#253350;border-bottom: 1px solid #2f3d5a;z-index: 999999;} .sidebar-menu.fixed .sidebar-menu-inner {top:44px !important;} .new_logo {width:30px;height:30px;float: left;margin-top:7px;margin-left:18px;border-radius: 50%;border:2px solid rgba(255,255,255,0.5);overflow:hidden;} .new_logo img {width:26px;height:26px;} .app_name {color: #fff;font-size: 18px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;width: 155px;display: block; height:40px; line-height: 40px;margin-top:2px;margin-left:8px;float:left;} .new_page_top a  ,.new_page_top a:visited {color:#fff;text-decoration: none;} .new_page_top a:hover {color: #b3b3b3;text-decoration: none;} .sidebar-menu.fixed .sidebar-menu-inner {position:fixed !important;} .new_top_right {float:right;width:180px;height:44px; line-height: 44px;} .logout_box {width:153px; height: 44px;background:url(../../yb_tuangou/core/public/images/logout_icon.png) right center no-repeat;float:left;font-size:13px;margin-left:12px;} .left_menu_box {position:fixed;width:95px;top:44px;left:0;} .back_sys {width:100px; text-align: center;color:#fff;float:left;}</style>
</head>
<body class="page-body">
<div class="new_page_top">
    <div class="new_logo">
        <?php if($about['logo'] != ''): ?>
        <img src="<?php echo $about['logo']; ?>" class="wq_logo">
        <?php else: ?>
        <img src="/public/static/bast/img/wq_shop_logo.png" class="wq_logo">
        <?php endif; ?>
    </div>
    <a href="javascript:void(0);" class="app_name"><?php echo $xcx_name; ?></a>
    <div class="new_top_right">
        <div class="logout_box">
            <?php if($copyright['back_type'] == 1): ?>
                <a href="<?php echo url('login/wxapp'); ?>" class="back_sys">
                    <?php else: if(!empty($last_visit_url)): ?>
                        <a href="<?php echo $last_visit_url; ?>" class="back_sys">
                    <?php else: ?>
                        <a href="<?php echo $siteroot; ?>web/index.php?c=wxapp&a=version&do=home&version_id=<?php echo $version_id; ?>" class="back_sys">
                    <?php endif; endif; ?>
                返回系统
            </a>
            <a href="<?php echo url('login/logout'); ?>" class="right_logout">退出</a>
        </div>
        <div class="clear"></div>
    </div>
    <?php if($endtime['is_show'] ==1): ?>
    <div style="height:44px; line-height:44px;float:right;color:#b3b3b3;font-size:13px;margin-right:15px;">该账号使用有效期至 <?php echo $endtime['time']; ?>，将在<?php echo $endtime['days']; ?>天后过期，请及时付费 ！  </div>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<div class="page-container" style="border-collapse:inherit;">
    <div class="new_left_menu" >
        <div class="left_menu_box" id="top_menu">
            <ul v-for="(item, index) in list" >
                <a v-on:click="top_click(item)" href="javascript:void(0);" :class="item.class"><i :class="item.logo"></i><span class="big_class_name" v-text="item.module_name"></span></a>
                <ul :id="'second_'+item.module_id" name="second_menu">
                    <li v-if="item.sub.length>0" v-for="(v, k) in item.sub" v-on:click="sub_click(v)" v-bind:class="{'left_cur' : v.module_id == sub_mid, 'expanded' : expanded && v.module_id == sub_mid && item.sub.length > 0 }">
                        <a href="javascript:void(0);">
                            <span class="title" v-text="v.module_name"></span>
                        </a>
                    </li>
                </ul>
            </ul>
        </div>
    </div>
    <!--<div class="new_left_menu" >-->
        <!--<div class="left_menu_box" id="top_menu">-->
            <!--<ul v-for="(item, index) in list" >-->
                <!--<a v-on:click="top_click(item)" href="javascript:void(0);" :class="item.class"><i :class="item.logo"></i><span class="big_class_name" v-text="item.module_name"></span></a>-->
                    <!--<ul :id="'second_'+item.module_id" name="second_menu">-->
                        <!--<li v-if="item.sub.length>0" v-for="(v, k) in item.sub" v-on:click="sub_click(v)" v-bind:class="{'left_cur' : v.module_id == sub_mid, 'expanded' : expanded && v.module_id == sub_mid && item.sub.length > 0 }">-->
                            <!--<a href="javascript:void(0);">-->
                                <!--<span class="title" v-text="v.module_name"></span>-->
                            <!--</a>-->
                        <!--</li>-->
                    <!--</ul>-->
            <!--</ul>-->
        <!--</div>-->
    <!--</div>-->
    <div class="main-content">
        
<style>
    .input-text {padding-left:10px !important;}
    .panel {
        padding: 0 1rem;
        background: #fff;
    }
    .panel .panel-body {
        padding: 1rem 0;
    }
    .mb-3 {
        margin-bottom: 1rem!important;
    }
    .rounded-0 {
        border-radius: 0;
    }
    .alert-warning {
        border: 1px solid transparent;
        background-color: #fcf8e3;
        border-color: #faf2cc;
        color: #8a6d3b;
    }
</style>
<div class="Hui-article">
<article class="cl pd-20">
    <!--<h3 id="dont_touch_this0"></h3>-->
    <div id="tab_demo" class="HuiTab" style="margin-bottom: 15px; position:relative;">
        <div class="tabBar clearfix">
            <span class="current" onclick="load_page('__CONF_SITE__admin/arliki/redlist')" >裂变红包</span>
            <span onclick="load_page('__CONF_SITE__admin/arliki/red_share_log')">分享记录</span>
            <span onclick="load_page('__CONF_SITE__admin/arliki/red_split_log')">拆分记录</span>
        </div>
    </div>
    <form method="post" action="" id="mymp3" class="form form-horizontal" enctype="multipart/form-data">
        <input type="hidden" id="id" value="<?php echo $info['id']; ?>">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">开启活动：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="radio" id="status1" name="status" value="2" <?php if($info["status"]==2 || empty($info['status'])): ?>checked<?php endif; ?>><label for="status1">关闭</label>
                <input type="radio" id="status2" name="status" value="1" <?php if($info["status"]==1): ?>checked<?php endif; ?>><label for="status2">开启</label>
                <br>
                <span>关闭后所有未成团红包将拆分失败</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">弹屏展示：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="radio" id="status3" name="show_big" value="2" <?php if($info["show_big"]==2 || empty($info['show_big'])): ?>checked<?php endif; ?>><label for="status3">关闭</label>
                <input type="radio" id="status4" name="show_big" value="1" <?php if($info["show_big"]==1): ?>checked<?php endif; ?>><label for="status4">开启</label>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">背景图：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <img src="<?php echo (isset($info['bg_img']) && ($info['bg_img'] !== '')?$info['bg_img']:''); ?>" width="120"  alt="背景图" id="bg_img">
                <br>
                <input onclick="select_img('1','red_1');" class="btn btn-default" type="button" value="选择图片">
                <span>推荐规格：500*800</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">红包分配方式：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="radio" id="split_type3" name="split_type" value="1" <?php if($info["split_type"]==1 || empty($info['split_type'])): ?>checked<?php endif; ?>><label for="split_type3">平均</label>
                <!--<input type="radio" id="split_type2" name="split_type" value="2" <?php if($info["split_type"]==2): ?>checked<?php endif; ?>><label for="split_type2" title="有效分享量越多,拆分后红包越大">分享量</label>-->
                <input type="radio" id="split_type1" name="split_type" value="3" <?php if($info["split_type"]==3): ?>checked<?php endif; ?>><label for="split_type1">随机</label>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>红包人数：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="number" autocomplete="off" value="<?php echo (isset($info['peo_num']) && ($info['peo_num'] !== '')?$info['peo_num']:2); ?>" onblur="check_user()" class="input-text" id="peo_num"><span style="display: inline-block;height: 30px;width: 35px;background: #ddd;border: 1px solid #ddd;margin-left: -1px;line-height: 25px;text-align: center;">人</span>
                <br>
                <span>规定时间内达到这个人数后，红包成功拆分，最少2人，最多16人。减少人数则满足团立即发放优惠券</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>红包总金额：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="number" autocomplete="off" value="<?php echo (isset($info['money_num']) && ($info['money_num'] !== '')?$info['money_num']:0.02); ?>" onblur="check_money()" class="input-text" id="money_num"><span style="display: inline-block;height: 30px;width: 35px;background: #ddd;border: 1px solid #ddd;margin-left: -1px;line-height: 25px;text-align: center;">元</span>
                <br>
                <span>红包赠送的优惠券总金额，最低=红包人数*0.01元</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">优惠券门槛：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="number" id="use_least" value="<?php echo (isset($info['use_least']) && ($info['use_least'] !== '')?$info['use_least']:0); ?>" style="width: 480px;height: 30px"><span style="display: inline-block;height: 30px;width: 35px;background: #ddd;border: 1px solid #ddd;margin-left: -1px;line-height: 25px;text-align: center;">元</span>
                <br>
                <span>优惠券使用的最低消费金额，最低0元。修改会影响已发放用户使用门槛</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>优惠券有效期：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" id="vali_time" value="<?php echo (isset($info['vali_time']) && ($info['vali_time'] !== '')?$info['vali_time']:30); ?>" style="width: 480px;height: 30px"><span style="display: inline-block;height: 30px;width: 35px;background: #ddd;border: 1px solid #ddd;margin-left: -1px;line-height: 25px;text-align: center;">天</span>
                <br>
                <span>优惠券有效时间，从发放时间算起，默认30天。修改不影响已发放用户期限</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>拆红包有效时间：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" id="split_time" value="<?php echo (isset($info['split_time']) && ($info['split_time'] !== '')?$info['split_time']:24); ?>" style="width: 480px;height: 30px"><span style="display: inline-block;height: 30px;width: 35px;background: #ddd;border: 1px solid #ddd;margin-left: -1px;line-height: 25px;text-align: center;">小时</span>
                <br>
                <span>有效时间内用户可以邀请好友一起拆红包，过期则此红包作废，默认24小时。修改会影响已分享用户拆分时间</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">活动规则：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <textarea name="role" id="role" cols="30" rows="10" style="width: 515px"><?php echo (isset($info['role']) && ($info['role'] !== '')?$info['role']:''); ?></textarea>
                <br>
                <input type="button" id="show_role" value="规则示范" onclick="show_role1()">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">分享标题：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" id="share_title" value="<?php echo (isset($info['share_title']) && ($info['share_title'] !== '')?$info['share_title']:''); ?>" style="width: 515px;height: 30px">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">分享图：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <img src="<?php echo (isset($info['share_img']) && ($info['share_img'] !== '')?$info['share_img']:''); ?>" width="120"  alt="背景图" id="share_img">
                <br>
                <input onclick="select_img('1','red_2');" class="btn btn-default" type="button" value="选择图片">
                <span>规格：500*400</span>
            </div>
        </div>
    </form>
    <br>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-2">
                <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button"
                       value="&nbsp;&nbsp;保存&nbsp;&nbsp;">
            </div>
        </div>
</article>
</div>

    </div>

    <footer class="footer" style="background: #FFFFFF;height: 25px;margin-top: -5px;padding-top: 10px;line-height: 25px;">
        <p><?php echo $copyright['content']; ?></p>
        <?php if($show_we7): ?>
        <div class="container-fluid footer text-center" role="footer">
            <div class="friend-link" >
                <?php if(empty($_W['footerright'])): ?>
                <a href="http://www.we7.cc">微信开发</a>
                <a href="http://s.we7.cc">微信应用</a>
                <a href="http://bbs.we7.cc">微擎论坛</a>
                <a href="http://s.we7.cc">联系客服</a>
                <?php else: ?>
                <?php echo $_W['footerright']; endif; ?>
            </div>
            <div class="copyright"><?php if(empty($_W['footerleft'])): ?>Powered by <a href="http://www.we7.cc"><b>微擎</b></a> v<?php echo $version; ?> &copy; 2014-2015 <a href="http://www.we7.cc">www.we7.cc</a><?php else: ?><?php echo $_W['footerleft']; endif; ?></div>
            <?php if(!empty($_W['icp'])): ?><div>备案号：<a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $_W['icp']; ?></a></div><?php endif; ?>
        </div>
        <?php if(!empty($_W['statcode'])): ?><?php echo $_W['statcode']; endif; if(!empty($_GPC) && !in_array($_GPC, array('keyword', 'special', 'welcome', 'default', 'userapi')) || defined('IN_MODULE')): ?>
        <script>
            if(typeof $.fn.tooltip != 'function' || typeof $.fn.tab != 'function' || typeof $.fn.modal != 'function' || typeof $.fn.dropdown != 'function') {  require(['bootstrap']);}
        </script>
        <?php endif; endif; ?>
    </footer>
</div>
<script src="/public/static/bast/xenon-custom.js"></script>
<script src="/public/static/bast/clipboard.js"></script>
<script src="/public/static/bast/TweenMax.min.js"></script>
<script src="/public/static/bast/resizeable.js"></script>
<script src="/public/static/layer/2.4/layer.js"></script>
<script src="/public/js/public_js.js"></script>
<script src="/public/js/all.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>

<!--<script src="/public/menu/js/jquery.artdialog.js"></script>-->
<!--<script src="/public/menu/js/iframetools.js"></script>-->
<script type="text/javascript">
    function red_1(id,path) {
        $("#bg_img").attr("src",path);
    }
    function red_2(id,path) {
        $("#share_img").attr("src",path);
    }
    function select_img(number,type) {
        layer_open("我的图片001",'__CONF_SITE__admin/images/dialogalbumlist&number=' + number + '&type=' + type,900,620);
    }
    var flag = false;//防止重复提交
    //添加用户
    function addSuppAjax() {
        var c1=check_user();
        var c2=check_money();
        var c3=check_date();
        if (!flag && c1 && c2 && c3) {
            flag = true;
            $.ajax({
                type: "post",
                url: "<?php echo url('arliki/red_one'); ?>",
                data: {
                    "id":'<?php echo $info['id']; ?>',
                    "status":$("input[name=status]:checked").val(),
                    "show_big":$("input[name=show_big]:checked").val(),
                    "bg_img":$("#bg_img").attr("src"),
                    "split_type":$("input[name=split_type]:checked").val(),
                    "peo_num":$("#peo_num").val(),
                    "money_num":$("#money_num").val(),
                    "use_least":$("#use_least").val(),
                    "vali_time":$("#vali_time").val(),
                    "split_time":$("#split_time").val(),
                    "role":$("#role").val(),
                    "share_title":$("#share_title").val(),
                    "share_img":$("#share_img").attr("src"),
                },
                success:function(data) {
                    if (data['code'] > 0) {
                        layer.msg('修改成功!', {icon: 1, time: 1000}, function () {
                            parent_flash();
                        });
                    }
                    else {
                        flag = false;
                        layer.msg(data["message"], {icon: 5, time: 2000});
                    }
                }
            });
        }
    }
    //检测
    function check_user(){
        var a=$("#peo_num").val();
        if(a<2) {
            layer.msg('人数设置过低', {icon: 5, time: 1000});
            $("#peo_num").focus();
            return false;
        }else {
            if(a>16){
                layer.msg('人数设置过高', {icon: 5, time: 1000});
                $("#peo_num").focus();
                return false;
            }else {
                return true;
            }
        }
    }
    function check_money(){
        var a=$("#peo_num").val();
        var b=$("#money_num").val();
        if(a*0.01>b) {
            layer.msg('总金额设置过低', {icon: 5, time: 1000});
            $("#money_num").focus();
            return false;
        }else {
            return true;
        }
    }
    function check_date() {
        var vali_time=parseInt($("#vali_time").val());
        var split_time=parseInt($("#split_time").val());
        if(vali_time<1) {
            layer.msg('有效期设置过低', {icon: 5, time: 1000});
            $("#vali_time").focus();
            return false;
        }
        if(split_time<1) {
            layer.msg('红包拆分时间设置过低', {icon: 5, time: 1000});
            $("#split_time").focus();
            return false;
        }
        return true;
    }
    function show_role1(){
        layer.open({
            type:1,
            area: '500px',
            title:"示范规则",
            shadeClose:true,
            content:'<div class="panel-body"><div class="alert alert-warning mb-3 rounded-0">本规则仅供参考</div><ol style="list-style: none;padding: 0"><li>1.用户可邀请好友共同拆红包，满N人则拆红包现金红包成功，共同瓜分总金额为N元的红包，每人获得红包金额随机（或平均）。</li><li>2.每个红包发起后'+$("#split_time").val()+'小时未组满'+$("#peo_num").val()+'人即失败，无红包奖励。</li><li>3.活动期间，不能帮同一好友拆多次，但发起拆红包次数不限。</li><li>4.发起拆红包的用户需在该红包满'+$("#peo_num").val()+'人拆成功或逾期失败后，才可再发起拆下一个红包。</li><li>5.一起拆红包活动的红包均为满减优惠券。</li><li>6.本公司对该活动规则保留最终解释权。</li></ol><div class="text-center"></div></div>'
        })
    }
</script>

<script>
    var str;
    str = '<?php echo json_encode($all_menu); ?>';
    var all_menu = eval(decodeURIComponent(str));
    var root_url = "<?php global $_W; echo $_W['siteroot'].'addons/yb_tuangou/core/index.php?s=/admin/'; ?>";
    var top_mid = '<?php echo $top_mid; ?>';
    var sub_mid = '<?php echo $sub_mid; ?>';
    var three_mid = '<?php echo $three_mid; ?>';
    var sub_menu_arr = [];
    $(document).ready(function () {
        $("ul[name=second_menu]").hide();
        if(top_mid>0){
            $("#second_"+top_mid).show();
        }
    });
    all_menu.forEach(function (item, index) {
        if(item.module_id == top_mid)
        {
            item.class = 'f_name_box cur_name';
            sub_menu_arr = item.sub? item.sub : [];
        }
        else
        {
            item.class = 'f_name_box';
        }
    });
    var top_menu = new Vue({
        el: '#top_menu',
        data: {
            list:all_menu,
            top_mid: top_mid,
            root_url : root_url,
            sub_mid: sub_mid,
            three_mid: three_mid,
            expanded:sub_mid > 0,
            show:true,
        },
        methods:{
            top_click:function (top_item) {
                if(this.top_mid != top_item.module_id)
                {
                    this.show=true;
                    var sub_menu=this;
                    $("ul[name=second_menu]").hide();
                    $("#second_"+top_item.module_id).show();
                    var val = top_item.module_id;
                    this.top_mid = val;
                    sub_menu.expanded = false;
                    document.cookie = "top_mid=" + val;
                    if(top_item.sub.length > 0)
                    {
                        this.list.forEach(function (item, index) {
                            if(item.module_id == val)
                            {
                                item.class = 'f_name_box cur_name';
//                                sub_menu.list = item.sub;
                                sub_menu.sub_mid = 0;
                                sub_menu.three_mid = 0;
                                if(sub_menu.list != null && sub_menu.list != undefined)
                                {
                                    if(sub_menu.list.length > 0)
                                    {
                                        sub_menu.expanded = true;
                                        sub_menu.sub_mid = sub_menu.list[0]['module_id'];
                                    }
                                }
                            }
                            else
                            {
                                item.class = 'f_name_box';
                            }
                        });
                    }
                    else
                    {
                        window.location.href = this.root_url+top_item.url;
                    }
                }else {
                    this.show=!this.show;
                    $("ul[name=second_menu]").hide();
                    if(this.show){
                        $("#second_"+top_item.module_id).show();
                    }
                }
            },
            sub_click: function (item) {
                this.expanded = this.sub_mid == item.module_id ? !this.expanded : true;
                this.sub_mid = item.module_id;
                document.cookie = "sub_mid=" + item.module_id;
                if(item.sub.length == 0)
                {
                    window.location.href = this.root_url+item.url;
                }
            },
            three_click: function (item) {
                this.three_mid = item.module_id;
                document.cookie = "three_mid=" + item.module_id;
                window.location.href = this.root_url+item.url;
            }
        },
    });
//    var sub_menu = new Vue({
//        el: '#sub_menu',
//        data: {
//            list:sub_menu_arr,
//            sub_mid: sub_mid,
//            three_mid: three_mid,
//            expanded:sub_mid > 0,
//            root_url : root_url,
//        },
//        methods:{
//            sub_click: function (item) {
//                this.expanded = this.sub_mid == item.module_id ? !this.expanded : true;
//                this.sub_mid = item.module_id;
//                document.cookie = "sub_mid=" + item.module_id;
//                if(item.sub.length == 0)
//                {
//                    window.location.href = this.root_url+item.url;
//                }
//            },
//            three_click: function (item) {
//                this.three_mid = item.module_id;
//                document.cookie = "three_mid=" + item.module_id;
//                window.location.href = this.root_url+item.url;
//            }
//        },
//    });
</script>
</body>
</html>