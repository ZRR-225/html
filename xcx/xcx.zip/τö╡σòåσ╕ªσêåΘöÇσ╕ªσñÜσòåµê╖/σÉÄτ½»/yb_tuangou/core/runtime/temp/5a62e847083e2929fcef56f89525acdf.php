<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:78:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/article/add_article.html";i:1547712128;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/base.html";i:1550644207;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
    <script src="/public/js/jquery-2.1.1.js"></script>
    <script type="text/javascript" src="/public/js/vue.js"></script>
    <link href="./favicon.ico?v=<?php echo time(); ?>" rel="shortcut icon" type="image/x-icon"/>
    <link rel="stylesheet" href="/public/css/linecons.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/bast/bootstrap.css">
    <link rel="stylesheet" href="/public/static/bast/xenon-core.css">
    <link rel="stylesheet" href="/public/static/bast/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css?v=1.1"/>
    <link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
    <link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
    <script src="/public/js/all.js"></script>
    <script>
        var UM_SITE_ROOT = '__CONF_SITE__';
    </script>
    
    <style>.new_logo .logo-expanded {color:#fff;font-size:14px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:100px; display: block;margin-left: 10px;background: #000;border-radius: 4px; height: 30px; line-height: 30px; text-align: center;padding:0 5px;margin-top:15px;margin-bottom: 5px;} .input-text {margin-bottom:0 !important;} .top_menu { height:50px; line-height: 50px; background: #fff;width:calc(100% - 200px);position: fixed;z-index: 1;top:0;left:200px;border-bottom:1px solid #eeeeee;} .top_menu a {display:block;float:right;height:50px; line-height: 50px;width:100px; text-align: center;border-left:1px solid #eeeeee;} .clear {clear:both;} .btn {margin-bottom:0;} body {line-height: 1.6 !important; overflow-x: hidden;} .left_cur a i:before ,.left_cur ul li .cur_s .title ,.left_cur .cur_tit ,li.left_cur > a:before {color:#444 !important;} .left_cur {    } .logo-env .new_logo {padding-left:36px;} .logo-env .new_logo .wq_logo {margin-left:-36px;width:28px;height: 28px;float: left;border-radius: 50%;} .logo-env .new_logo:after {clear:both;} .tool_box a span ,.tool_box a:hover span {color:#666 !important;} .left_btn_box {padding:3px 10px 0 10px;justify-content:center;display: flex;} .left_btn_box a {display:block;height: 28px; line-height: 26px;width:80px;color: #fff; text-align: center;    border-radius: 2px;} .left_btn_box a.btn_li01 {background:rgb(25, 200, 91);border-bottom-right-radius: 0; border-top-right-radius: 0;} .left_btn_box a.btn_li02 {background:rgb(0, 193, 222);border-bottom-left-radius: 0; border-top-left-radius: 0;} .left_btn_box a.btn_li01:hover {background:rgb(21, 186, 93);} .left_btn_box a.btn_li02:hover {background:rgb(2, 182, 209);} .wq_bottom_btn {position:fixed;bottom:0;left:230px;width:100%;background: #fff;justify-content:center;display: flex; height: 80px; line-height: 80px;} .sidebar-menu {min-width: 122px !important;width: 122px !important; overflow: hidden;background: #fff !important;} .main-menu-scroll{height: calc(100% - 130px);overflow-x: hidden;width: 200px;overflow-y: scroll;} .main-menu-scroll::-webkit-scrollbar {display: none;} .new_left_menu {width:180px; height: 100%;display: table-cell;position: relative;background: #fafafa;z-index: 1;border-right: 1px solid #e7e7f0;overflow: auto;} .sidebar-menu.fixed .sidebar-menu-inner {left:86px !important;border-right: 1px solid #eeeeee;} .f_name_box {display: block; height: 50px; line-height: 50px;color: #504f5c;} .f_name_box.cur_name {width: 180px} .new_left_menu a {text-decoration:none;height: 30px;line-height: 26px;margin-top: 10px;} .new_left_menu a span {font-size:12px;margin-left: 16px;} .new_left_menu a i {margin-left:18px;display:inline-block;color:#b3b3b3;} .new_left_menu a.cur_name i ,.new_left_menu a.cur_name .big_class_name {color: #503eff;} .main-menu-scroll {width:122px !important;} /*		.sidebar-menu .main-menu a {color: #444 !important;background: rgba(55, 87, 109, 0.05);}*/ .sidebar-menu .main-menu a {color: #444 !important;padding-left:20px !important;} .sidebar-menu .main-menu .cur_s a ,.sidebar-menu .main-menu .cur_s a:visited ,.sidebar-menu .main-menu .left_cur ul li.cur_s a>span{ background: rgba(255, 255, 255, 1) !important;color: #00a0e9 !important;border-right: 1px solid #eeeeee;} .title.cur_tit {color:#444 !important;font-weight: bold;} /*		.left_cur {background:#fff !important;}*/ .cur_s .sidebar-menu .main-menu a {background:#fff !important;} .sidebar-menu .main-menu ul li a {padding-left:20px !important;} /*		.left_cur ul li a {background:#fff !important;}*/ .left_cur ul li {background:#fff !important;} .sidebar-menu .main-menu {margin-top:0 !important;} .top_big_class_name { height: 50px;line-height: 50px; text-align: center;overflow: hidden;border-bottom: 1px solid;white-space: nowrap;text-overflow: ellipsis;border-bottom: 1px solid #eeeeee;font-size:13px;} .new_logo {    display: block !important;} .sidebar-menu .main-menu .left_cur ul li a>span {color:#777777 !important;} .sidebar-menu .main-menu li.has-sub>a:before {content: '\f0d7' !important;} .main-menu-scroll {height:100% !important;} .page-container {position:absolute;padding-top: 40px;box-sizing: border-box;} .new_page_top {height:44px;width:100%;position: fixed;background:#1d1a3b;border-bottom: 1px solid #2f3d5a;z-index: 999999;} .sidebar-menu.fixed .sidebar-menu-inner {top:44px !important;} .new_logo {width:30px;height:30px;float: left;margin-top:7px;margin-left:18px;border-radius: 50%;border:2px solid rgba(255,255,255,0.5);overflow:hidden;} .new_logo img {width:26px;height:26px;} .app_name {color: #fff;font-size: 18px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;width: 155px;display: block; height:40px; line-height: 40px;margin-top:2px;margin-left:8px;float:left;} .new_page_top a  ,.new_page_top a:visited {color:#fff;text-decoration: none;} .new_page_top a:hover {color: #b3b3b3;text-decoration: none;} .sidebar-menu.fixed .sidebar-menu-inner {position:fixed !important;} .new_top_right {float:right;width:180px;height:44px; line-height: 44px;} .logout_box {width:153px; height: 44px;background:url(../../yb_tuangou/core/public/images/logout_icon.png) right center no-repeat;float:left;font-size:13px;margin-left:12px;} .left_menu_box {position:fixed;width:180px;top:44px;left:0;} .back_sys {width:100px; text-align: center;color:#fff;float:left;}.f_name_box:hover{color: #504f5c;background: #f3f3f3;text-decoration: none;}.ul_style .left_cur a{color: #503eff;}.ul_style li:hover{background: #f3f3f3;}.ul_style a{color: #7f7d8e;}.ul_style li:hover a span{color: #504f5c; }.ul_style .left_cur:hover a span{color: #503eff;}.ul_style li a{margin-left: 34px;}.jt{position: absolute;right: 10px;margin-top: -14px}.ul_style li a:hover{text-decoration: none;}.f_name_box.cur_name{text-decoration: none;}

    </style>
</head>
<body class="page-body">
<div class="new_page_top">
    <div class="new_logo">
        <?php if($about['logo'] != ''): ?>
        <img src="<?php echo $about['logo']; ?>" class="wq_logo">
        <?php else: ?>
        <img src="/public/static/bast/img/wq_shop_logo.png" class="wq_logo">
        <?php endif; ?>
    </div>
    <a href="javascript:void(0);" class="app_name"><?php echo $xcx_name; ?></a>
    <div class="new_top_right">
        <div class="logout_box">
            <?php if($copyright['back_type'] == 1): ?>
                <a href="<?php echo url('login/wxapp'); ?>" class="back_sys">
                    <?php else: if(!empty($last_visit_url)): ?>
                        <a href="<?php echo $last_visit_url; ?>" class="back_sys">
                    <?php else: ?>
                        <a href="<?php echo $siteroot; ?>web/index.php?c=wxapp&a=version&do=home&version_id=<?php echo $version_id; ?>" class="back_sys">
                    <?php endif; endif; ?>
                返回系统
            </a>
            <a href="<?php echo url('login/logout'); ?>" class="right_logout">退出</a>
        </div>
        <div class="clear"></div>
    </div>
    <?php if($endtime['is_show'] ==1): ?>
    <div style="height:44px; line-height:44px;float:right;color:#b3b3b3;font-size:13px;margin-right:15px;">该账号使用有效期至 <?php echo $endtime['time']; ?>，将在<?php echo $endtime['days']; ?>天后过期，请及时付费 ！  </div>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<div class="page-container" style="border-collapse:inherit;">
    <div class="new_left_menu" >
        <div class="left_menu_box" id="top_menu">
            <ul v-for="(item, index) in list" >
                <a v-on:click="top_click(item)" href="javascript:void(0);" :class="item.class"><i>
                    <img v-if="top_mid==item.module_id" :src="'public/images/aside_icon/'+item.logo+'_p.png'" alt="" >
                    <img v-else :src="'public/images/aside_icon/'+item.logo+'_n.png'" >
                </i><span class="big_class_name" v-text="item.module_name"></span>
                    <div v-if="item.sub.length>0">
                    <img src="public/images/aside_icon/ic_menu_top.png" v-if="top_mid==item.module_id && show" alt="" class="jt">
                    <img src="public/images/aside_icon/ic_menu_bot.png" v-else alt="" class="jt">
                    </div>
                </a>
                <ul :id="'second_'+item.module_id" name="second_menu" class="ul_style">
                    <li  v-if="item.sub.length>0" v-for="(v, k) in item.sub" v-on:click="sub_click(v)" v-bind:class="{'left_cur' : v.module_id == sub_mid, 'expanded' : expanded && v.module_id == sub_mid && item.sub.length > 0 }">
                        <a href="javascript:void(0);">
                            <span class="title" v-text="v.module_name"></span>
                        </a>
                    </li>
                </ul>
            </ul>
        </div>
    </div>
    <div class="main-content">
        
<style>
    input[type="checkbox"] + label::before {
        content: "\a0";  /*不换行空格*/
        display: inline-block;
        vertical-align: .2em;
        height: 18px;
        width: 18px;
        font-size: 22px;
        margin-right: .2em;
        border-radius: .2em;
        background-color: white;
        border: 1px solid #93a1a1;
        text-indent: .15em;
        line-height: .65;  /*行高不加单位，子元素将继承数字乘以自身字体尺寸而非父元素行高*/
    }
    input[type="checkbox"]:checked + label::before {
        content: "\2714";
        background-color:#00a0e9;
        color: white;
        height: 18px;
        width: 18px;
        font-size: 22px;
    }
    input[type="checkbox"] {
        position: absolute;
        clip: rect(0, 0, 0, 0);
        cursor:pointer;
    }
</style>
<meta name="referrer" content="never">
<link href="/public/static/umedito/themes/default/_css/umeditor.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/public/css/defau.css">
<script type="text/javascript" src="/public/static/umedito/third-party/jquery.min.js"></script>
<script type="text/javascript" src="/public/static/umedito/third-party/template.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/public/static/umedito/umeditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/public/static/umedito/_examples/editor_api.js"></script>
<script type="text/javascript" src="/public/static/umedito/lang/zh-cn/zh-cn.js"></script>
<article class="cl pd-20">
    <div id="tab_demo" class="HuiTab" style="margin-bottom: 15px; position:relative;">
        <div class="tabBar clearfix">
            <span onclick="window.location.href='__CONF_SITE__admin/article/article_list'">文章列表</span>
            <span class="current">添加文章</span>
            <div class="l n_tab_add" style="width: auto;">
                <button type="button" class="btn btn-search radius"
                        onclick="gather('微信文章一键采集','__CONF_SITE__admin/article/collect','650px','300px')">
                    微信文章一键采集
                </button>
            </div>
        </div>
    </div>
    <form action="" method="post" class="form form-horizontal" id="">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>文章标题：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <input type="text" autocomplete="off" value="" placeholder="文章标题" class="input-text" id="title">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>短标题：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <input type="text" autocomplete="off" value="" placeholder="短标题" class="input-text" id="short_title">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>文章分类：</label>
            <div class="formControls col-xs-8 col-sm-2">
                <span class="select-box">
					<select class="select" size="1" id="class_id">
						<option value="-1">请选择</option>
                        <?php if(is_array($class) || $class instanceof \think\Collection || $class instanceof \think\Paginator): $i = 0; $__LIST__ = $class;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$c): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $c['class_id']; ?>">
                          <?php if($c['level']==1): ?>
                                    <?php echo $c['name']; endif; if($c['level']==2): ?>
                                    &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $c['name']; endif; ?>
                        </option>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
					</select>
				</span>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>作者：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <input type="text" autocomplete="off" value="" class="input-text" placeholder="作者" id="author">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">阅读量：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <input type="text" autocomplete="off" value="" class="input-text" placeholder="阅读量" id="click">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">文章关键字：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <input type="text" autocomplete="off" value="" class="input-text" placeholder="文章关键字" id="keyword">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">直接链接：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <input type="text" autocomplete="off" value="" class="input-text" placeholder="直接链接" id="link">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">是否推荐：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <div class="formControls col-xs-8 col-sm-3">
                    <input type="checkbox" id="is_recommend">
                    <label for="is_recommend">&nbsp;</label>
                </div>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>封面图片：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <p style="height: 165px;width:165px;border: dashed 1px #e5e5e5">
                    <img src="" alt="" id="imgarticle_pic" class="thumbnail">
                </p>
                <div style="position: absolute;top:50px;left:200px;color: #ccc;">图片尺寸根据文章列表样式而定<br>
                    图文横排-建议图片尺寸：200*200px<br>
                    图文竖排-建议图片尺寸：600*300px
                </div>
                <div class="upload-btn">
				<span>
					<input type="hidden" value="" id="article_pic"/>
				</span>
                    <!--<input class="btn radius btn-primary" onclick="on_upload()" type="button" value="上传图片">-->
                    <input onclick="select_img('1','zhu');" class="btn btn-default" type="button" value="选择图片">
                </div>
            </div>
        </div>
        <div class="row cl" style="margin-bottom: 100px;">
            <label class="form-label col-xs-4 col-sm-2"><span class="c-red">*</span>内容：</label>
            <div class="formControls col-xs-8 col-sm-8">
                <textarea id="editor" type="text/plain" style="width: 100%; height: 500px;"></textarea>
            </div>
        </div>
        <div class="row cl wq_bottom_btn" style="position: absolute;left: 10px;">
            <div>
                <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button"
                       style="bottom:0rem;z-index: 999999999;"value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
    </form>
</article>

    </div>

    <footer class="footer" style="background: #FFFFFF;height: 25px;margin-top: -5px;padding-top: 10px;line-height: 25px;">
        <!--<p><?php echo $copyright['content']; ?></p>-->
        <?php if($show_we7): ?>
        <div class="container-fluid footer text-center" role="footer">
            <div class="friend-link" >
                <?php if(empty($_W['footerright'])): ?>
                <a href="http://www.we7.cc">微信开发</a>
                <a href="http://s.we7.cc">微信应用</a>
                <a href="http://bbs.we7.cc">微擎论坛</a>
                <a href="http://s.we7.cc">联系客服</a>
                <?php else: ?>
                <?php echo $_W['footerright']; endif; ?>
            </div>
            <div class="copyright"><?php if(empty($_W['footerleft'])): ?>Powered by <a href="http://www.we7.cc"><b>微擎</b></a> v<?php echo $version; ?> &copy; 2014-2015 <a href="http://www.we7.cc">www.we7.cc</a><?php else: ?><?php echo $_W['footerleft']; endif; ?></div>
            <?php if(!empty($_W['icp'])): ?><div>备案号：<a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $_W['icp']; ?></a></div><?php endif; ?>
        </div>
        <?php if(!empty($_W['statcode'])): ?><?php echo $_W['statcode']; endif; if(!empty($_GPC) && !in_array($_GPC, array('keyword', 'special', 'welcome', 'default', 'userapi')) || defined('IN_MODULE')): ?>
        <script>
            if(typeof $.fn.tooltip != 'function' || typeof $.fn.tab != 'function' || typeof $.fn.modal != 'function' || typeof $.fn.dropdown != 'function') {  require(['bootstrap']);}
        </script>
        <?php endif; endif; ?>
    </footer>
</div>
<script src="/public/static/bast/xenon-custom.js"></script>
<script src="/public/static/bast/clipboard.js"></script>
<script src="/public/static/bast/TweenMax.min.js"></script>
<script src="/public/static/bast/resizeable.js"></script>
<script src="/public/static/layer/2.4/layer.js"></script>
<script src="/public/js/public_js.js"></script>
<script src="/public/js/all.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>

<script src="/public/js/ajax_file_upload.js" type="text/javascript"></script>
<script src="/public/js/file_upload.js" type="text/javascript"></script>
<script src="/public/menu/js/jquery.artdialog.js"></script>
<script src="/public/menu/js/iframetools.js"></script>
<script type="text/javascript">
    var ue = UM.getEditor('editor', {
        imageUrl: "__CONF_SITE__app/Umupload/uploadFile", //处理图片上传的接口
        imageFieldName: "upfile", //上传图片的表单的name
        imagePath: ""
    });
    function pickrsve(url) {
        $.ajax({
            type: "post",
            url: "<?php echo url('admin/article/collect'); ?>",
            data: {
                url: url
            },
            success: function (data) {
                $('#title').val(data['title']);
                $('#short_title').val(data['short_title']);
                $('#author').val(data['nickname']);
                $('#imgarticle_pic').attr('src', data['msg_img']);
                $('#article_pic').val(data['msg_img']);
                ue.setContent(data['content']);
            }
        });
    }
    function gather(title, url, w, h) {
        layer.open({
            type: 2,
            area: [w, h],
            fix: false, //不固定
            maxmin: true,
            shade: 0.4,
            title: title,
            content: url,
            scrollbar: false
        });
    }
    //模块输入信息验证
    function verify(title, short_title, class_id, author, content, article_pic) {
        if (title == '') {
            layer.msg('文章标题不能为空', {icon: 5, time: 1000});
            return false;
        }
        if (short_title == '') {
            layer.msg('文章短标题不能为空', {icon: 5, time: 1000});
            return false;
        }
        if (class_id == '-1') {
            layer.msg('请选择文章类型', {icon: 5, time: 1000});
            return false;
        }
        if (author == '') {
            layer.msg('作者不能为空', {icon: 5, time: 1000});
            return false;
        }
        if (article_pic == '') {
            layer.msg('文章封面不能为空', {icon: 5, time: 1000});
            return false;
        }
//        if (content == '') {
//
//            layer.msg('内容不能为空', {icon: 5, time: 1000});
//
//            return false;
//
//        }
        return true;
    }
    var flag = false;//防止重复提交
    //添加用户
    function addSuppAjax() {
        var title = $("#title").val();
        var short_title = $("#short_title").val();
        var class_id = $("#class_id").val();
        var keyword = $("#keyword").val();
        var author = $("#author").val();
        var click = $("#click").val();
        var content = UM.getEditor('editor').getContent();
        var article_pic = $("#article_pic").val();
        var goods_id_array = $("#goods_id_array").val();
        var link=$("#link").val();
        if ($("#is_recommend").prop("checked")) {
            var is_recommend = 1;
        } else {
            var is_recommend = 0;
        }
        if (verify(title, short_title, class_id, author, content, article_pic) && !flag) {
            flag = true;
            $.ajax({
                type: "post",
                url: "<?php echo url('admin/article/add_article'); ?>",
                data: {
                    'title': title,
                    'short_title': short_title,
                    'class_id': class_id,
                    'keyword': keyword,
                    'author': author,
                    'click': click,
                    'content': content,
                    'article_pic': article_pic,
                    'is_recommend': is_recommend,
                    'goods_array': goods_id_array,
                    'link':link
                },
                success: function (data) {
                    if (data['code'] > 0) {
                        layer.msg('添加成功!', {icon: 1, time: 1000}, function () {
                            window.parent.location.href = "__CONF_SITE__admin/article/article_list";
                        });
                    }
                    else {
                        flag = false;
                        layer.msg('添加失败', {icon: 5, time: 1000});
                    }
                }
            });
        }
    }
    function zhu_images(id,path) {
        $("#article_pic").val(path);
        $("#imgarticle_pic").attr('src',path);
    }
    function select_img(number,type) {
        art.dialog.open(('__CONF_SITE__admin/images/dialogalbumlist&number=' + number + '&type=' + type), {
            lock : true,
            title : "我的图片",
            width : 900,
            height : 620,
            drag : false,
            background : "#000000",
            scrollbar:false,
        }, true);
    }
</script>

<script>
    var str;
    str = '<?php echo json_encode($all_menu); ?>';
    var all_menu = eval(decodeURIComponent(str));
    var root_url = "<?php global $_W; echo $_W['siteroot'].'addons/yb_tuangou/core/index.php?s=/admin/'; ?>";
    var top_mid = '<?php echo $top_mid; ?>';
    var sub_mid = '<?php echo $sub_mid; ?>';
    var three_mid = '<?php echo $three_mid; ?>';
    var sub_menu_arr = [];
    $(document).ready(function () {
        $("ul[name=second_menu]").hide();
        if(top_mid>0){
            $("#second_"+top_mid).show();
        }
    });
    all_menu.forEach(function (item, index) {
        if(item.module_id == top_mid)
        {
            item.class = 'f_name_box cur_name';
            sub_menu_arr = item.sub? item.sub : [];
        }
        else
        {
            item.class = 'f_name_box';
        }
    });
    var top_menu = new Vue({
        el: '#top_menu',
        data: {
            list:all_menu,
            top_mid: top_mid,
            root_url : root_url,
            sub_mid: sub_mid,
            three_mid: three_mid,
            expanded:sub_mid > 0,
            show:true,
        },
        methods:{
            top_click:function (top_item) {
                if(this.top_mid != top_item.module_id)
                {
                    this.show=true;
                    var sub_menu=this;
                    $("ul[name=second_menu]").hide();
                    $("#second_"+top_item.module_id).show();
                    var val = top_item.module_id;
                    this.top_mid = val;
                    sub_menu.expanded = false;
                    document.cookie = "top_mid=" + val;
                    if(top_item.sub.length > 0)
                    {
                        this.list.forEach(function (item, index) {
                            if(item.module_id == val)
                            {
                                item.class = 'f_name_box cur_name';
//                                sub_menu.list = item.sub;
                                sub_menu.sub_mid = 0;
                                sub_menu.three_mid = 0;
                                if(sub_menu.list != null && sub_menu.list != undefined)
                                {
                                    if(sub_menu.list.length > 0)
                                    {
                                        sub_menu.expanded = true;
                                        sub_menu.sub_mid = sub_menu.list[0]['module_id'];
                                    }
                                }
                            }
                            else
                            {
                                item.class = 'f_name_box';
                            }
                        });
                    }
                    else
                    {
                        window.location.href = this.root_url+top_item.url;
                    }
                }else {
                    this.show=!this.show;
                    $("ul[name=second_menu]").hide();
                    if(this.show){
                        $("#second_"+top_item.module_id).show();
                    }
                }
            },
            sub_click: function (item) {
                this.expanded = this.sub_mid == item.module_id ? !this.expanded : true;
                this.sub_mid = item.module_id;
                document.cookie = "sub_mid=" + item.module_id;
                if(item.sub.length == 0)
                {
                    window.location.href = this.root_url+item.url;
                }
            },
            three_click: function (item) {
                this.three_mid = item.module_id;
                document.cookie = "three_mid=" + item.module_id;
                window.location.href = this.root_url+item.url;
            }
        },
    });
</script>
</body>
</html>