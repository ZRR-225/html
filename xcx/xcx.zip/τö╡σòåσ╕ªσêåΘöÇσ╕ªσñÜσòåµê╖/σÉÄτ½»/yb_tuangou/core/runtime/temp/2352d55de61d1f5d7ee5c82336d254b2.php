<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/goods/goods_attr_mod_add.html";i:1547714826;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.admin.css"/>
</head>
<style>
    input[type="checkbox"] + label::before {
        content: "\a0";  /*不换行空格*/
        display: inline-block;
        vertical-align: .2em;
        height: 18px;
        width: 18px;
        font-size: 22px;
        margin-right: .2em;
        border-radius: .2em;
        background-color: white;
        border: 1px solid #93a1a1;
        text-indent: .15em;
        line-height: .65;  /*行高不加单位，子元素将继承数字乘以自身字体尺寸而非父元素行高*/
    }
    input[type="checkbox"]:checked + label::before {
        content: "\2714";
        background-color:#00a0e9;
        color: white;
        height: 18px;
        width: 18px;
        font-size: 22px;
    }
    input[type="checkbox"] {
        position: absolute;
        clip: rect(0, 0, 0, 0);
        cursor:pointer;
    }
    .chec input[type="checkbox"] + label::before {
        content: "\a0";  /*不换行空格*/
        display: inline-block;
        vertical-align: .2em;
        height: 18px;
        width: 18px;
        font-size: 22px;
        margin-right: .2em;
        border-radius: .2em;
        background-color: white;
        border: 1px solid #93a1a1;
        text-indent: .15em;
        line-height: .65;  /*行高不加单位，子元素将继承数字乘以自身字体尺寸而非父元素行高*/
    }
    .chec input[type="checkbox"]:checked + label::before {
        content: "\2714";
        background-color:green;
        color: white;
        height: 18px;
        width: 18px;
        font-size: 22px;
    }
   .chec input[type="checkbox"] {
        position: absolute;
        clip: rect(0, 0, 0, 0);
        cursor:pointer;
    }
</style>
<body>
<article class="cl pd-20">
    <form action="" method="post" class="form form-horizontal" id="">
        <div class="row cl">
            <label class="form-label col-xs-3 col-sm-3"><span class="c-red">*</span>分类名称：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" value="" placeholder="分类名称" class="input-text" id="attr_name">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-3 col-sm-3"><span class="c-red">*</span>排序：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" value="0" placeholder="排序" class="input-text" id="sort">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-3 col-sm-3">是否启用：</label>
            <div class="formControls col-xs-8 col-sm-9">
                    <input type="checkbox" checked id="is_use">
                    <label for="is_use">&nbsp;</label>
            </div>
        </div>
        <div class="row cl chec">
            <label class="form-label col-xs-3 col-sm-3">关联规格：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <?php if(is_array($spec_list) || $spec_list instanceof \think\Collection || $spec_list instanceof \think\Paginator): $i = 0; $__LIST__ = $spec_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$s): $mod = ($i % 2 );++$i;?>
                <dl class="permission-list">
                    <dt>
                        <label>
                            <input type="checkbox" value="<?php echo $s['spec_id']; ?>" id="a-<?php echo $s['spec_id']; ?>"  name="spec_id">
                            <label for="a-<?php echo $s['spec_id']; ?>"><?php echo $s['spec_name']; ?></label>
                        </label>
                    </dt>
                    <?php if(is_array($s['spec_value_list']) || $s['spec_value_list'] instanceof \think\Collection || $s['spec_value_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $s['spec_value_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                    <dd>
                        <dl class="cl permission-list2">
                            <dt>
                                <label class="">
                                    <?php echo $v['spec_value_name']; ?>
                                   </label>
                            </dt>
                        </dl>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <div class="row cl chec">
            <label class="form-label col-xs-3 col-sm-3">关联属性：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <?php if(is_array($attr_value) || $attr_value instanceof \think\Collection || $attr_value instanceof \think\Paginator): $i = 0; $__LIST__ = $attr_value;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$atv): $mod = ($i % 2 );++$i;?>
                <dl class="permission-list">
                    <dt>
                        <label>
                            <input type="checkbox" id="b-<?php echo $atv['attr_value_id']; ?>" value="<?php echo $atv['attr_value_id']; ?>" name="attr_value_id">
                            <label for="b-<?php echo $atv['attr_value_id']; ?>"><?php echo $atv['attr_value_name']; ?></label>
                        </label>
                    </dt>
                    <dd>
                        <dl class="cl permission-list2">
                            <dt>
                                <label class="">
                                    <?php echo $atv['value']; ?>
                                </label>
                            </dt>
                        </dl>
                    </dd>
                </dl>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
    </form>
</article>
<script type="text/javascript" src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script src="/public/js/ajax_file_upload.js" type="text/javascript"></script>
<script src="/public/js/file_upload.js" type="text/javascript"></script>
<script type="text/javascript">
    $(function(){
        $('.skin-minimal input').iCheck({
            checkboxClass: 'icheckbox-blue',
            radioClass: 'iradio-blue',
            increaseArea: '20%'
        });
    });
    //模块输入信息验证
    function verify(attr_name,sort) {
        if (attr_name == '') {
            layer.msg('请填写分类名称', {icon: 5, time: 1000});
            return false;
        }
        if (sort == '') {
            layer.msg('请填写排序', {icon: 5, time: 1000});
            return false;
        }
        return true;
    }
    var flag = false;//防止重复提交
    //提交
    function addSuppAjax() {
        var attr_name = $("#attr_name").val();
        var sort = $("#sort").val();
        if($("#is_use").prop("checked")){
            var is_use = 1;
        }else{
            var is_use = 0;
        }
        var spec_id = '';
        $('input[name=spec_id]:checked').each(function() {
            if (!isNaN($(this).val())) {
                spec_id = $(this).val() + "," + spec_id;
            }
        });
        spec_id = spec_id.substring(0, spec_id.length - 1);
        var attr_value_id = '';
        $('input[name=attr_value_id]:checked').each(function() {
            if (!isNaN($(this).val())) {
                attr_value_id = $(this).val() + "," + attr_value_id;
            }
        });
        attr_value_id = attr_value_id.substring(0, attr_value_id.length - 1);
        if(verify(attr_name,sort) && !flag){
            flag = true;
            $.ajax({
                type : "post",
                url : "<?php echo url('goods/add_attr_mod'); ?>",
                data : {
                    'attr_name':attr_name,
                    'sort':sort,
                    'spec_id':spec_id,
                    'attr_value_id':attr_value_id,
                    'is_use':is_use
                },
                success : function(data) {
                    if(data['code']>0){
                        layer.msg('添加成功!',{icon:1,time:1000},function () {
                            window.parent.location.reload();
                        });
                    }
                    else{
                        flag = false;
                        layer.msg(data['message'],{icon:5,time:1000});
                    }
                }
            });
        }
    }
</script>
</body>
</html>