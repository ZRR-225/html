<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/arliki/shequ_edit.html";i:1547904198;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/noue.html";i:1545994004;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
<script src="/public/js/jquery-2.1.1.js"></script>
<script type="text/javascript" src="/public/js/vue.js"></script>
<link href="./favicon.ico?v=1.2" rel="shortcut icon" type="image/x-icon"/>
<link rel="stylesheet" href="/public/css/linecons.css">
<link rel="stylesheet" href="/public/static/bast/bootstrap.css">
<link rel="stylesheet" href="/public/static/bast/xenon-core.css?v=1.0">
<link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css"/>
<link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
<link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
<link rel="stylesheet" type="text/css" href="/public/css/dashboard.css">
<link rel="stylesheet" type="text/css" href="/public/css/yb_index.css?v=1.0"/>
<link rel="stylesheet" href="/public/css/new_index.css">
<link rel="stylesheet" type="text/css" href="/public/css/defau.css">
<script src="/public/static/layer/2.4/layer.js"></script>
</head>
<div id="newks2"></div>
<script src="/public/menu/js/jquery.artdialog.js"></script>
<script src="/public/menu/js/iframetools.js"></script>
<script src="/public/js/public_js.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>
<script>
    var UM_SITE_ROOT = '__CONF_SITE__';
</script>
<script src="/public/js/all.js"></script>

<style>
    .row {height: 32px !important; line-height: 32px !important;}
    .thumbnail {margin-right: 20px !important;display: inline-block !important;}
    .upload-thumb img{max-width: 150px;}
    .cl,.clearfix {
        zoom: 1;
        clear: both;
    }
    .formControls {display: block !important;}
</style>
<article class="cl pd-20">
    <form action="" method="post" class="form form-horizontal" id="my_bargain">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>社区名称：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" v-model="community" value="" placeholder="供货商名称" class="input-text" id="community">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>社区logo：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <img width="120" v-if="pic!=''" :src="pic" class="thumbnail">
                <input onclick="select_img('1','zhu');" class="btn btn-default" type="button" value="选择图片">
            </div>
        </div>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <input type="hidden" value="<?php echo $info['id']; ?>" id="id">
                <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button" value="提交">
            </div>
        </div>
    </form>
</article>
<script src="/public/menu/js/jquery.artdialog.js"></script>
<script src="/public/menu/js/iframetools.js"></script>
<script type="text/javascript">
    var bannerVM = new Vue({
        el: '#my_bargain',
        data: {
            community:"<?php echo (isset($info['community']) && ($info['community'] !== '')?$info['community']:''); ?>",
            pic:"<?php echo (isset($info['community_img']) && ($info['community_img'] !== '')?$info['community_img']:''); ?>"
        }
    });
    function zhu_images(id, path) {
        bannerVM.pic = path;
    }
    var flag = false;//防止重复提交
    //添加用户
    function addSuppAjax() {
        if (!flag) {
            flag = true;
            $.ajax({
                type: "post",
                url: "<?php echo url('arliki/shequ_edit'); ?>",
                data: {
                    'community' : bannerVM.community,
                    'community_img' : bannerVM.pic,
                    'id':$("#id").val()
                },
                success: function (data) {
                    if (data['code'] > 0) {
                        layer.msg('操作成功!', {icon: 1, time: 1000}, function () {
                            window.parent.location.reload();
                        });
                    }
                    else {
                        flag = false;
                        layer.msg(data['message'], {icon: 5, time: 1000});
                    }
                }
            });
        }
    }
    function select_img(number, type) {
        art.dialog.open(('__CONF_SITE__admin/images/dialogalbumlist&number=' + number + '&type=' + type), {
            lock: true,
            title: "我的图片",
            width: 900,
            height: 520,
            drag: false,
            background: "#000000",
            scrollbar: false,
        }, true);
    }
</script>
</html>