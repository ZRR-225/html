<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:84:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/express/express_rules_add.html";i:1547797402;s:63:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/base.html";i:1548050425;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php if($site_name != '' || !empty($site_name)): ?><?php echo $site_name; else: ?>请在版权设置里配置您的站点名称<?php endif; ?></title>
    <script src="/public/js/jquery-2.1.1.js"></script>
    <script type="text/javascript" src="/public/js/vue.js"></script>
    <link href="./favicon.ico?v=<?php echo time(); ?>" rel="shortcut icon" type="image/x-icon"/>
    <link rel="stylesheet" href="/public/css/linecons.css">
    <link rel="stylesheet" href="/public/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/bast/bootstrap.css">
    <link rel="stylesheet" href="/public/static/bast/xenon-core.css">
    <link rel="stylesheet" href="/public/static/bast/font-awesome.min.css">
    <link rel="stylesheet" href="/public/static/h-ui/css/H-ui.min.css?v=1.1"/>
    <link rel="stylesheet" href="/public/static/h-ui/css/style.css"/>
    <link rel="stylesheet" href="/public/static/Hui-iconfont/1.0.8/iconfont.css"/>
    <script src="/public/js/all.js"></script>
    <script>
        var UM_SITE_ROOT = '__CONF_SITE__';
    </script>
    
<style>
    .panel .panel-body {padding: 1rem 0;}  .form-group {margin-top: 10px;}  .form-group {margin-bottom: 1rem;width: 100%;}  .form-group-label {width: 180px;-webkit-flex: 0 0 180px;-ms-flex: 0 0 180px;flex: 0 0 180px;}  .text-right {text-align: right !important;}  label.required {position: relative;}  .col-form-label {padding-top: calc(.35rem - 1px);padding-bottom: calc(.35rem - 1px);}  label.required:before {content: "*";display: inline;position: absolute;left: -.75rem;color: #ff4544;font-weight: bolder;top: 25%;right: -10px;}  .form-control {display: block;width: 100%;padding: .5rem .75rem;font-size: 1rem;line-height: 1.25;color: #464a4c;background-color: #fff;background-image: none;-webkit-background-clip: padding-box;background-clip: padding-box;border: 1px solid rgba(0, 0, 0, .15);border-radius: .25rem;-webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;-o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;}  .col-sm-6 {-webkit-box-flex: 0;-webkit-flex: 0 0 50%;-ms-flex: 0 0 50%;flex: 0 0 50%;max-width: 50%;}  .col-form-label {padding-top: calc(.35rem - 1px);padding-bottom: calc(.35rem - 1px);}  .col-form-label {padding-top: calc(.5rem - 1px * 2);padding-bottom: calc(.5rem - 1px * 2);margin-bottom: 0;}  .mb-3 {margin-bottom: 1rem !important;}  .card {position: relative;display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-webkit-flex-direction: column;-ms-flex-direction: column;flex-direction: column;background-color: #fff;;border-radius: .25rem;}  .btn, .form-control, .modal-content, .card-block {border-radius: .15rem;}  .card-block {-webkit-box-flex: 1;-webkit-flex: 1 1 auto;-ms-flex: 1 1 auto;flex: 1 1 auto;padding: 1.25rem; border: 1px solid rgba(0, 0, 0, .125);margin-top: 10px;}  .float-right {float: right !important;}
</style>
<style>
    .pop_bg {position: absolute;top:0;left:0;width:100%;height:100%;z-index: 999;background-color: rgba(0,0,0,0.5);}
    .pop_box {width:600px;margin:0 auto;z-index: 99999;position: absolute;left: calc(50% - 300px);background: #fff;padding:20px;position: fixed;top: 200px;}
    .pop_scroll {max-height: 300px;overflow-y: scroll;}
    .log_box {padding-bottom: 15px;}
    .log_box ul li {width:50%;float:left; height:50px;line-height: 50px;}
    .areas_box ul li {width:50%;float:left; height:50px;line-height: 50px;}
    .areas_tit {background: #f2f2f2; height:50px; line-height: 50px;padding-left:15px;}
    .areas_box ul li div {margin-left:15px;}
    .clear { clear: both;}
    .ares_input {margin-left: 8px !important; height: 36px !important; line-height: 36px !important;border: 1px solid rgba(0, 0, 0, .15) !important;    padding: 5px;}
    .areas_btn01 {width: 115px;height: 35px;
        line-height: 35px;
        color: rgb(255, 255, 255);
        background-color: rgb(13, 163, 249);
        float: left;
        text-align: center;
        font-size: 15px;
        cursor: pointer;
        border-radius: 5px;
        margin-left: 130px;
        border: 1px solid rgb(13, 163, 249);}
    .areas_btn02 {
        width: 115px;height: 35px;
        line-height: 35px;
        float: left;
        color: rgb(136, 136, 136);
        background-color: rgb(255, 255, 255);
        border: 1px solid rgb(136, 136, 136);
        margin-left: 50px;
        cursor: pointer;
        border-radius: 5px;text-align: center;
        font-size: 15px;
    }
    .areas_btn_box {
        background: #fff;
        height: 60px;
        width: 560px;
        border-top: 1px solid #eeeeee;
        padding-top: 20px;}
</style>

    <style>.new_logo .logo-expanded {color:#fff;font-size:14px;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:100px; display: block;margin-left: 10px;background: #000;border-radius: 4px; height: 30px; line-height: 30px; text-align: center;padding:0 5px;margin-top:15px;margin-bottom: 5px;} .input-text {margin-bottom:0 !important;} .top_menu { height:50px; line-height: 50px; background: #fff;width:calc(100% - 200px);position: fixed;z-index: 1;top:0;left:200px;border-bottom:1px solid #eeeeee;} .top_menu a {display:block;float:right;height:50px; line-height: 50px;width:100px; text-align: center;border-left:1px solid #eeeeee;} .clear {clear:both;} .btn {margin-bottom:0;} body {line-height: 1.6 !important; overflow-x: hidden;} .left_cur a i:before ,.left_cur ul li .cur_s .title ,.left_cur .cur_tit ,li.left_cur > a:before {color:#444 !important;} .left_cur {    } .logo-env .new_logo {padding-left:36px;} .logo-env .new_logo .wq_logo {margin-left:-36px;width:28px;height: 28px;float: left;border-radius: 50%;} .logo-env .new_logo:after {clear:both;} .tool_box a span ,.tool_box a:hover span {color:#666 !important;} .left_btn_box {padding:3px 10px 0 10px;justify-content:center;display: flex;} .left_btn_box a {display:block;height: 28px; line-height: 26px;width:80px;color: #fff; text-align: center;    border-radius: 2px;} .left_btn_box a.btn_li01 {background:rgb(25, 200, 91);border-bottom-right-radius: 0; border-top-right-radius: 0;} .left_btn_box a.btn_li02 {background:rgb(0, 193, 222);border-bottom-left-radius: 0; border-top-left-radius: 0;} .left_btn_box a.btn_li01:hover {background:rgb(21, 186, 93);} .left_btn_box a.btn_li02:hover {background:rgb(2, 182, 209);} .wq_bottom_btn {position:fixed;bottom:0;left:230px;width:100%;background: #fff;justify-content:center;display: flex; height: 80px; line-height: 80px;} .sidebar-menu {min-width: 122px !important;width: 122px !important; overflow: hidden;background: #fff !important;} .main-menu-scroll{height: calc(100% - 130px);overflow-x: hidden;width: 200px;overflow-y: scroll;} .main-menu-scroll::-webkit-scrollbar {display: none;} .new_left_menu {width:180px; height: 100%;display: table-cell;position: relative;background: #fafafa;z-index: 1;border-right: 1px solid #e7e7f0} .sidebar-menu.fixed .sidebar-menu-inner {left:86px !important;border-right: 1px solid #eeeeee;} .f_name_box {display: block; height: 50px; line-height: 50px;color: #504f5c;} .f_name_box.cur_name {width: 180px} .new_left_menu a {text-decoration:none;height: 30px;line-height: 26px;margin-top: 10px;} .new_left_menu a span {font-size:12px;margin-left: 16px;} .new_left_menu a i {margin-left:18px;display:inline-block;color:#b3b3b3;} .new_left_menu a.cur_name i ,.new_left_menu a.cur_name .big_class_name {color: #503eff;} .main-menu-scroll {width:122px !important;} /*		.sidebar-menu .main-menu a {color: #444 !important;background: rgba(55, 87, 109, 0.05);}*/ .sidebar-menu .main-menu a {color: #444 !important;padding-left:20px !important;} .sidebar-menu .main-menu .cur_s a ,.sidebar-menu .main-menu .cur_s a:visited ,.sidebar-menu .main-menu .left_cur ul li.cur_s a>span{ background: rgba(255, 255, 255, 1) !important;color: #00a0e9 !important;border-right: 1px solid #eeeeee;} .title.cur_tit {color:#444 !important;font-weight: bold;} /*		.left_cur {background:#fff !important;}*/ .cur_s .sidebar-menu .main-menu a {background:#fff !important;} .sidebar-menu .main-menu ul li a {padding-left:20px !important;} /*		.left_cur ul li a {background:#fff !important;}*/ .left_cur ul li {background:#fff !important;} .sidebar-menu .main-menu {margin-top:0 !important;} .top_big_class_name { height: 50px;line-height: 50px; text-align: center;overflow: hidden;border-bottom: 1px solid;white-space: nowrap;text-overflow: ellipsis;border-bottom: 1px solid #eeeeee;font-size:13px;} .new_logo {    display: block !important;} .sidebar-menu .main-menu .left_cur ul li a>span {color:#777777 !important;} .sidebar-menu .main-menu li.has-sub>a:before {content: '\f0d7' !important;} .main-menu-scroll {height:100% !important;} .page-container {position:absolute;padding-top: 40px;box-sizing: border-box;} .new_page_top {height:44px;width:100%;position: fixed;background:#1d1a3b;border-bottom: 1px solid #2f3d5a;z-index: 999999;} .sidebar-menu.fixed .sidebar-menu-inner {top:44px !important;} .new_logo {width:30px;height:30px;float: left;margin-top:7px;margin-left:18px;border-radius: 50%;border:2px solid rgba(255,255,255,0.5);overflow:hidden;} .new_logo img {width:26px;height:26px;} .app_name {color: #fff;font-size: 18px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;width: 155px;display: block; height:40px; line-height: 40px;margin-top:2px;margin-left:8px;float:left;} .new_page_top a  ,.new_page_top a:visited {color:#fff;text-decoration: none;} .new_page_top a:hover {color: #b3b3b3;text-decoration: none;} .sidebar-menu.fixed .sidebar-menu-inner {position:fixed !important;} .new_top_right {float:right;width:180px;height:44px; line-height: 44px;} .logout_box {width:153px; height: 44px;background:url(../../yb_tuangou/core/public/images/logout_icon.png) right center no-repeat;float:left;font-size:13px;margin-left:12px;} .left_menu_box {position:fixed;width:180px;top:44px;left:0;} .back_sys {width:100px; text-align: center;color:#fff;float:left;}.f_name_box:hover{color: #504f5c;background: #f3f3f3;text-decoration: none;}.ul_style .left_cur a{color: #503eff;}.ul_style li:hover{background: #f3f3f3;}.ul_style a{color: #7f7d8e;}.ul_style li:hover a span{color: #504f5c; }.ul_style .left_cur:hover a span{color: #503eff;}.ul_style li a{margin-left: 34px;}.jt{position: fixed;right: 91%;margin-top: -14px}.ul_style li a:hover{text-decoration: none;}.f_name_box.cur_name{text-decoration: none;}

    </style>
</head>
<body class="page-body">
<div class="new_page_top">
    <div class="new_logo">
        <?php if($about['logo'] != ''): ?>
        <img src="<?php echo $about['logo']; ?>" class="wq_logo">
        <?php else: ?>
        <img src="/public/static/bast/img/wq_shop_logo.png" class="wq_logo">
        <?php endif; ?>
    </div>
    <a href="javascript:void(0);" class="app_name"><?php echo $xcx_name; ?></a>
    <div class="new_top_right">
        <div class="logout_box">
            <?php if($copyright['back_type'] == 1): ?>
                <a href="<?php echo url('login/wxapp'); ?>" class="back_sys">
                    <?php else: if(!empty($last_visit_url)): ?>
                        <a href="<?php echo $last_visit_url; ?>" class="back_sys">
                    <?php else: ?>
                        <a href="<?php echo $siteroot; ?>web/index.php?c=wxapp&a=version&do=home&version_id=<?php echo $version_id; ?>" class="back_sys">
                    <?php endif; endif; ?>
                返回系统
            </a>
            <a href="<?php echo url('login/logout'); ?>" class="right_logout">退出</a>
        </div>
        <div class="clear"></div>
    </div>
    <?php if($endtime['is_show'] ==1): ?>
    <div style="height:44px; line-height:44px;float:right;color:#b3b3b3;font-size:13px;margin-right:15px;">该账号使用有效期至 <?php echo $endtime['time']; ?>，将在<?php echo $endtime['days']; ?>天后过期，请及时付费 ！  </div>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<div class="page-container" style="border-collapse:inherit;">
    <div class="new_left_menu" >
        <div class="left_menu_box" id="top_menu">
            <ul v-for="(item, index) in list" >
                <a v-on:click="top_click(item)" href="javascript:void(0);" :class="item.class"><i>
                    <img v-if="top_mid==item.module_id" :src="'public/images/aside_icon/'+item.logo+'_p.png'" alt="" >
                    <img v-else :src="'public/images/aside_icon/'+item.logo+'_n.png'" >
                </i><span class="big_class_name" v-text="item.module_name"></span>
                    <div v-if="item.sub.length>0">
                    <img src="public/images/aside_icon/ic_menu_top.png" v-if="top_mid==item.module_id && show" alt="" class="jt">
                    <img src="public/images/aside_icon/ic_menu_bot.png" v-else alt="" class="jt">
                    </div>
                </a>
                <ul :id="'second_'+item.module_id" name="second_menu" class="ul_style">
                    <li  v-if="item.sub.length>0" v-for="(v, k) in item.sub" v-on:click="sub_click(v)" v-bind:class="{'left_cur' : v.module_id == sub_mid, 'expanded' : expanded && v.module_id == sub_mid && item.sub.length > 0 }">
                        <a href="javascript:void(0);">
                            <span class="title" v-text="v.module_name"></span>
                        </a>
                    </li>
                </ul>
            </ul>
        </div>
    </div>
    <div class="main-content">
        
<div class="Hui-article">
    <article class="cl pd-20">
        <div id="tab_demo" class="HuiTab" style="margin-top: 0px; position: relative;">
            <div class="tabBar clearfix">
                <span onclick="window.location.href='<?php echo url('express/express_rules'); ?>'">运费规则</span>
                <span class="current" onclick="window.location.href='javascript:;'"><?php echo $fee_id==0?'添加运费规则':'运费规则编辑'; ?></span>
            </div>
        </div>
    </article>
    <div id="main" class="panel-body" style="display: none" v-show="show">
        <form class="auto-form">
            <div class="form-group row">
                <div class="form-group-label col-sm-2 text-right"><label class="col-form-label required">规则名称</label>
                </div>
                <div class="col-sm-6"><input type="text" v-model="name" class="form-control"></div>
            </div>
            <div style="display: none" class="form-group row">
                <div class="form-group-label col-sm-2 text-right"><label class="col-form-label required">快递公司</label>
                </div>
                <div class="col-sm-6"><input type="text" name="express" value="" class="form-control"> <select
                        name="express_id" hidden="hidden" class="form-control">
                    <option value="0">无</option>
                </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="form-group-label col-sm-2 text-right"><label class=" col-form-label required">计费方式</label>
                </div>
                <div class="col-sm-6"><label class="radio-label"><input checked="checked" value="1" v-model="type_fee" name="type"
                                                                        type="radio" class="custom-control-input"> <span
                        class="label-icon"></span> <span class="label-text">按件计费</span></label> <label
                        class="radio-label"><input value="2" name="type" v-model="type_fee" type="radio" class="custom-control-input">
                    <span class="label-icon"></span> <span class="label-text">按重计费</span></label></div>
            </div>
            <div class="form-group row detail">
                <div class="form-group-label col-sm-2 text-right"><label class=" col-form-label required">运费规则</label>
                </div>
                <div class="col-sm-6 col-form-label">
                    <div class="card mb-3">
                        <div class="card-block" v-for="(v,k) in fee">
                            <div class="mb-3"><span><span class="show-frist">{{type_fee==1?'首件(件)':'首重(克)'}} ：</span>{{v.frist_num}}</span> <span><span
                                    class="show-frist-price">首费(元) ：</span>{{v.frist_price}}</span> <span><span
                                    class="show-second">{{type_fee==1?'续件(件)':'续重(克)'}} ：</span>{{v.add_num}}</span>
                                <span><span>续费(元) ：</span>{{v.add_price}}</span> <a href="javascript:" class="del-rules-btn float-right" style="font-size: 15px;font-weight: bold;color: #06c" @click="del_fee_li(k)">[-删除条目]</a>
                            </div>
                            <div><span>城市：</span>
                                <span v-for="(v2,k2) in v.city_list">
                                    <span>{{v2}} &nbsp;&nbsp;</span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <a href="javascript:" class="show-rules-modal" @click="show_area=true">[+新增条目]</a></div>
            </div>
            <div class="form-group row">
                <div class="form-group-label col-sm-2 text-right"></div>
                <div class="col-sm-6"><a href="javascript:" onclick="express_add()" class="btn btn-primary auto-form-btn" style="border-radius: 4px;">保存</a></div>
            </div>
        </form>


        <div v-if="show_area" class="pop_box">

            <div class="log_box">
                <ul>
            <li>{{type_fee==1?'首件(件)':'首重(克)'}}<input type="number" v-model="add_fee.frist_num" class="ares_input"></li>
            <li>首费(元)<input type="number" v-model="add_fee.frist_price"  class="ares_input"></li>
            <li>{{type_fee==1?'续件(件)':'续重(克)'}}<input type="number" v-model="add_fee.add_num"  class="ares_input"></li>
            <li>续费(元)<input type="number" v-model="add_fee.add_price" class="ares_input"></li>
                <div class="clear"></div>
                </ul>
            </div>
            <div class="pop_scroll">
                <div v-for="(v,k) in area" class="areas_box">
                    <div v-if="v.city_num>0" class="areas_tit">
                        <input @click="chose_pro(v.id,k)" name="pro" type="checkbox" />
                        <label>
                            <span>{{v.name}}</span>
                            <span @click="area_open(k)" v-if="!v.is_open"><img src="public/images/jiantou.png " alt="" style="width: 10px;height: 8px" class="xia"></span>
                            <span @click="area_open(k)" v-if="v.is_open"><img src="public/images/jiantouer.png " alt="" style="width: 10px;height: 8px;" class="shang"></span>
                        </label>
                    </div>
                    <div v-show="v.is_open">
                        <ul>
                            <li v-for="(v2,k2) in v.city">
                                <div v-if="!v2.hidden">
                                    <input @click="chose_city(v2.id,k,k2,v2.name)" type="checkbox" name="city"  :data-value="'pro_'+v.id" :data-valname="v2.name" :data-id="v2.id" :data-index="k2" :id="'city_'+v2.id"/>
                                    <label :for="'city_'+v2.id">{{v2.name}}</label>
                                </div>
                            </li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="areas_btn_box">
                <div @click="add_fee_mo()" class="areas_btn01">确认</div>
                <div class="areas_btn02" @click="show_area=false">取消</div>
                <div class="clear"></div>
            </div>

        </div>
        <div v-if="show_area" class="pop_bg"></div>
    </div>
</div>

    </div>

    <footer class="footer" style="background: #FFFFFF;height: 25px;margin-top: -5px;padding-top: 10px;line-height: 25px;">
        <!--<p><?php echo $copyright['content']; ?></p>-->
        <?php if($show_we7): ?>
        <div class="container-fluid footer text-center" role="footer">
            <div class="friend-link" >
                <?php if(empty($_W['footerright'])): ?>
                <a href="http://www.we7.cc">微信开发</a>
                <a href="http://s.we7.cc">微信应用</a>
                <a href="http://bbs.we7.cc">微擎论坛</a>
                <a href="http://s.we7.cc">联系客服</a>
                <?php else: ?>
                <?php echo $_W['footerright']; endif; ?>
            </div>
            <div class="copyright"><?php if(empty($_W['footerleft'])): ?>Powered by <a href="http://www.we7.cc"><b>微擎</b></a> v<?php echo $version; ?> &copy; 2014-2015 <a href="http://www.we7.cc">www.we7.cc</a><?php else: ?><?php echo $_W['footerleft']; endif; ?></div>
            <?php if(!empty($_W['icp'])): ?><div>备案号：<a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $_W['icp']; ?></a></div><?php endif; ?>
        </div>
        <?php if(!empty($_W['statcode'])): ?><?php echo $_W['statcode']; endif; if(!empty($_GPC) && !in_array($_GPC, array('keyword', 'special', 'welcome', 'default', 'userapi')) || defined('IN_MODULE')): ?>
        <script>
            if(typeof $.fn.tooltip != 'function' || typeof $.fn.tab != 'function' || typeof $.fn.modal != 'function' || typeof $.fn.dropdown != 'function') {  require(['bootstrap']);}
        </script>
        <?php endif; endif; ?>
    </footer>
</div>
<script src="/public/static/bast/xenon-custom.js"></script>
<script src="/public/static/bast/clipboard.js"></script>
<script src="/public/static/bast/TweenMax.min.js"></script>
<script src="/public/static/bast/resizeable.js"></script>
<script src="/public/static/layer/2.4/layer.js"></script>
<script src="/public/js/public_js.js"></script>
<script src="/public/js/all.js"></script>
<script type="text/javascript" src="/public/static/My97DatePicker/4.8/WdatePicker.js"></script>

<script type="text/javascript">
    var flag = false;//防止重复提交
    function verify( fee,name) {
        if(name == ''){
            layer.msg('请输入名称',{icon:5,time:1000});
            return false;
        }
        if(fee.length<1){
            layer.msg('请添加规则',{icon:5,time:1000});
            return false;
        }
        return true;
    }
    function express_add(){
        if (verify(vm.fee,vm.name) && !flag) {
            flag = true;
            $.ajax({
                type : "post",
                url : "<?php echo url('express/express_rules_save'); ?>",
                data : {
                    'id':vm.fee_id,
                    'values' : JSON.stringify(vm.fee),
                    'name' : vm.name,
                    'type_fee' : vm.type_fee,
                    'area':JSON.stringify(vm.area)
                },
                success : function(data) {
                    if (data["code"] > 0) {
                        layer.msg('操作成功',{icon:1,time:1000},function () {
                            window.location.href="<?php echo url('Express/express_rules'); ?>";
                        });
                    }else{
                        layer.msg('操作失败', {icon: 2, time: 1000});
                    }
                }
            });
        }
    }
        var vm = new Vue({
            el: '#main',
            data: {
                type_fee: 0,//件
                fee_id:0,
                area: [],
                name:'',
                area_new: [],
                show_area: false,//选择地区
                fee: [],
                add_fee: {
                    frist_price: 10,
                    frist_num: 1,
                    add_price: 0,
                    add_num: 0,
                    city: {},
                    city_list: []
                },
                show: false
            },
            created: function () {
                var that = this;
                var fee_id='<?php echo $fee_id?>';
                var area = [];
                that.fee_id=fee_id;
                if(fee_id==0){
                    area = JSON.parse('<?php echo $area?>');
                    that.area_new = JSON.parse('<?php echo $area?>');
                    that.type_fee=1;
                }else{
                    area = JSON.parse('<?php echo $area_e?>');
                    that.area_new = JSON.parse('<?php echo $area_e?>');
                    that.fee=JSON.parse('<?php echo $values?>');
                    that.type_fee='<?php echo $type_fee?>';
                    that.name='<?php echo $name?>';
                }
                that.area = area;
                that.show = true;
            },
            watch:{
                type_fee:function(val,oldVal){
                    var that=this;
                    var frist_num=1;
                    if(oldVal!=0){
                        if(val==2){
                            frist_num=1000;
                        }
                        that.add_fee={
                            frist_price: 10,
                            frist_num: frist_num,
                            add_price: 0,
                            add_num: 0,
                            city: {},
                            city_list: []
                        };
                        that.area = JSON.parse('<?php echo $area?>');
                        that.area_new = JSON.parse('<?php echo $area?>');
                        that.fee=[];
                    }
                }
            },
            methods: {
                //删除运费规则
                del_fee_li:function(index){
                    var that=this;
                    var arr=that.fee;
                    var city=arr[index].city;
                    var area=that.area;
                    var res=[];
                    for (var i in city) {
                        res=that.city_to_index(i);
                      //  console.log(res)
                        area[res[0]].city[res[1]]['hidden'] = false;//显示隐藏城市
                        area[res[0]].city_num= area[res[0]].city_num + 1;
                    }
                    var str = JSON.stringify(area);
                    that.area=JSON.parse(str);
                    that.area_new=JSON.parse(str);
                    var new_arr=[];
                    for(var s=0;s<arr.length;s++){
                        if(s!=index){
                            new_arr.push(arr[s]);
                        }
                    }
                    that.fee=new_arr;
                },
                area_open:function(index){
                    var that = this;
                    var a = !that.area[index]['is_open'];
                    Vue.set(that.area[index],"is_open",a);
                },
                //选择省份
                chose_pro: function (id, k) {
                    var that = this, f = 'pro_' + id, name = '', sid = '', index,
                        city = that.add_fee.city,
                        area_new = that.area_new;
                    console.log(f);
                    $("input[data-value=" + f + "]").each(function () {
                        console.log(111111);
                        if ($(this).attr("data-value") == f) {
                            sid = $(this).attr("data-id");
                            name = $(this).attr("data-valname");
                            index = $(this).attr("data-index");
                            if (!$(this)[0].checked) {
                                if(name=='市辖区' || name=='县'){
                                    name=that.area[k].name+name;
                                }
                                city[sid] = name;
                                area_new[k].city[index]['hidden'] = true;
                                area_new[k].city_num = area_new[k].city_num - 1;
                            } else {
                                area_new[k].city[index]['hidden'] = false;
                                area_new[k].city_num = area_new[k].city_num + 1;
                                delete city[sid];
                            }
                            console.log(city)
                            that.area_new = area_new;
                            that.add_fee.city = city;
                            that.add_fee.city_list = that.obj_to_arr(city);
                            console.log(that.add_fee);
                            $(this).prop("checked", !$(this)[0].checked);
                        }
                    });
                },
                //选择城市
                chose_city: function (id, k, index, name) {
                    var f = '#city_' + id;
                    var that = this,
                        city = that.add_fee.city,
                        area_new = that.area_new;
                    if ($(this)[0].checked) {
                        if(name=='市辖区' || name=='县'){
                            name=that.area[k].name+name;
                        }
                        city[id] = name;
                        area_new[k].city[index]['hidden'] = true;
                        area_new[k].city_num = area_new[k].city_num - 1;
                    } else {
                        area_new[k].city[index]['hidden'] = false;
                        area_new[k].city_num = area_new[k].city_num + 1;
                        delete city[id];
                    }
                    that.area_new = area_new;
                    that.add_fee.city = city;
                    that.add_fee.city_list = that.obj_to_arr(city);
                    $(f).prop("checked", $(f)[0].checked);

                },
                //添加运费规则
                add_fee_mo: function () {
                    var that = this,
                        fee = that.fee;
                    if(parseFloat(that.add_fee.frist_price)<=0 || parseInt(that.add_fee.frist_num)<=0 || parseFloat(that.add_fee.add_price)<0 || parseInt(that.add_fee.add_num)<0){
                        layer.msg('请重新设置运费',{icon:5,time:1000});
                        return false;
                    }
                    if(that.add_fee.city_list.length<1){
                        layer.msg('请选择城市',{icon:5,time:1000});
                        return false;
                    }
                    var str = JSON.stringify(that.area_new);
                    that.fee = fee.concat([that.add_fee]);
                    that.add_fee = {
                        frist_price: 10,
                        frist_num: 1,
                        add_price: 0,
                        add_num: 0,
                        city: {},
                        city_list: []
                    };
                    that.area = JSON.parse(str);
                    that.show_area = false;
                },
                //根据城市id获取，省，市的index
                city_to_index:function(city_id){
                    console.log(city_id)
                    var that=this;
                    var area=that.area;
                    var aa=false;
                    var arr=[];
                    for(var i=0;i<area.length;i++){
//                        console.log('--------pro---------')
//                        console.log(area[i])
                        for(var r=0;r<area[i]['city'].length;r++){
//                            console.log('--------city---------')
//                            console.log(area[i]['city'][r])
                            if(area[i]['city'][r]['id']==city_id){
                                arr[0]=i;
                                arr[1]=r;
                                aa=true;break;
                            }
                        }
                        if(aa){
                            break;
                        }
                    }
                    return arr;
                },
                obj_to_arr: function (object) {
                    var arr = []
                    for (var i in object) {
                        arr.push(object[i]);
                    }
                    return arr;
                }
            }
    });

</script>

<script>
    var str;
    str = '<?php echo json_encode($all_menu); ?>';
    var all_menu = eval(decodeURIComponent(str));
    var root_url = "<?php global $_W; echo $_W['siteroot'].'addons/yb_tuangou/core/index.php?s=/admin/'; ?>";
    var top_mid = '<?php echo $top_mid; ?>';
    var sub_mid = '<?php echo $sub_mid; ?>';
    var three_mid = '<?php echo $three_mid; ?>';
    var sub_menu_arr = [];
    $(document).ready(function () {
        $("ul[name=second_menu]").hide();
        if(top_mid>0){
            $("#second_"+top_mid).show();
        }
    });
    all_menu.forEach(function (item, index) {
        if(item.module_id == top_mid)
        {
            item.class = 'f_name_box cur_name';
            sub_menu_arr = item.sub? item.sub : [];
        }
        else
        {
            item.class = 'f_name_box';
        }
    });
    var top_menu = new Vue({
        el: '#top_menu',
        data: {
            list:all_menu,
            top_mid: top_mid,
            root_url : root_url,
            sub_mid: sub_mid,
            three_mid: three_mid,
            expanded:sub_mid > 0,
            show:true,
        },
        methods:{
            top_click:function (top_item) {
                if(this.top_mid != top_item.module_id)
                {
                    this.show=true;
                    var sub_menu=this;
                    $("ul[name=second_menu]").hide();
                    $("#second_"+top_item.module_id).show();
                    var val = top_item.module_id;
                    this.top_mid = val;
                    sub_menu.expanded = false;
                    document.cookie = "top_mid=" + val;
                    if(top_item.sub.length > 0)
                    {
                        this.list.forEach(function (item, index) {
                            if(item.module_id == val)
                            {
                                item.class = 'f_name_box cur_name';
//                                sub_menu.list = item.sub;
                                sub_menu.sub_mid = 0;
                                sub_menu.three_mid = 0;
                                if(sub_menu.list != null && sub_menu.list != undefined)
                                {
                                    if(sub_menu.list.length > 0)
                                    {
                                        sub_menu.expanded = true;
                                        sub_menu.sub_mid = sub_menu.list[0]['module_id'];
                                    }
                                }
                            }
                            else
                            {
                                item.class = 'f_name_box';
                            }
                        });
                    }
                    else
                    {
                        window.location.href = this.root_url+top_item.url;
                    }
                }else {
                    this.show=!this.show;
                    $("ul[name=second_menu]").hide();
                    if(this.show){
                        $("#second_"+top_item.module_id).show();
                    }
                }
            },
            sub_click: function (item) {
                this.expanded = this.sub_mid == item.module_id ? !this.expanded : true;
                this.sub_mid = item.module_id;
                document.cookie = "sub_mid=" + item.module_id;
                if(item.sub.length == 0)
                {
                    window.location.href = this.root_url+item.url;
                }
            },
            three_click: function (item) {
                this.three_mid = item.module_id;
                document.cookie = "three_mid=" + item.module_id;
                window.location.href = this.root_url+item.url;
            }
        },
    });
</script>
</body>
</html>