<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/arliki/printer.html";i:1552112152;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0077)http://api.niuteam.cn/index.php?s=/admin/order/printOrder&print_order_ids=900 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<title>订单打印</title>
	<style>
		*{
			padding: 0;
			margin: 0;
		}
		body{
			font:12px/1.5 "宋体", Arial, Helvetica, sans-serif;
			color:#404040;
			text-align:center
		}
		.print_area{
			width: auto;
   			margin: 20px;
   			height:1000px
		}
		.print_area table{
			border-top: 1px solid #aaa;
		    width: 100%;
		    text-align: left;
		}
		.print_area table tr th,.print_area table tr td{
			padding: 8px 10px;
   	 		padding-left: 16px;
		}
		.print_area table tr td ul li{
			list-style: none;
			height: 25px;
			line-height: 25px;
		}
		.handlerA {
			width:200px;
			height:25px;
			line-height:25px;
			overflow:hidden;
			color:#fff;
			background:#aaa;
			border:1px solid #aaa;
			text-align:center;
		}
		.handlerB {
			width:200px;
			margin:0 auto;
			height:120px;
			border:1px solid #ccc;
			background:#ccc;
		}
		.confirmPrintBtn {
			background:#0096ff;
			border:1px solid #0096ff;
			color:#fff;
			padding:6px 20px;
			font-weight:bold;
			font-size:14px;
			vertical-align:middle;
		}
		.cancelPrintBtn {
			background:#999;
			border:1px solid #999;
			color:white;
			padding:6px 20px;
			font-weight:bold;
			font-size:14px;
			vertical-align:middle;
		}
		.printSuccessBtn {
			background:#0096ff;
			border:1px solid #0096ff;
			color:#fff;
			padding:4px 15px;
			font-weight:bold;
			font-size:14px;
			vertical-align:middle;
		}
		.printFailBtn {
			background:#0096ff;
			border:1px solid #0096ff;
			color:#fff;
			padding:4px 18px;
			font-weight:bold;
			font-size:14px;
			vertical-align:middle;
		}

	</style>
	<script src="/public/js/jquery-2.1.1.js"></script>
	<script src="/public/js/jquery.qrcode.min.js"></script>
</head>
<body>
		<div class="print_area" style="page-break-after: always;">
		<table style="border-top: none;padding: 0;">
			<tbody><tr>
				<th style="width:250px;" valign="bottom">下单用户：<?php echo $order['user_name']; ?></th>
			</tr>
		</tbody></table>
		<table>
			<tbody><tr>
				<th>订单号：<?php echo $order['order_no']; ?></th>
				<th style="width:250px;">下单日期：<?php echo date('Y-m-d H:i:s',$order['create_time']); ?></th>
			</tr>
		</tbody></table>
		<table>
			<thead>
				<tr>
					<th style="width:10%;">序号</th>
					<th class="cell-10" style="width:30%;">商品</th>
					<th style="width:5%;">数量</th>
					<th style="width:10%;">订单价格(元)</th>
					<?php if($order['order_goods_no_delive']): ?>
					<th style="width:8%;">优惠券(元)</th>
					<th style="width:8%;">会员折扣(元)</th>
					<th style="width:8%;">运费(元)</th>
					<?php endif; ?>
					<th class="cell-13" style="width:10%;">实付款价格(元)</th>
					<th style="width:10%;">配送状态</th>
				</tr>
			</thead>
			<colgroup>
				<col style="width: 6%;">
				<col style="width: 22%">
				<col style="width: 18%">
				<col style="width: 10%">
				<col style="width: 8%">
				<col style="width: 8%">
				<col style="width: 8%">
				<col style="width: 8%">
				<col style="width: 8%">
			</colgroup>
			<tbody style="border-top: 1px solid #aaa">
			<?php if($order['order_goods_no_delive']): if(is_array($order['order_goods_no_delive']) || $order['order_goods_no_delive'] instanceof \think\Collection || $order['order_goods_no_delive'] instanceof \think\Paginator): $k1 = 0; $__LIST__ = $order['order_goods_no_delive'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k1 % 2 );++$k1;?>
			<tr class="test-item">
				<td><span><?php echo $k1; ?></span></td>
				<td class="cell-10" style="width:200px;">
					<span><?php echo $vo['goods_name']; ?></span>
					<p class="c-gray"><?php echo $vo['sku_name']; ?></p>
				</td>
				<td><?php echo $vo['num']; ?></td>
				<td><?php echo $vo['price']; ?></td>
				<td><p><?php echo $list['coupon_money']; ?></p></td>
				<td><p><?php echo $list['rebate_money']; ?></p></td>
				<td><p><?php echo $list['shipping_money']; ?></p></td>
				<td><p><?php echo $list['pay_money']; ?></p></td>
				<td>
					<p><?php echo getOrderStatus($order['order_status']); ?></p>
				</td>
			</tr>
			<tr><td colspan="9"></td></tr>
			<?php endforeach; endif; else: echo "" ;endif; endif; ?>
			<!-- 已发货 -->
			<?php if($order['goods_packet_list']): if(is_array($order['goods_packet_list']) || $order['goods_packet_list'] instanceof \think\Collection || $order['goods_packet_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $order['goods_packet_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
			<tr style="background-color:#f2f2f2;color:#999;font-weight:bold;">
				<td colspan="7"><a href="javascript:;" style="color:rgba(34, 34, 34, 0.71);font-size:14px;"><?php echo $v['packet_name']; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
					<?php if($v['is_express'] == 1): ?>
					<?php echo $v['express_name']; ?>&nbsp;&nbsp;运单号:<?php echo $v['express_code']; endif; ?>
				</td>
			</tr>
			<?php if(is_array($v['order_goods_list']) || $v['order_goods_list'] instanceof \think\Collection || $v['order_goods_list'] instanceof \think\Paginator): $k2 = 0; $__LIST__ = $v['order_goods_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k2 % 2 );++$k2;?>
			<tr class="test-item">
				<td><?php echo $k2; ?></td>
				<td class="cell-10" style="width:200px;">
					<span><?php echo $vo['goods_name']; ?></span>
					<p class="c-gray"><?php echo $vo['sku_name']; ?></p>
				</td>
				<td><?php echo $vo['num']; ?></td>
				<td><?php echo $vo['price']; ?></td>
				<td><p><?php echo $vo['goods_money']; ?></p></td>
				<td>
					<p>
						<?php echo $order['shipping_status_name']; ?>
					</p>
				</td>
			</tr>
			<?php endforeach; endif; else: echo "" ;endif; endforeach; endif; else: echo "" ;endif; endif; ?>
			</tbody>
		</table>
		<table>
			<tbody>
				<tr>
					<td style="width: 60px;">订单留言：</td>
					<td><?php echo $order['buyer_message']; ?></td>
					<td style="width: 250px;text-align: right;">
						<ul>
							<li>商品总金额：￥<?php echo $order['order_money']; ?>，</li>
							<?php if($order['user_platform_money']>0): ?>
							<li>余额支付：￥<?php echo $order['user_platform_money']; ?>，</li>
							<?php endif; if($order['coupon_money']>0): ?>
							<li>优惠券：￥<?php echo $order['coupon_money']; ?>，</li>
							<?php endif; if($order['tax_money']>0): ?>
							<li>发票税额：￥<?php echo $order['tax_money']; ?>，</li>
							<?php endif; if($order['discount_money']>0): ?>
							<li>满减优惠：￥<?php echo $order['discount_money']; ?>，</li>
							<?php endif; if($order['point']>0): ?>
							<li>使用积分：<?php echo $order['point']; ?>，</li>
							<?php endif; ?>
							<li> 实际需支付：<b class="real-pay c-red">￥<?php echo $order['pay_money']; ?></b></li>
							<li>（含运费 ￥<?php echo $order['shipping_money']; ?>）</li>
						</ul>
					</td>
				</tr>
			</tbody>
		</table>
		<table>
			<tbody><tr><th>配送方式：</th><td><?php echo $order['shipping_type_name']; ?>&nbsp;&nbsp;<?php echo $order['shipping_company_name']; ?></td></tr>
			<?php switch($order['shipping_type']): case "1": ?>
			<!-- 物流 -->
			<tr>
				<th>收货信息：</th>
				<td>
					<p><?php echo $order['receiver_name']; ?>，<?php echo $order['receiver_mobile']; ?>，<?php echo $order['address']; ?>&nbsp;<?php echo $order['receiver_address']; if($order['receiver_zip']!=''): ?>&nbsp;，<?php echo $order['receiver_zip']; endif; ?></p>
				</td>
			</tr>
			<?php break; case "2": ?>
			<!-- 自提 -->
			<tr>
				<th>自提地址：</th>
				<td>
					<p><?php echo $order['order_pickup']['province_name']; ?>&nbsp;<?php echo $order['order_pickup']['city_name']; ?>&nbsp;<?php echo $order['order_pickup']['dictrict_name']; ?>&nbsp;<?php echo $order['order_pickup']['address']; ?></p>
				</td>
			</tr>
			<?php break; endswitch; ?>
		</tbody></table>
		<table>
			<tbody><tr>
				<td><?php echo $qrcode; ?></td>
				<td></td>
			</tr>
		</tbody></table>
	</div>
		<div class="extraElement">
	    <div id="popA" style="width: 202px; opacity: 0.8; position: absolute; top: 660.5px; left: 389px; cursor: move;">
	        <div class="handlerB">
	            <table>
	                <tbody>
	                    <tr style="height: 30px;line-height:30px;">
	                        <td colspan="4" style="text-align:center;background:#999;color:#fff;">操作</td></tr>
	                    <tr style="height: 40px;"></tr>
	                    <tr>
	                        <td style="width: 50px;"></td>
	                        <td>
	                            <input class="confirmPrintBtn" value="打印" onclick="javascript: printIt();" id="print" style="cursor: pointer;" type="button"></td>
	                        <td>
	                            <input class="cancelPrintBtn" onclick="javascript: printCancel();" value="取消" style="cursor: pointer;" type="button"></td>
	                        <td style="width: 50px;"></td>
	                    </tr>
	                </tbody>
	            </table>
	        </div>
	    </div>
	    <div id="popB" style="width: 202px;opacity: 0.9;display: none;position: fixed;top: 200px;left: 42%;">
	        <div class="handlerA" style="width:202px;text-align:center;background: #999;height: 28px;line-height: 28px;">
	            <span style="color: red;font-size: 14px;">反馈您的打印结果【非常重要】</span></div>
	        <div class="handlerB">
	            <table>
	                <tbody>
	                    <tr style="height: 50px;">
	                        <td></td>
	                        <td></td>
	                        <td></td>
	                        <td></td>
	                    </tr>
	                    <tr>
	                        <!-- <td style="width: 60px;"></td> -->
	                        <td>
	                            <input class="printSuccessBtn" value="打印成功" onclick="javascript: printSuccess();" style="cursor: pointer;" type="button"></td>
	                        <td>
	                            <input class="printFailBtn" value="打印失败" onclick="javascript: printFail();" style="cursor: pointer;" type="button"></td>
	                        <!-- <td style="width: 60px;"></td> -->
	                    </tr>
	                </tbody>
	            </table>
	        </div>
	    </div>
	</div>

<script>
$(function(){
	showDiv($("#popA"));
	$("#popA").easydrag();
	showDiv($("#popB"));
	$("#popB").easydrag();
	function showDiv(obj) {
		center(obj);
		$(window).scroll(function () {
			center(obj);
		});
		$(window).resize(function () {
			center(obj);
		});
	}

	function center(obj) {
		var windowWidth = document.documentElement.clientWidth;
		var windowHeight = document.documentElement.clientHeight;
		var popupHeight = $(obj).height();
		var popupWidth = $(obj).width();
		$(obj).css({
			"position": "absolute",
			"top": (windowHeight - popupHeight) / 2 + $(document).scrollTop() - 150,
			"left": (windowWidth - popupWidth) / 2
		});
	}
})
// 打印失败
function printFail() {
	$("#popA").css("display", "block");
	$("#popB").css("display", "none");
};

// 打印
function printIt() {
	$("#popA").css("display", "none");
	window.print();
	setTimeout(function () {
		$("#popB").css("display", "block");
	}, 1000);
}

// 取消打印
function printCancel() {
	window.close();
}

// 打印成功后【当用户确定打印成功后才会修改订单的打印状态】
function printSuccess() {
	window.close();
}

</script>
</body></html>