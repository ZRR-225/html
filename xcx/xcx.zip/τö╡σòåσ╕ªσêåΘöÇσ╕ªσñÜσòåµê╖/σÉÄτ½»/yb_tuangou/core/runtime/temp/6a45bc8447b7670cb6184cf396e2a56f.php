<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"/www/wwwroot/weiqing/addons/yb_tuangou/core//template/goods/goods_attr_mod_edit.html";i:1548052637;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="/public/static/h-ui/css/H-ui.min.css" />
    <script src="/public/js/jquery-2.1.1.js"></script>
    <style>
        .formControls {
            position: relative;
            display: inline-flex;
        }
    </style>
</head>
<body>
<article class="cl pd-20">
    <form action="" method="post" class="form form-horizontal" id="">
        <input type="hidden" value="<?php echo $attr_mod_info['attr_id']; ?>" id="attr_mod_id">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>分类名称：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" value="<?php echo $attr_mod_info['attr_name']; ?>" placeholder="分类名称" class="input-text" id="attr_name">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>排序：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <input type="text" autocomplete="off" value="<?php echo $attr_mod_info['sort']; ?>" placeholder="排序" class="input-text" id="sort">
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3">是否启用：</label>
            <div class="formControls col-xs-8 col-sm-9 skin-minimal">
                <div class="check-box">
                    <input type="checkbox" <?php if($attr_mod_info['is_use']==1): ?> checked <?php endif; ?> id="is_use">
                    <label for="is_use">&nbsp;</label>
                </div>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3">关联规格：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <?php if(is_array($spec_list) || $spec_list instanceof \think\Collection || $spec_list instanceof \think\Paginator): $i = 0; $__LIST__ = $spec_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$s): $mod = ($i % 2 );++$i;?>
                <dl class="permission-list">
                    <dt>
                        <?php $num=0; if(is_array($attr_mod_info['spec_id_array']) || $attr_mod_info['spec_id_array'] instanceof \think\Collection || $attr_mod_info['spec_id_array'] instanceof \think\Paginator): if( count($attr_mod_info['spec_id_array'])==0 ) : echo "" ;else: foreach($attr_mod_info['spec_id_array'] as $key=>$mod): if($mod==$s['spec_id']): ?>
                            <label>
                                <input type="checkbox" <?php if($mod==$s['spec_id']): ?> checked <?php endif; ?> value="<?php echo $s['spec_id']; ?>"  name="spec_id">
                              <?php echo $s['spec_name']; ?>
                            </label>
                        <?php $num++; endif; endforeach; endif; else: echo "" ;endif; if($num==0): ?>
                        <label>
                            <input type="checkbox" value="<?php echo $s['spec_id']; ?>"  name="spec_id">
                            <?php echo $s['spec_name']; ?>
                        </label>
                        <?php endif; ?>
                    </dt>
                    <?php if(is_array($s['spec_value_list']) || $s['spec_value_list'] instanceof \think\Collection || $s['spec_value_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $s['spec_value_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                    <dd>
                        <dl class="cl permission-list2">
                            <dt>
                                <label class="">
                                    <?php echo $v['spec_value_name']; ?>
                                   </label>
                            </dt>
                        </dl>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-3">关联属性：</label>
            <div class="formControls col-xs-8 col-sm-9">
                <?php if(is_array($attr_value) || $attr_value instanceof \think\Collection || $attr_value instanceof \think\Paginator): $i = 0; $__LIST__ = $attr_value;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$atv): $mod = ($i % 2 );++$i;?>
                <dl class="permission-list">
                    <dt>
                        <?php $num2=0; if(is_array($attr_mod_info['attr_values']) || $attr_mod_info['attr_values'] instanceof \think\Collection || $attr_mod_info['attr_values'] instanceof \think\Paginator): if( count($attr_mod_info['attr_values'])==0 ) : echo "" ;else: foreach($attr_mod_info['attr_values'] as $key=>$val): if($val['attr_value_id']==$atv['attr_value_id']): ?>
                        <label>
                            <input type="checkbox" <?php if($val['attr_value_id']=$atv['attr_value_id']): ?> checked <?php endif; ?> value="<?php echo $atv['attr_value_id']; ?>" name="attr_value_id">
                            <?php echo $atv['attr_value_name']; ?>
                        </label>
                        <?php $num2++; endif; endforeach; endif; else: echo "" ;endif; if($num2==0): ?>
                        <label>
                            <input type="checkbox" value="<?php echo $atv['attr_value_id']; ?>"  name="attr_value_id">
                            <?php echo $atv['attr_value_name']; ?>
                        </label>
                        <?php endif; ?>
                    </dt>
                    <dd>
                        <dl class="cl permission-list2">
                            <dt>
                                <label class="">
                                    <?php echo $atv['value']; ?>
                                </label>
                            </dt>
                        </dl>
                    </dd>
                </dl>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <div class="row cl">
            <div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
                <input class="btn btn-primary radius" onclick="addSuppAjax()" type="button" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
    </form>
</article>
<script type="text/javascript" src="/public/static/layer/2.4/layer.js"></script>
<script type="text/javascript">
    $(function(){
        $('.skin-minimal input').iCheck({
            checkboxClass: 'icheckbox-blue',
            radioClass: 'iradio-blue',
            increaseArea: '20%'
        });
    });
    //模块输入信息验证
    function verify(attr_name,sort) {
        if (attr_name == '') {
            layer.msg('请填写分类名称', {icon: 5, time: 1000});
            return false;
        }
        if (sort == '') {
            layer.msg('请填写排序', {icon: 5, time: 1000});
            return false;
        }
        return true;
    }
    var flag = false;//防止重复提交
    //提交
    function addSuppAjax() {
        var attr_mod_id = $("#attr_mod_id").val();
        var attr_name = $("#attr_name").val();
        var sort = $("#sort").val();
        if($("#is_use").prop("checked")){
            var is_use = 1;
        }else{
            var is_use = 0;
        }
        var spec_id = '';
        $('input[name=spec_id]:checked').each(function() {
            if (!isNaN($(this).val())) {
                spec_id = $(this).val() + "," + spec_id;
            }
        });
        spec_id = spec_id.substring(0, spec_id.length - 1);
        var attr_value_id = '';
        $('input[name=attr_value_id]:checked').each(function() {
            if (!isNaN($(this).val())) {
                attr_value_id = $(this).val() + "," + attr_value_id;
            }
        });
        attr_value_id = attr_value_id.substring(0, attr_value_id.length - 1);
        if(verify(attr_name,sort) && !flag){
            flag = true;
            $.ajax({
                type : "post",
                url : "<?php echo url('goods/add_attr_mod'); ?>",
                data : {
                    'attr_mod_id':attr_mod_id,
                    'attr_name':attr_name,
                    'sort':sort,
                    'spec_id':spec_id,
                    'attr_value_id':attr_value_id,
                    'is_use':is_use
                },
                success : function(data) {
                    if(data['code']>0){
                        layer.msg('添加成功!',{icon:1,time:1000},function () {
                            window.parent.location.reload();
                        });
                    }
                    else{
                        flag = false;
                        layer.msg(data['message'],{icon:5,time:1000});
                    }
                }
            });
        }
    }
</script>
</body>
</html>