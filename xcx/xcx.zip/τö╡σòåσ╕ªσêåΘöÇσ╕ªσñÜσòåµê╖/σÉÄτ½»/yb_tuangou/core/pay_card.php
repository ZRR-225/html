<?php
error_reporting(0);
define('IN_IA','');
date_default_timezone_set("Asia/chongqing");
define('APP_PATH', __DIR__ . '/application/');
define('CONF_PATH', APP_PATH );
define('EXTEND_PATH',__DIR__.'/extend/');
require __DIR__ . '/thinkphp/base.php';
require EXTEND_PATH . 'Wxpay/WxPay.Api.php';
use think\config;
use think\Db;
use think\Log;
use think\Exception;
$filename = APP_PATH."database.php";
Config::load($filename,'database');
error_reporting(0);
//微信订单异步通知1
$notify_data = isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input");
if(!$notify_data){
    exit('未收到回调');
}
$doc = new \DOMDocument();
$doc->loadXML($notify_data);
$out_trade_no = $doc->getElementsByTagName("out_trade_no")->item(0)->nodeValue;
$data = array(
    'ispay'     => 1,
    'paytime'   => time(),
);
$data_pay = array(
    'pay_status'     => 1,
    'pay_time'   => time(),
);
$data_jf=array(
    'time'=>time(),
    'itype'=>1,
    'ctype'=>1,
    'explain'=>'会员充值'
);
$info=Db::name('ybtg_user_card_orders')->where(['out_trade_no' => $out_trade_no,'ispay'=>0])->find();
$user_id=Db::name('ybtg_user_card')->where(['id'=>$info['card_id']])->value('user_id');
if($info){
// 启动事务
    Db::startTrans();
    try {
        Db::name('ybtg_user_card_payment')->where(['out_trade_no' => $out_trade_no,'pay_status'=>0])->update($data_pay);
        $res = Db::name('ybtg_user_card_orders')->where(['out_trade_no' => $out_trade_no,'ispay'=>0])->update($data);
        //加余额
        $money=floatval($info['payprice'])+floatval($info['giveprice']);
        Db::name('ybtg_user_card')->where(['id'=>$info['card_id'],'is_del'=>1])->setInc('money',$money);
        //加积分
        $level=Db::name('ybtg_user_card_setting')->where(['mch_id'=>$info['mch_id']])->value('level');
        if($info['integral'] && intval($info['integral'])>0){
            $new_data=[
                'time'=>time(),
                'itype'=>1,
                'ctype'=>1,
                'num_qd'=>5,
                'order_id'=>0,
                'user_id'=>$user_id,
                'mch_id'=>$data['mch_id'],
                'integral'=>intval($info['integral']),
                'consume'=>$level==1?intval($info['integral']):0,
                'type_lxm'=>1,
                'explain'=>'会员充值'
            ];
            $lxm1= Db::name('ybtg_integral_detail')->insert($new_data);
            $c=Db::name('ybtg_user')->where('uid',$data['uid'])->find();
            $user_data['integral']=intval($c['integral'])+intval($new_data['integral']);
            if($level==1){
                $user_data['consume']=intval($c['consume'])+intval($new_data['consume']);
            }
            $lxm2=Db::name('ybtg_user')->where('uid',$user_id)->update($user_data);
            if($level==1){//会员等级变更
                $d=Db::name('ybtg_user_level')->where('mch_id',$data['mch_id'])->order('hierarchy','desc')->select();
                if($d){
                    for($i=0;$i<count($d);$i++){
                        if($user_data['consume']>=$d[$i]['hierarchy']){
                            $level_id=$d[$i]['id'];
                            Db::name('ybtg_user')->where('uid',$data['uid'])->update(['level_id'=>$level_id]);
                            break;
                        }
                    }
                }
            }
        }
        // 提交事务
        Db::commit();
    } catch (\Exception $e){
        Db::rollback();
        Log::write($out_trade_no.',支付状态更改失败'.$e,'card_pay_state_change_fail');
    }
}
