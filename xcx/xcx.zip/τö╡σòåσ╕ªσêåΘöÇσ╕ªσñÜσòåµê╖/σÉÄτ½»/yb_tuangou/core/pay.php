<?php
error_reporting(0);
define('IN_IA','');
define('IA_ROOT','');
date_default_timezone_set("Asia/chongqing");
define('APP_PATH', __DIR__ . '/application/');
define('CONF_PATH', APP_PATH );
define('EXTEND_PATH',__DIR__.'/extend/');
require __DIR__ . '/thinkphp/base.php';
require EXTEND_PATH . 'Wxpay/WxPay.Api.php';
require __DIR__ . '/application/admin/service/AliyunService.php';
require  __DIR__ . '/application/admin/service/PrinterService.php';
require __DIR__ . '/application/api/service/ArlikiService.php';
use app\api\service\ArlikiService;
use app\admin\service\PrinterService;
use app\admin\service\AliyunService;
use think\config;
use think\Db;
use think\Log;
$filename = APP_PATH."database.php";
Config::load($filename,'database');
$push_config = array(
    'appid'      => 'LTAIA6equwSykSCK', // KeyID
    'secret'     => '2OTqoYSU2XVZe28cfiJpjk1FD3BEqY', // AppSecret  2OTqoYSU2XVZe28cfiJpjk1FD3BEqY
    'appkey'        => '24965934',  //Appkey  24849080
);
error_reporting(0);
//微信订单异步通知
$notify_data = isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input");
if(empty($notify_data)){
    exit('未收到回调');
}
$doc = new \DOMDocument();
$doc->loadXML($notify_data);
$out_trade_no = $doc->getElementsByTagName("out_trade_no")->item(0)->nodeValue;
$data = array(
    'order_status'   => 1,
    'pay_status'     => 1,
    'pay_type'       => 1,
    'pay_time'   => time(),
);
$data_pay = array(
    'pay_status'     => 1,
    'pay_time'   => time(),
);
$data_jf=array(
    'time'=>time(),
    'itype'=>1,
    'ctype'=>1,
    'explain'=>'消费'
);
$a=Db::name('ybtg_order')->where(['out_trade_no' => $out_trade_no,'order_status'=>0])->find();
//加积分
if($a){
    //订单打印
    $pp = new PrinterService($a['mch_id'],$a['order_id'],'pay',0);
    $pp->print_order();
    $b=Db::name('ybtg_integral_rule')->where('mch_id',$a['mch_id'])->value('data');
    $jifen=0;
    if($b){
        $b=json_decode($b,true);
        if($b['cons_status']==1){
            $order_money=$a['order_money'];
            $jifen=floor(floatval($order_money)/floatval($b['cons_money']))*floatval($b['cons_integral']);
            $c=Db::name('ybtg_user')->where('uid',$a['buyer_id'])->find();
            $jf_all=round($jifen)+intval($c['consume']);
            $d=Db::name('ybtg_user_level')->where('mch_id',$a['mch_id'])->order('hierarchy','desc')->select();
            if($d){
                for($i=0;$i<count($d);$i++){
                    if($jf_all>=$d[$i]['hierarchy']){
                        $new_data['level_id']=$d[$i]['id'];
                        $new_data['consume']=$jf_all;
                        $new_data['integral']=round($jifen)+intval($c['integral']);
                        Db::name('ybtg_user')->where('uid',$a['buyer_id'])->update($new_data);
                        $data_jf['user_id']=$a['buyer_id'];
                        $data_jf['integral']=$jifen;
                        $data_jf['consume']=$jifen;
                        $data_jf['mch_id']=$a['mch_id'];
                        $data_jf['order_id']=$a['order_id'];
                        Db::name('ybtg_integral_detail')->insert($data_jf);
                        break;
                    }
                }
            }
        }
    }
}
// 启动事务
Db::startTrans();
try {
    //修改订单
    $res = Db::name('ybtg_order')->where(['out_trade_no' => $out_trade_no,'order_status'=>0])->update($data);
    //修改支付订单
    Db::name('ybtg_order_payment')->where(['out_trade_no' => $out_trade_no,'pay_status'=>0])->update($data_pay);
    // 提交事务
    Db::commit();
    if(!empty($res) && $res > 0)
    {
        $order = Db::name('ybtg_order')->where(['out_trade_no' => $out_trade_no])->find();
        $mid = $order['mch_id'];
        $user = Db::name('ybtg_business')->where(['id' => $mid])->find();
        $un_data['url'] = $_SERVER['HTTP_HOST'];
        $un_url = explode(":", $un_data['url'] );
        $data['url'] =  $un_url[0];
        $data['username'] = $user['name'];
        $data['uniacid'] = $user['uniacid'];
        $alias = md5($data['url'].$data['username'].$data['uniacid']);
        $aliyun = new AliyunService();
        $aliyun->push($push_config,$alias);
        $sms=new ArlikiService($a["mch_id"]);
        $r=$sms->send_sms($a["order_no"],2);
        Log::write($out_trade_no.',支付状态更改成功','shop_pay_state_change_success');
    }
} catch (\Exception $e) {
    Db::rollback();
    Log::write($out_trade_no.',支付状态更改失败'.$e,'shop_pay_state_change_fail');
}
