<?php
error_reporting(0);
define('IN_IA','');
date_default_timezone_set("Asia/chongqing");
define('APP_PATH', __DIR__ . '/application/');
define('CONF_PATH', APP_PATH );
define('EXTEND_PATH',__DIR__.'/extend/');
require __DIR__ . '/thinkphp/base.php';
require EXTEND_PATH . 'Wxpay/WxPay.Api.php';
require  __DIR__ . '/application/admin/service/PrinterService.php';
use app\admin\service\PrinterService;
use think\config;
use think\Db;
use think\Log;
$filename = APP_PATH."database.php";
Config::load($filename,'database');
error_reporting(0);
//微信订单异步通知
$notify_data = isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input");
if(!$notify_data){
    exit('未收到回调');
}
$doc = new \DOMDocument();
$doc->loadXML($notify_data);
$out_trade_no = $doc->getElementsByTagName("out_trade_no")->item(0)->nodeValue;
$data = array(
    'order_status'   => 1,
    'pay_status'     => 1,
    'pay_type'       => 1,
    'pay_time'   => time(),
);
$data_pay = array(
    'pay_status'     => 1,
    'pay_time'   => time(),
);
$a=Db::name('ybtg_bargain_order')->where(['out_trade_no' => $out_trade_no,'order_status'=>0])->find();
if($a)
{
    //订单打印
    $pp = new PrinterService($a['mch_id'],$a['order_id'],'pay',1);
    $pp->print_order();
    // 启动事务
    Db::startTrans();
    try {
        //修改订单
        $res = Db::name('ybtg_bargain_order')->where(['out_trade_no' => $out_trade_no,'order_status'=>0])->update($data);
        //修改支付订单
        Db::name('ybtg_bargain_order_payment')->where(['out_trade_no' => $out_trade_no,'pay_status'=>0])->update($data_pay);
        // 提交事务
        Db::commit();
        Log::write($out_trade_no.',支付状态更改成功','bargain_pay_state_change_success');
    } catch (\Exception $e) {
        Db::rollback();
        Log::write($out_trade_no.',支付状态更改失败'.$e,'bargain_pay_state_change_fail');
    }
}
