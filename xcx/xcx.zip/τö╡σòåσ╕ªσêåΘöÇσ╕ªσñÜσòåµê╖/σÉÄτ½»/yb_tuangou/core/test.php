<?php
define('IN_IA','');
define('IA_ROOT','');
date_default_timezone_set("Asia/chongqing");
define('APP_PATH', __DIR__ . '/application/');
define('CONF_PATH', APP_PATH );
define('EXTEND_PATH',__DIR__.'/extend/');
require __DIR__ . '/thinkphp/base.php';
require EXTEND_PATH . 'Wxpay/WxPay.Api.php';
require __DIR__ . '/application/admin/service/AliyunService.php';
require  __DIR__ . '/application/admin/service/PrinterService.php';
use app\admin\service\PrinterService;
use think\config;
use think\Db;
use think\Log;
$filename = APP_PATH."database.php";
Config::load($filename,'database');
//订单打印
$pp = new PrinterService(30,76,'order',0);
$pp->print_order();
