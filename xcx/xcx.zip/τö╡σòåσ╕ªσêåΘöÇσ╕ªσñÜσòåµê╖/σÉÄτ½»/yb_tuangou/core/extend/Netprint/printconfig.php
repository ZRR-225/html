<?php
const BASEURL = "http://www.open.mstching.com";
const APPID ="65b1763c7b00";
const APPSECRET = "4edfb961c2dce00c6949";
?>
