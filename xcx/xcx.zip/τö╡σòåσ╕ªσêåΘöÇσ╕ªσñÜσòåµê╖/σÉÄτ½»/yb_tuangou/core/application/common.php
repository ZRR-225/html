<?php
// 插件目录
//define('ADDON_PATH', ROOT_PATH . 'addons' . DS);
//分页条数
define("PAGESIZE", 10);
//APP_URL
define("APP_URL", 'https://vip.ly100.wang/api/api/Pay/PayCallback');
//餐饮APP_URL
define("CateringPay", 'https://vip.ly100.wang/api/api/CaterPay/PayCallback');
//商城（商品分类）
define("SHOP_GOODS_CATE", '/pages/goods/index/index?cate=');
//商城（商品详情）
define("SHOP_GOODS_DETAIL", '/pages/goods/detail/index?id=');
//商城（文章详情）
define("SHOP_ARTICLE_INDEX", '/pages/find/index');
//商城（文章详情）
define("SHOP_ARTICLE_DETAIL", '/pages/find_info/index?id=');
//官网（案例）
define("WEB_CASE", '/pages/case/index');
//（文章分类路径）
define("CLASS_ID", '/pages/find/index?class_id=');
//（相册分类路径）
define("IMAGES_ID", '/pages/image/index?group_id=');
//（相册分类路径）
define("IMG_URL", 'https://ad.vip.ly100.wang/');
// 当前域名
define("THIS_URL", 'https://vip.ly100.wang/');
//API域名
define("VIPAPI", 'https://vip.ly100.wang/api/');
if( ! function_exists('array_column'))
{
    //array_multisort(array_column($res,'num'),SORT_DESC,$res);
    function array_column($input, $columnKey, $indexKey = NULL)
    {
        $columnKeyIsNumber = (is_numeric($columnKey)) ? TRUE : FALSE;
        $indexKeyIsNull = (is_null($indexKey)) ? TRUE : FALSE;
        $indexKeyIsNumber = (is_numeric($indexKey)) ? TRUE : FALSE;
        $result = array();
        foreach ((array)$input AS $key => $row)
        {
            if ($columnKeyIsNumber)
            {
                $tmp = array_slice($row, $columnKey, 1);
                $tmp = (is_array($tmp) && !empty($tmp)) ? current($tmp) : NULL;
            }
            else
            {
                $tmp = isset($row[$columnKey]) ? $row[$columnKey] : NULL;
            }
            if ( ! $indexKeyIsNull)
            {
                if ($indexKeyIsNumber)
                {
                    $key = array_slice($row, $indexKey, 1);
                    $key = (is_array($key) && ! empty($key)) ? current($key) : NULL;
                    $key = is_null($key) ? 0 : $key;
                }
                else
                {
                    $key = isset($row[$indexKey]) ? $row[$indexKey] : 0;
                }
            }
            $result[$key] = $tmp;
        }
        return $result;
    }
}
function get_first($str)
{
    $str= iconv("UTF-8","gb2312", $str);//编码转换
    if (preg_match("/^[\x7f-\xff]/", $str))
    {
        $fchar=ord($str{0});
        if($fchar>=ord("A") and $fchar<=ord("z") )return strtoupper($str{0});
        $a = $str;
        $val=ord($a{0})*256+ord($a{1})-65536;
        if($val>=-20319 and $val<=-20284)return "A";
        if($val>=-20283 and $val<=-19776)return "B";
        if($val>=-19775 and $val<=-19219)return "C";
        if($val>=-19218 and $val<=-18711)return "D";
        if($val>=-18710 and $val<=-18527)return "E";
        if($val>=-18526 and $val<=-18240)return "F";
        if($val>=-18239 and $val<=-17923)return "G";
        if($val>=-17922 and $val<=-17418)return "H";
        if($val>=-17417 and $val<=-16475)return "J";
        if($val>=-16474 and $val<=-16213)return "K";
        if($val>=-16212 and $val<=-15641)return "L";
        if($val>=-15640 and $val<=-15166)return "M";
        if($val>=-15165 and $val<=-14923)return "N";
        if($val>=-14922 and $val<=-14915)return "O";
        if($val>=-14914 and $val<=-14631)return "P";
        if($val>=-14630 and $val<=-14150)return "Q";
        if($val>=-14149 and $val<=-14091)return "R";
        if($val>=-14090 and $val<=-13319)return "S";
        if($val>=-13318 and $val<=-12839)return "T";
        if($val>=-12838 and $val<=-12557)return "W";
        if($val>=-12556 and $val<=-11848)return "X";
        if($val>=-11847 and $val<=-11056)return "Y";
        if($val>=-11055 and $val<=-10247)return "Z";
    }
    else
    {
        return null;
    }
}
function page_url(){
    $queryString = $_SERVER["QUERY_STRING"];
    $arr = array();
    foreach (explode('&', $queryString) as $value) {
        $queryStringTemp = explode('=', $value);
        $arr[trim($queryStringTemp[0])] = trim($queryStringTemp[1]);
    }
    return $arr;
}
function img_zip($img,$size=1){
    try {
        $IM = new IMG_COMPRESS($img, $size);
        $IM->compressImg($img);
//        $s=file_put_contents("wxwx2.json",$img.PHP_EOL,8);
//        return true;
    }catch (Exception $e){
//        return false;
    }
}

/**
 * @param $pass string 原密码
 * @param $salt string 混淆
 * @param string $case  low/up 字母大小写
 * @return string 密文
 */
function set_passwd($pass,$salt,$case=""){
    if(!empty($case)){
        if($case=="low"){
            $pass=strtolower($pass);
        }
        if($case=="up"){
            $pass=strtoupper($pass);
        }
    }
    $pass=strtolower("Arliki".strtoascii($pass).$salt);
    $new="";
    for($i=0;$i<strlen($salt);$i++){
        $new=md5(md5($pass).$new."Arliki".substr($salt,$i));
    }
    if(!empty($case)){
        if($case=="low"){
            $new=strtolower($new);
        }
        if($case=="up"){
            $new=strtoupper($new);
        }
    }
    return $new;
}
//ascii码
function strtoascii($str){
    $str=mb_convert_encoding($str,'GB2312');
    $change_after='';
    for($i=0;$i<strlen($str);$i++){
        $temp_str=dechex(ord($str[$i]));
        $change_after.=$temp_str[1].$temp_str[0];
    }
    return strtoupper($change_after);
}
function asciitostr($sacii){
    $asc_arr= str_split(strtolower($sacii),2);
    $str='';
    for($i=0;$i<count($asc_arr);$i++){
        $str.=chr(hexdec($asc_arr[$i][1].$asc_arr[$i][0]));
    }
    return mb_convert_encoding($str,'UTF-8','GB2312');
}
/**
 * 生成数据的返回值
 */
function AjaxReturn($err_code, $data = [])
{
    // return $retval;
    $rs = [
        'code' => $err_code,
        'message' => getErrorInfo($err_code)
    ];
    if (! empty($data))
        $rs['data'] = $data;
    return $rs;
}
//计算指定日期相差天数
function count_days($a,$b){
    $a_dt=getdate($a);
    $b_dt=getdate($b);
    $a_new=mktime(12,0,0,$a_dt['mon'],$a_dt['mday'],$a_dt['year']);
    $b_new=mktime(12,0,0,$b_dt['mon'],$b_dt['mday'],$b_dt['year']);
    return round(abs(intval($a_new)-intval($b_new))/86400);
}
/**
 * 生成数据的返回值
 */
function AjaxReturnMsg($err_code, $message)
{
    $rs = [
        'code' => $err_code,
        'message' => $message
    ];
    return $rs;
}
/**
 * 删除图片文件
 */
function removeImageFile($img_path)
{
    // 检查图片文件是否存在
    if (file_exists($img_path)) {
        return unlink($img_path);
    } else {
        return false;
    }
}
/**
 * 图片路径拼装(用于完善用于外链的图片)
 * @param $img_path
 * @return string
 */
function __IMG($img_path)
{
    $path = "";
    if (! empty($img_path)) {
        if (stristr($img_path, "http://") === false && stristr($img_path, "https://") === false) {
            $path = 'https://'.WEB_HOST ."/". $img_path;
        } else {
            $path = $img_path;
        }
    }
    return $path;
}
/**
 * 时间戳转换
 * @param $time
 * @return false|string
 */
function __TIME($time)
{
    $date = "";
    if (! empty($time)) {
        $date = date("Y-m-d H:i:s",$time) ;
    }
    return $date;
}
/**
 * 获取插件类的类名
 * @param strng $name 插件名
 * @param string $ext 扩展名
 */
function get_addon_class($name, $type = '', $class = null)
{
    $name = \think\Loader::parseName($name);
    if ($type == '' && $class == null) {
        $dir = ADDON_PATH . $name . '/core';
        if (is_dir($dir)) {
            // 目录存在
            $type = 'addons_index';
        } else {
            $type = 'addon_index';
        }
    }
    $class = \think\Loader::parseName(is_null($class) ? $name : $class, 1);
    switch ($type) {
        // 单独的插件addon 入口文件
        case 'addon_index':
            $namespace = "\\addons\\" . $name . "\\" . $class;
            break;
        // 单独的插件addon 控制器
        case 'addon_controller':
            $namespace = "\\addons\\" . $name . "\\controller\\" . $class;
            break;
        // 单独的插件addon 接口
        case 'addon_api':
            $namespace = "\\addons\\" . $name . "\\api\\" . $class;
            break;
        // 有下级插件的插件addons 入口文件
        case 'addons_index':
            $namespace = "\\addons\\" . $name . "\\core\\" . $class;
            break;
        // 有下级插件的插件addons 控制器
        case 'addons_controller':
            $namespace = "\\addons\\" . $name . "\\core\\controller\\" . $class;
            break;
        // 插件类型下的下级插件plugin
        default:
            $namespace = "\\addons\\" . $name . "\\" . $type . "\\controller\\" . $class;
    }
    return $namespace;
}
/**
 * 处理插件钩子
 * @param string $hook   钩子名称
 * @param mixed $params 传入参数
 * @return void
 */
function hook($hook, $params = [])
{
    // 钩子调用
    \think\Hook::listen($hook, $params);
}
/**
 * 全局获取用户名称
 */
function get_user_name($uid){
    $res=\think\Db::name('user')->where('uid',$uid)->find();
    return $res['nick_name'];
}
/**
 * 砍价订单状态
 * @param $status
 * @return int
 */
function bargain_order_status($status){
    if ($status=='-1'){
        return "订单取消";
    }
    if ($status=='0'){
        return "待付款";
    }
    if ($status=='1'){
        return "已付款";
    }
    if ($status=='2'){
        return "已发货";
    }
    if ($status=='3'){
        return "已完成";
    }
    if ($status=='4'){
        return "退款中";
    }
    if ($status=='5'){
        return "已退款";
    }
    if ($status=='8'){
        return "待核销";
    }
}
/**
 * 根据id获取城市
 * @param $area_id
 * @return array
 */
function getCity($area_id)
{
    $rs = array();
    $res=  \app\common\model\Area::get($area_id);
    $city= \app\common\model\Area::get($res['pid']);
    $pro= \app\common\model\Area::get($city['pid']);
    $rs['province_id']= $pro['id'];
    $rs['city_id']=$city['id'];
    $rs['district_id']=$res['id'];
    $rs['province_name']= $pro['name'];
    $rs['city_name']=$city['name'];
    $rs['district_name']=$res['name'];
    return $pro['name'].$city['name'].$res['name'];
}
//商家生成key
function generate_password( $length = 10 ) {
// 密码字符集，可任意添加你需要的字符
    $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $password = '';
    for ( $i = 0; $i < $length; $i++ )
    {
// 这里提供两种字符获取方式
// 第一种是使用 substr 截取$chars中的任意一位字符；
// 第二种是取字符数组 $chars 的任意元素
// $password .= substr($chars, mt_rand(0, strlen($chars) – 1), 1);
        $password .= $chars[ mt_rand(0, strlen($chars) - 1) ];
    }
    $res=\think\Db::name('yb_business')->where('app_key',$password)->find();
    if ($res){
        generate_password();
    }else{
        return $password;
    }
}
function commet_img_array($id){
    $list=\think\Db::name('yb_res_comment')->where('id',$id)->find();
    if (!empty($list['array_pic'])){
        $img=substr($list['array_pic'], 0, -1);
        $img_arr=explode(",", $img);
    }else{
        $img_arr="-";
    }
    return $img_arr;
}
function subtext($text, $length)
{
    if(mb_strlen($text, 'utf8') > $length){
        return mb_substr($text,0,$length,'utf8').'…';
    }
    return $text;
}
function getWxCode($code){
    $msg=[
        '-1' => '系统繁忙',
        '0' => '成功',
        '61004' => '当前客户端ip未在开放平台白名单',
        '61007' => '当前公众号或者小程序已在公众平台解绑',
        '61023' => '授权已过期,请重新授权',
        '85001' => '微信号不存在或微信号设置为不可搜索',
        '85002' => '小程序绑定的体验者数量达到上限',
        '85003' => '微信号绑定的小程序体验者达到上限',
        '85004' => '微信号已经绑定',
        '85006' => '标签格式错误',
        '85007' => '页面路径错误',
        '85008' => '类目填写错误',
        '85009' => '已经有正在审核的版本',
        '85010' => 'item_list有项目为空',
        '85011' => '标题填写错误',
        '85012' => '无效的审核id',
        '85013' => '无效的自定义配置',
        '85014' => '无效的模版编号',
        '85015' => '版本输入错误',
        '85019' => '没有审核版本',
        '85020' => '审核状态未满足发布',
        '85021' => '状态不可变-5以内',
        '85022' => 'action非法',
        '85023' => '审核列表填写的项目数不在1-5以内',
        '85043' => '模版错误',
        '85044' => '代码包超过大小限制',
        '85045' => '导航设置错误,请重置导航再试,编号85045',//'ext_json有不存在的路径',
        '85046' => 'tabBar中缺少path',
        '85047' => 'pages字段为空',
        '85048' => '导航设置错误,请重置导航再试,编号85048',//'ext_json解析失败',
        '85066' => '链接错误',
        '85068' => '测试链接不是子链接',
        '85069' => '校验文件失败',
        '85070' => '链接为黑名单',
        '85071' => '已添加该链接，请勿重复添加',
        '85072' => '该链接已被占用',
        '85073' => '二维码规则已满',
        '85074' => '小程序未发布, 小程序必须先发布代码才可以发布二维码跳转规则',
        '85075' => '个人类型小程序无法设置二维码规则',
        '85076' => '链接没有ICP备案',
        '85077' => '小程序类目信息失效（类目中含有官方下架的类目，请重新选择类目）',
        '85079' => '小程序没有线上版本，不能进行灰度',
        '85080' => '小程序提交的审核未审核通过',
        '85081' => '无效的发布比例',
        '85082' => '当前的发布比例需要比之前设置的高',
        '85085' => '当前平台近7天提交审核的小程序数量过多，请耐心等待审核完毕后再次提交',
        '86000' => '不是由第三方代小程序进行调用',
        '86001' => '不存在第三方的已经提交的代码',
        '86002' => '小程序还未设置昵称、头像、简介。请先设置完后再重新提交',
        '87011' => '现网已经在灰度发布，不能进行版本回退',
        '87012' => '该版本不能回退，可能的原因：1:无上一个线上版用于回退 2:此版本为已回退版本，不能回退 3:此版本为回退功能上线之前的版本，不能回退',
        '87013' => '撤回次数达到上限（每天一次，每个月10次）',
        '89031' => '小程序绑定的体验者数量达到上限',//其实我不知道报什么错误
    ];
    if(array_key_exists($code, $msg))
    {
        return $msg[$code];
    }else{
        return $code;
    }
}
function htmltotxt($string)
{
    $string = htmlspecialchars_decode($string);
    $string = html_entity_decode(strip_tags ( $string ));
    return $string;
}
function getOrderStatus($status){
    if ($status==-1){
        return '已取消';
    }
    if ($status==0){
        return '待支付';
    }
    if ($status==1){
        return '待发货';
    }
    if ($status==2){
        return '待收货';
    }
    if ($status==3){
        return '已完成';
    }
     if ($status==4){
         return '退款中';
     }
      if ($status==5){
          return '已退款';
      }
}
//获取用户名称
function getUserName($id){
    $user_name=\Think\Db::name('ybtg_user')->where('uid',$id)->find();
    return $user_name['nick_name'];
}
//获取表单名称
function getFormrName($id){
    $user_name=\Think\Db::name('ybtg_bus_form')->where('id',$id)->find();
    return $user_name['title'];
}
function get_img_arr($str){
    if ($str==''){
        return '';
    }
    $string_arr = explode(",", $str );
    return $string_arr;
}
/**
 * 获取权限名称
 */
function getArrayName($arr){
    $string_arr = explode(",", $arr );
    $return = '';
    foreach ($string_arr as $k=>$v){
        $res=\Think\Db::name('ybtg_bus_module')->where('module_id',$v)->find();
        $return.=$res['module_name'].",";
    }
    return substr($return, 0, -1);
}
/**
 * 获取权限名称
 */
function getUserAou($uid){
    $res=\Think\Db::name('ybtg_user_permission')->alias('p')
        ->join('ybtg_user_role r','r.role_id=p.role_id')
        ->where('p.user_id',$uid)
        ->find();
    return $res['role_name'];
}
/**
* 获取版权信息
*/
function getUserCopyright($uid){
    $res=\Think\Db::name('ybtg_user_permission')->alias('p')
        ->join('ybtg_user_role r','r.role_id=p.role_id')
        ->where('p.user_id',$uid)
        ->value('is_show_copyright');
    if(!isset($res)){
        return null;
    }
    if($res && $res==1){
        return '不显示';
    }else{
        return '显示';
    }
}
/**
 * 获取图片路径
 * @param $img
 * @return mixed
 */
function get_img_src($img){
    $img_cover=\think\Db::name('ybtg_images')->where('img_id',$img)->find();
    return $img_cover['img_cover'];
}
/**
 * 拼团分类
 */
function get_pt_cname($id){
    $img_cover=\think\Db::name('ybtg_pt_category')->where('id',$id)->find();
    return $img_cover['name'];
}
/**
 * 解析json
 */
function json_ecd_all($val){
    if (empty($val)){
        return '';
    }
    $json=json_decode($val,true);
    return $json;
}
function get_group_order_status($status){
    if ($status==-1){
        return '已取消';
    }
    if ($status==1){
        return '待支付';
    }
    if ($status==2){
        return '待成团';
    }
    if ($status==3){
        return '待发货';
    }
    if ($status==4){
        return '待收货';
    }
    if ($status==5){
        return '申请退款';
    }
    if ($status==6){
        return '已完成';
    }
    if ($status==7){
        return '已退款';
    }
    if ($status==8){
        return '待核销';
    }
}
/** 获取页面 **/
function get_url_content($url,$method='http',$ispost = false){
    $ch=curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);

    curl_setopt($ch, CURLOPT_POST, $ispost);

    if ($method=='https') {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    }
    $cont=curl_exec($ch);
    curl_close($ch);
    $cont=mb_convert_encoding($cont, 'UTF-8', 'UTF-8,GBK,GB2312,BIG5');
    return $cont;
}

function curl_request($url,$post_data = array()){

    $ch=curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);

    if(!empty($post_data))
    {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    }

    if (strpos($url,"https://") !== false) {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    }

    $cont=curl_exec($ch);
    curl_close($ch);
    $cont=mb_convert_encoding($cont, 'UTF-8', 'UTF-8,GBK,GB2312,BIG5');
    return $cont;

}

if ( ! function_exists( 'exif_imagetype' ) ) {
    function exif_imagetype ( $filename ) {
        if ( ( list($width, $height, $type, $attr) = getimagesize( $filename ) ) !== false ) {
            return $type;
        }
        return false;
    }
}
//php异步
function asynRequest($host,$port,$path, $param=array()){
    if(function_exists('fsockopen'))
    {
        $query = isset($param)? http_build_query($param) : '';
        $errno = 0;
        $errstr = '';
        $timeout = 10;
        $fp = fsockopen($host, $port, $errno, $errstr, $timeout);
        $out = "POST ".$path." HTTP/1.1\r\n";
        $out .= "host:".$host."\r\n";
        $out .= "content-length:".strlen($query)."\r\n";
        $out .= "content-type:application/x-www-form-urlencoded\r\n";
        $out .= "connection:close\r\n\r\n";
        $out .= $query;
        fputs($fp, $out);
        fclose($fp);
    }
}
function urlQueryToArr(){
    $queryString = $_SERVER["QUERY_STRING"];
    $arr = array();
    foreach (explode('&', $queryString) as $value) {
        $queryStringTemp = explode('=', $value);
        $arr[trim($queryStringTemp[0])] = trim($queryStringTemp[1]);
    }
    return $arr;//
}
function get_child_url($http=true){
    if (isset($_SERVER['HTTP_X_REAL_HOST'])) {
        $host = $_SERVER['HTTP_X_REAL_HOST'];
    } else {
        $host = $_SERVER['HTTP_HOST'];
    }
    if(isset($_SERVER["PHP_SELF"])){
        $child_path=explode("addons/",$_SERVER["PHP_SELF"]);
    }else{
        $child_path=explode("addons/",$_SERVER["REQUEST_URI"]);
    }
    $http=($http===true)?"http://":"https://";
   // $http=$_SERVER['REQUEST_SCHEME'];
    return $http.$host.$child_path[0];
}
/**
 * 获取客户端IP地址
 * @param integer $type 返回类型 0 返回IP地址 1 返回IPV4地址数字
 * @param boolean $adv 是否进行高级模式获取（有可能被伪装）
 * @return string
 */
function get_client_ip($type = 0, $adv = true)
{
    $type      = $type ? 1 : 0;
    static $ip = null;
    if (null !== $ip) {
        return $ip[$type];
    }
    if ($adv) {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $pos = array_search('unknown', $arr);
            if (false !== $pos) {
                unset($arr[$pos]);
            }
            $ip = trim(current($arr));
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    // IP地址合法验证
    $long = sprintf("%u", ip2long($ip));
    $ip   = $long ? [$ip, $long] : ['0.0.0.0', 0];
    return $ip[$type];
}

function htmltomip($content)
{
    $desc = preg_replace('/style=".*?"/i', '', $content);
    preg_match_all('/(<img )([\s\S]*?)( \/>)/', $desc, $matche);

    $all_img = $matche[0];
    $mip_img = array();
    foreach ($all_img as $img)
    {
        $matche = array();
        preg_match_all('/(src=")([\s\S]*?)(")/', $img, $matche);
        $src = $matche[2][0];
        $mip_img[] = "<mip-img class=\"content_img\" src=\"{$src}\"></mip-img>";
    }

    $desc = str_replace($all_img,$mip_img,$desc);

    return $desc;
}

function h5linkmip($item)
{
    global $_W;

    $url = $item['url'];
    $urlarr = parse_url($url);
    parse_str($urlarr['query'],$parr);
    $id = !empty($parr['id']) ? $parr['id'] : 0;
    $id = !empty($item['param']) ? $item['param'] : $id;

    if(strpos($url,"yb_tuangou/pages/index/index") !== false)
    {
        return "/index.html";
    }
    else if(strpos($url,"yb_tuangou/pages/find/index") !== false)
    {

        return "/article/{$id}_1.html";
    }
    else if(strpos($url,"yb_tuangou/pages/find_info/index") !== false)
    {
        return "/article/{$id}.html";
    }
    else if(strpos($url,"yb_tuangou/pages/class_image/index") !== false)
    {
        return "/photo/1.html";
    }
    else if(strpos($url,"yb_tuangou/pages/image/index") !== false)
    {
        return "/photo/{$id}_1.html";
    }
    else if(strpos($url,"yb_tuangou/pages/product/list/index") !== false)
    {
        return "/product/{$id}_1.html";
    }
    else if(strpos($url,"yb_tuangou/pages/product/info/index") !== false)
    {
        return "/product/{$id}.html";
    }

    return $_W['siteroot']."addons/yb_tuangou/h5/".$_W['uniacid']."/#/".ltrim($url,"/");
}

//循环删除目录和文件函数
function delDirAndFile($dirName)
{
    if ( $handle = opendir( $dirName ) ) {
        while ( false !== ( $item = readdir( $handle ) ) ) {
            if ( $item != "." && $item != ".." ) {
                if ( is_dir( $dirName."/$item" ) ) {
                    delDirAndFile( $dirName."/$item" );
                } else {
                    unlink( $dirName."/$item" );
                }
            }
        }
        closedir( $handle );
        rmdir($dirName);
    }
}

//获取目录下所有文件的函数
function allfile($dir) {
    $files = array();
    if (is_file($dir)) {
        return $dir;
    }
    $handle = opendir($dir);
    if ($handle) {
        while (false !== ($file = readdir($handle))) {
            if ($file != '.' && $file != '..') {
                $filename = $dir . "/" . $file;
                if (is_file($filename)) {
                    $files[] = $filename;
                } else {
                    $files = array_merge($files, allfile($filename));
                }
            }
        } // end while
        closedir($handle);
    }
    return $files;
}