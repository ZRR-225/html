<?php
set_time_limit(0);
define('BASE_ROOT', __DIR__ . '/');
include_once "core/application/api/controller/Index.php";
include_once "core/application/api/controller/User.php";
include_once "core/application/api/controller/Goods.php";
include_once "core/application/api/controller/Cart.php";
include_once "core/application/api/controller/Article.php";
include_once "core/application/api/controller/Arliki.php";
include_once "core/application/api/controller/Market.php";
include_once "core/application/api/controller/Area.php";
include_once "core/application/api/controller/Order.php";
include_once "core/application/api/controller/Pay.php";
include_once "core/application/api/controller/Album.php";
include_once "core/application/api/controller/Bargain.php";
include_once "core/application/api/controller/Wxpush.php";
include_once "core/application/api/controller/Pintuan.php";
include_once "core/application/api/controller/Miaosha.php";
include_once "core/application/api/controller/Distribe.php";
include_once "core/application/api/controller/Share.php";
include_once "core/application/api/controller/Product.php";
include_once "core/application/api/controller/Paycontent.php";
include_once "core/application/api/controller/Integral.php";
include_once "core/application/api/controller/Userbd.php";
include_once "core/application/api/controller/Userwap.php";
include_once "core/application/api/controller/Usercard.php";
include_once "core/application/api/controller/Merchant.php";
include_once "core/application/api/controller/Commander.php";
include_once "core/application/api/controller/Community.php";
use app\api\controller\Index;
use app\api\controller\Arliki;
use app\api\controller\User;
use app\api\controller\Goods;
use app\api\controller\Cart;
use app\api\controller\Article;
use app\api\controller\Market;
use app\api\controller\Area;
use app\api\controller\Order;
use app\api\controller\Pay;
use app\api\controller\Album;
use app\api\controller\Bargain;
use app\api\controller\Wxpush;
use app\api\controller\Pintuan;
use app\api\controller\Miaosha;
use app\api\controller\Distribe;
use app\api\controller\Share;
use app\api\controller\Product;
use app\api\controller\Paycontent;
use app\api\controller\Integral;
use app\api\controller\Userbd;
use app\api\controller\Userwap;
use app\api\controller\Usercard;
use app\api\controller\Commander;
use app\api\controller\Community;
error_reporting(0);
header('Access-Control-Allow-Origin: *');

class yb_tuangouModuleWxapp extends WeModuleWxapp
{
    private $gpc;
    private $w;
    public function __construct()
    {
        global $_W;
        global $_GPC;
        $this->gpc = $_GPC;
        $this->w = $_W;
    }

    public function get($key, $default = null)
    {
        return isset($this->gpc[$key]) ? $this->gpc[$key] : $default;
    }
    /*
     * 接口调用tp5项目1
     * doPageAAA_BBB
     * AAA为控制器
     * BBB为方法
     */

    public function doPageArliki_get_comment(){
        $t = new Arliki();
        $res = $t->get_comment();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    public function doPageArliki_write_comment(){
        $t = new Arliki();
        $res = $t->write_comment();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    public function doPageArliki_get_suppler(){
        $t = new Arliki();
        $res = $t->get_suppler();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    public function doPageArliki_get_apply(){
        $t = new Arliki();
        $res = $t->get_apply();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    public function doPageArliki_get_choice_city(){
        $t = new Arliki();
        $res = $t->get_choice_city();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    //红包
    public function doPageArliki_get_red_conf(){
        $t = new Arliki();
        $res = $t->get_red_conf();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    public function doPageArliki_get_red_info(){
        $t = new Arliki();
        $res = $t->get_red_info();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    public function doPageArliki_do_split(){
        $t=new Arliki();
        $res=$t->do_split();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    public function doPageArliki_share_success(){
        $t=new Arliki();
        $res=$t->share_success();
        $callback = $_GET['callback']; if (!empty($callback)) { exit($callback.'('.$res.')'); } else { return $res; }
    }
    //社区
    public function doPageCommunity_city()
    {
        $t = new Community();
        $res = $t->city();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageCommunity_comlist()
    {
        $t = new Community();
        $res = $t->comlist();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageCommunity_sendcode()
    {
        $t = new Community();
        $res = $t->sendcode();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageCommunity_shareOrder()
{
    $t = new Community();
    $res = $t->shareOrder();
    $callback = $_GET['callback'];
    if (!empty($callback)) {
        exit($callback . '(' . $res . ')');
    } else {
        return $res;
    }
}
    public function doPageCommunity_OrderInfo()
    {
        $t = new Community();
        $res = $t->OrderInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageCommunity_verifyOrder()
    {
        $t = new Community();
        $res = $t->verifyOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageCommunity_signOrder()
{
    $t = new Community();
    $res = $t->signOrder();
    $callback = $_GET['callback'];
    if (!empty($callback)) {
        exit($callback . '(' . $res . ')');
    } else {
        return $res;
    }
}
    public function doPageCommunity_Addsupplier()
    {
        $t = new Community();
        $res = $t->Addsupplier();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageCommunity_refund()
    {
        $t = new Community();
        $res = $t->refund();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageCommunity_get_verify_info()
    {
        $t = new Community();
        $res = $t->get_verify_info();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    //index
    public function doPagetest()
    {
        return 'success';
    }

    public function doPageindex_modindex()
    {
        $t = new Index();
        $res = $t->ModIndex();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_form()
    {
        $t = new Index();
        $res = $t->form();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_submitform()
    {
        $t = new Index();
        $res = $t->submitform();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_power()
    {
        $t = new Index();
        $res = $t->power();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_menu()
    {
        $t = new Index();
        $res = $t->menu();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_tabbar()
    {
        $t = new Index();
        $res = $t->tabbar();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_ucenter()
    {
        $t = new Index();
        $res = $t->ucenter();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepic_share()
    {
        $t = new Share();
        $res = $t->share();
        exit($res);
    }

    public function doPageqr_code()
    {
        $t = new Share();
        $res = $t->getqrcode();
        exit($res);
    }

    public function doPagenet_img()
    {
        $t = new Share();
        $res = $t->getpic();
        exit($res);
    }

    public function doPageindex_WriteBook()
    {
        $t = new Index();
        $res = $t->WriteBook();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_WriteComment()
    {
        $t = new Index();
        $res = $t->WriteComment();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageindex_articleMod()
    {
        $t = new Index();
        $res = $t->articleMod();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageindex_goodsMod()
    {
        $t = new Index();
        $res = $t->goodsMod();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageindex_CommentList()
    {
        $t = new Index();
        $res = $t->CommentList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageindex_uploadFile()
    {
        $t = new Index();
        $res = $t->uploadFile();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //user
    public function doPageuser_openid()
    {
        $t = new User();
        $res = $t->OpenId();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_login()
    {
        $t = new User();
        $res = $t->Login();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_weblogin()
    {
        $t = new User();
        $res = $t->WebLogin();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_Index()
    {
        $t = new User();
        $res = $t->Index();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageUser_About()
    {
        $t = new User();
        $res = $t->About();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageUser_UserInfo()
    {
        $t = new User();
        $res = $t->UserInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_AddressList()
    {
        $t = new User();
        $res = $t->AddressList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_GetFavorites()
    {
        $t = new User();
        $res = $t->GetFavorites();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_SingleAddress()
    {
        $t = new User();
        $res = $t->SingleAddress();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_updateAddress()
    {
        $t = new User();
        $res = $t->updateAddress();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_CreateAddress()
    {
        $t = new User();
        $res = $t->CreateAddress();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuser_delAddress()
    {
        $t = new User();
        $res = $t->delAddress();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageUser_GetAreaId()
    {
        $t = new User();
        $res = $t->GetAreaId();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //goods
    public function doPagegoods_GetCate()
    {
        $t = new Goods();
        $res = $t->GetCate();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_GoodsList()
    {
        $t = new Goods();
        $res = $t->GoodsList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_CateGoods()
    {
        $t = new Goods();
        $res = $t->CateGoods();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_GetGoods()
    {
        $t = new Goods();
        $res = $t->GetGoods();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_CartGoods()
    {
        $t = new Goods();
        $res = $t->CartGoods();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_GoodsDetail()
    {
        $t = new Goods();
        $res = $t->GoodsDetail();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_GoodsClicks()
    {
        $t = new Goods();
        $res = $t->GoodsClicks();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_Favorites()
    {
        $t = new Goods();
        $res = $t->Favorites();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagegoods_DelFavorites()
    {
        $t = new Goods();
        $res = $t->DelFavorites();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //article
    public function doPageArticle_Article()
    {
        $t = new Article();
        $res = $t->Article();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageArticle_ArticleClass()
    {
        $t = new Article();
        $res = $t->ArticleClass();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageArticle_ArticleInfo()
    {
        $t = new Article();
        $res = $t->ArticleInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //cart
    public function doPageCart_cart()
    {
        $t = new Cart();
        $res = $t->Cart();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageCart_AddCart()
    {
        $t = new Cart();
        $res = $t->AddCart();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageCart_DelCart()
    {
        $t = new Cart();
        $res = $t->DelCart();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageCart_cartNum()
    {
        $t = new Cart();
        $res = $t->CartNum();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //Market
    public function doPageMarket_UserFee()
    {
        $t = new Market();
        $res = $t->UserFee();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_UserCoupon()
    {
        $t = new Market();
        $res = $t->UserCoupon();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_booklist()
    {
        $t = new Market();
        $res = $t->booklist();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_bookinfo()
    {
        $t = new Market();
        $res = $t->bookinfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_submitbook()
    {
        $t = new Market();
        $res = $t->submitbook();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_UserBook()
    {
        $t = new Market();
        $res = $t->UserBook();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_getFormid()
    {
        $t = new Market();
        $res = $t->getFormid();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_BusCoupon()
    {
        $t = new Market();
        $res = $t->BusCoupon();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_mchInfo()
    {
        $t = new Market();
        $res = $t->mchInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_ManJian()
    {
        $t = new Market();
        $res = $t->ManJian();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageMarket_GetCoupon()
    {
        $t = new Market();
        $res = $t->GetCoupon();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //Area
    public function doPagearea_GetArea()
    {
        $t = new Area();
        $res = $t->GetArea();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagearea_UserAddress()
    {
        $t = new Area();
        $res = $t->UserAddress();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //order
    public function doPageOrder_OrderList()
    {
        $t = new Order();
        $res = $t->OrderList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageOrder_after_sale()
    {
        $t = new Order();
        $res = $t->after_sale();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageOrder_createOrder()
    {
        $t = new Order();
        $res = $t->createOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageOrder_PrintTest()
    {
        $t = new Order();
        $res = $t->PrintTest();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageOrder_getOrder()
    {
        $t = new Order();
        $res = $t->getOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageOrder_signOrder()
    {
        $t = new Order();
        $res = $t->signOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageOrder_cancelOrder()
    {
        $t = new Order();
        $res = $t->cancelOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageOrder_delOrder()
    {
        $t = new Order();
        $res = $t->delOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageOrder_refundOrder()
    {
        $t = new Order();
        $res = $t->refundOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //pay
    public function doPagepay_OrderInfo()
    {
        $t = new Pay();
        $res = $t->OrderInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepay_Pay()
    {
        $t = new Pay();
        $res = $t->Pay();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagepay_Paywap()
    {
        $t = new Pay();
        $res = $t->Paywap();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagepay_PayCallback()
    {
        $t = new Pay();
        $res = $t->PayCallback();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

//Album
    public function doPageAlbum_AlbumImages()
    {
        $t = new Album();
        $res = $t->AlbumImages();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageAlbum_Album()
    {
        $t = new Album();
        $res = $t->Album();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //砍价
    public function doPageBargain_BarIndex()
    {
        $t = new Bargain();
        $res = $t->BarIndex();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageBargain_kjGoodsmodel()
    {
        $t = new Bargain();
        $res = $t->kjGoodsmodel();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageBargain_Bargain()
    {
        $t = new Bargain();
        $res = $t->Bargain();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_GoodsInfo()
    {
        $t = new Bargain();
        $res = $t->GoodsInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_BargainInfo()
    {
        $t = new Bargain();
        $res = $t->BargainInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_BargainCreate()
    {
        $t = new Bargain();
        $res = $t->BargainCreate();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_BargainHelp()
    {
        $t = new Bargain();
        $res = $t->BargainHelp();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_BargainRecord()
    {
        $t = new Bargain();
        $res = $t->BargainRecord();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_MyBargain()
    {
        $t = new Bargain();
        $res = $t->MyBargain();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_CreateOrder()
    {
        $t = new Bargain();
        $res = $t->CreateOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_OrderList()
    {
        $t = new Bargain();
        $res = $t->OrderList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_GetOrder()
    {
        $t = new Bargain();
        $res = $t->GetOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_SignOrder()
    {
        $t = new Bargain();
        $res = $t->SignOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_CancelOrder()
    {
        $t = new Bargain();
        $res = $t->CancelOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_DelOrder()
    {
        $t = new Bargain();
        $res = $t->DelOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_RefundOrder()
    {
        $t = new Bargain();
        $res = $t->RefundOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_OrderInfo()
    {
        $t = new Bargain();
        $res = $t->OrderInfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageBargain_Pay()
    {
        $t = new Bargain();
        $res = $t->Pay();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageBargain_Paywap()
    {
        $t = new Bargain();
        $res = $t->Paywap();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    //砍价end
//模板推送 普通订单创建
    public function doPageWxpush_CreateOrderPush()
    {
        $t = new Wxpush();
        $res = $t->CreateOrderPush();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    //模板推送 砍价订单创建
    public function doPageWxpush_CreateOrderPush2()
    {
        $t = new Wxpush();
        $res = $t->CreateOrderPush2();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageWxpush_DeliveryOrderPush()
    {
        $t = new Wxpush();
        $res = $t->DeliveryOrderPush();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageWxpush_PayOrderPush()
    {
        $t = new Wxpush();
        $res = $t->PayOrderPush();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    //拼团成功 消息推送
    public function doPageWxpush_PtSuccessPush()
    {
        $t = new Wxpush();
        $res = $t->PtSuccessPush();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageWxpush_KgSuccessPush()
    {
        $t = new Wxpush();
        $res = $t->KgSuccessPush();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageWxpush_FromSuccessPush()
    {
        $t = new Wxpush();
        $res = $t->FromSuccessPush();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //拼团begin
    public function doPagePintuan_ptIndex()
    {
        $t = new Pintuan();
        $res = $t->ptIndex();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagePintuan_ptGoodsmodel()
    {
        $t = new Pintuan();
        $res = $t->ptGoodsmodel();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_ptGoodsList()
    {
        $t = new Pintuan();
        $res = $t->ptGoodsList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_ptGoodsDetail()
    {
        $t = new Pintuan();
        $res = $t->ptGoodsDetail();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_ptCreateOrder()
    {
        $t = new Pintuan();
        $res = $t->ptCreateOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_ptPay()
    {
        $t = new Pintuan();
        $res = $t->ptPay();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagePintuan_ptPaywap()
    {
        $t = new Pintuan();
        $res = $t->ptPaywap();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagePintuan_ptOrderList()
    {
        $t = new Pintuan();
        $res = $t->ptOrderList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_ptOrderDetail()
    {
        $t = new Pintuan();
        $res = $t->ptOrderDetail();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_ptGroupList()
    {
        $t = new Pintuan();
        $res = $t->ptGroupList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_ptGroupDetail()
    {
        $t = new Pintuan();
        $res = $t->ptGroupDetail();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_SignOrder()
    {
        $t = new Pintuan();
        $res = $t->SignOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagePintuan_refundOrder()
    {
        $t = new Pintuan();
        $res = $t->refundOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //分销
    public function doPageDistribe_userinfo()
    {
        $t = new Distribe();
        $res = $t->userinfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_addman()
    {
        $t = new Distribe();
        $res = $t->addman();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_join()
    {
        $t = new Distribe();
        $res = $t->join();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_myteam()
    {
        $t = new Distribe();
        $res = $t->myteam();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_shareOrder()
    {
        $t = new Distribe();
        $res = $t->shareOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_shareSetting()
    {
        $t = new Distribe();
        $res = $t->shareSetting();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_addCash()
    {
        $t = new Distribe();
        $res = $t->addCash();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_CashList()
    {
        $t = new Distribe();
        $res = $t->CashList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageDistribe_getShareCode()
    {
        $t = new Distribe();
        $res = $t->getShareCode();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageproduct_productClass()
    {
        $t = new Product();
        $res = $t->productClass();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageproduct_product_list()
    {
        $t = new Product();
        $res = $t->product_list();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageproduct_product_info()
    {
        $t = new Product();
        $res = $t->product_info();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_paycontentClass()
    {
        $t = new Paycontent();
        $res = $t->paycontentClass();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_paycontent_list()
    {
        $t = new Paycontent();
        $res = $t->paycontent_list();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_paycontent_info()
    {
        $t = new Paycontent();
        $res = $t->paycontent_info();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_samegroup()
    {
        $t = new Paycontent();
        $res = $t->samegroup();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_allprice()
    {
        $t = new Paycontent();
        $res = $t->allprice();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_createOrder()
    {
        $t = new Paycontent();
        $res = $t->createOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_checkuser()
    {
        $t = new Paycontent();
        $res = $t->checkuser();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_dolike()
    {
        $t = new Paycontent();
        $res = $t->dolike();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_uinfo()
    {
        $t = new Paycontent();
        $res = $t->uinfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_order()
    {
        $t = new Paycontent();
        $res = $t->order();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepaycontent_likes()
    {
        $t = new Paycontent();
        $res = $t->likes();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //百度小程序  api
    public function doPageuserbd_openid()
    {
        $t = new Userbd();
        $res = $t->OpenId();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuserbd_login()
    {
        $t = new Userbd();
        $res = $t->Login();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageuserbd_Index()
    {
        $t = new Userbd();
        $res = $t->Index();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPagepay_Paybd()
    {
        $t = new Pay();
        $res = $t->Paybd();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //秒杀
    public function doPageMiaosha_msGoodsList()
    {
        $t = new Miaosha();
        $res = $t->msGoodsList();
        return $res;
    }

    public function doPageMiaosha_msGoodsmodel()
    {
        $t = new Miaosha();
        $res = $t->msGoodsmodel();
        return $res;
    }

    public function doPageMiaosha_msGoodsDetail()
    {
        $t = new Miaosha();
        $res = $t->msGoodsDetail();
        return $res;
    }

    public function doPageMiaosha_CreateOrder()
    {
        $t = new Miaosha();
        $res = $t->CreateOrder();
        return $res;
    }

    public function doPageMiaosha_OrderList()
    {
        $t = new Miaosha();
        $res = $t->OrderList();
        return $res;
    }

    public function doPageMiaosha_GetOrder()
    {
        $t = new Miaosha();
        $res = $t->GetOrder();
        return $res;
    }

    public function doPageMiaosha_SignOrder()
    {
        $t = new Miaosha();
        $res = $t->SignOrder();
        return $res;
    }

    public function doPageMiaosha_CancelOrder()
    {
        $t = new Miaosha();
        $res = $t->CancelOrder();
        return $res;
    }

    public function doPageMiaosha_DelOrder()
    {
        $t = new Miaosha();
        $res = $t->DelOrder();
        return $res;
    }

    public function doPageMiaosha_RefundOrder()
    {
        $t = new Miaosha();
        $res = $t->RefundOrder();
        return $res;
    }

    public function doPageMiaosha_OrderInfo()
    {
        $t = new Miaosha();
        $res = $t->OrderInfo();
        return $res;
    }

    public function doPageMiaosha_Pay()
    {
        $t = new Miaosha();
        $res = $t->Pay();
        return $res;
    }
    public function doPageMiaosha_Paywap()
    {
        $t = new Miaosha();
        $res = $t->Paywap();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    //userwap
    public function doPageUserwap_login()
    {
        $t = new Userwap();
        $res = $t->login();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    public function doPageUserwap_register()
    {
        $t = new Userwap();
        $res = $t->register();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }

    //积分
    public function doPageIntegral_qiandao()
    {
        $t = new Integral();
        $res = $t->qiandao();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_allrank()
    {
        $t = new Integral();
        $res = $t->allrank();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_speedrank()
    {
        $t = new Integral();
        $res = $t->speedrank();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_integralinfo()
    {
        $t = new Integral();
        $res = $t->integralinfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_goodscate()
    {
        $t = new Integral();
        $res = $t->goodscate();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_goodslist()
    {
        $t = new Integral();
        $res = $t->goodslist();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_goodsinfo()
    {
        $t = new Integral();
        $res = $t->goodsinfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_createorder()
    {
        $t = new Integral();
        $res = $t->createorder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageIntegral_exchangelog()
    {
        $t = new Integral();
        $res = $t->exchangelog();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    //会员卡
    public function doPageUsercard_cardinfo()
    {
        $t = new Usercard();
        $res = $t->cardinfo();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageUsercard_addcard()
    {
        $t = new Usercard();
        $res = $t->addcard();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageUsercard_createOrder()
    {
        $t = new Usercard();
        $res = $t->createOrder();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageUsercard_exchangelog()
    {
        $t = new Usercard();
        $res = $t->exchangelog();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageUsercard_consumeLog()
    {
        $t = new Usercard();
        $res = $t->consumeLog();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageUsercard_rechargemeal()
    {
        $t = new Usercard();
        $res = $t->rechargemeal();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPageUser_CommanderId()
    {
        $t = new User();
        $res = $t->commanderId();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_AddCommander()
    {
        $t = new Commander();
        $res = $t->commanderAdd();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CommanderList()
    {
        $t = new Commander();
        $res = $t->commanderList();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CommanderCenter()
    {
        $t = new Commander();
        $res = $t->commanderCenter();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_UpdatePassword()
    {
        $t = new Commander();
        $res = $t->updatePassword();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_UpdateMobile()
    {
        $t = new Commander();
        $res = $t->updateMobile();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_UpdateType()
    {
        $t = new Commander();
        $res = $t->updateType();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CommanderData()
    {
        $t = new Commander();
        $res = $t->commanderData();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_ManageData()
    {
        $t = new Commander();
        $res = $t->manageData();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CommissionLog()
    {
        $t = new Commander();
        $res = $t->commissionLog();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CashManage()
    {
        $t = new Commander();
        $res = $t->cashManage();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CashMethod()
    {
        $t = new Commander();
        $res = $t->cashMethod();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CashApply()
    {
        $t = new Commander();
        $res = $t->cashApply();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_CommunityImg()
    {
        $t = new Commander();
        $res = $t->communityImg();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
    public function doPagecommander_UpdateImg()
    {
        $t = new Commander();
        $res = $t->updateImg();
        $callback = $_GET['callback'];
        if (!empty($callback)) {
            exit($callback . '(' . $res . ')');
        } else {
            return $res;
        }
    }
}
