<?php
defined('IN_IA') or exit('Access Denied');
function jumpIndex()
{
    global $_W;
    global $_GPC;
    session_start();
    if(!empty($_GPC['version_id']))
    {
        $_SESSION['version_id'] = $_GPC['version_id'];
    }
    $_SESSION['we7_w'] = $_W;
    $url = $_W['siteroot'] . 'addons/' . $_W['current_module']['name'] . '/core/index.php';
    if (session_status() != PHP_SESSION_ACTIVE)
        session_start();
    $_SESSION['we7_user'] = $_W['user'];
    $_SESSION['we7_account'] = $_W['account'];
    if (file_exists(__DIR__ . '/core/index.php')) {
        header('Location:' . $url);
        exit;
    }
    else
    {
        die('应用入口文件缺失，请联系开发者处理！');
    }
}

//模块标识Module 首字母大写
class Yb_tuangouModule extends WeModule
{
    //必须走这个方法 方法名不能变
    public function welcomeDisplay()
    {
        jumpIndex();
    }
}
